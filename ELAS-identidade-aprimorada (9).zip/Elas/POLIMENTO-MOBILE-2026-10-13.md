> Atualização seguinte: Overture está integrado ao catálogo. Veja [OVERTURE-E-ENRIQUECIMENTO-2026-10-13.md](OVERTURE-E-ENRIQUECIMENTO-2026-10-13.md) para dados aplicados, schema 4, fotos, aliases e verificações atuais. As seções abaixo registram o estado da entrega anterior.

# Polimento mobile do ELAS — 13/10/2026

## Escopo entregue

React Native, Expo SDK 55, Expo Router e TypeScript mantidos. Ajustes concentrados no mapa, perfil, avisos e notificações. A paleta original, os prédios, logo, carinhas e navegação inferior não foram substituídos.

| Área | Alteração |
| --- | --- |
| Mapa | Categorias rápidas com rolagem horizontal. Escopos de busca aparecem durante a busca/lista. Detalhes em painel inferior, com nome/endereço legíveis, expansão, fechamento e botão de avaliar nos dois estados. |
| Ponto selecionado | No web, foco calculado pelo espaço entre busca e painel; no nativo, padding atualizado conforme a altura do painel. O corpo dos detalhes rola em telas menores. |
| Controles web | Zoom separado dos controles adicionais de movimento. Impactos/lista deixam espaço para o painel enquanto os detalhes estão abertos. |
| Perfil | Cabeçalho coerente com as outras abas; menu agrupado em participação, conta e equipe. Contagem de notificações separada do título. Resumo de conquistas mais compacto, mantendo critérios/ícones e acesso à lista completa. |
| Avisos | Hierarquia sem caixa alta alarmista para todo relato. Resumos, horários, indicação de verificação e ação que corresponde ao destino real. Pendência não aparece como risco confirmado. |
| Notificações | Uma superfície de toque abre o registro e solicita marcação de leitura. Destaque discreto para não lidas, horários compactos, ação “Ler todas” e estado vazio. Sem repetir vários botões em cada cartão. |

Foram preservados feedback ao toque, redução de movimento, filtros completos, lista alternativa aos pontos, tratamento de GPS negado, favoritos, direções, correção de cadastro e avaliação unificada. Nenhuma avaliação/classificação/foto foi inventada.

## Overture: decisão técnica

Overture Places é um conjunto de dados de estabelecimentos, e não uma API que substitui diretamente o componente de mapa. Pode enriquecer o catálogo de restaurantes/comércios. O mapa nativo atual usa react-native-maps (MapKit no iOS e Google Maps no Android); a versão web usa tiles OSM. Catálogo de lugares e desenho do mapa são responsabilidades distintas.

A documentação oficial informa cobertura global, identificadores GERS e downloads por área. Também registra duplicatas, baixa completude de propriedades e limitações de qualidade. O score de confiança trata da existência do estabelecimento, não da segurança para as usuárias. Não há fundamento para garantir que seja melhor em Criciúma sem comparar os registros locais.

Nesta entrega, Overture **não foi ativado**, não houve importação e nenhum registro existente foi substituído. A tentativa de acesso ao catálogo STAC expirou nesta sessão; não há medição local de cobertura. A fonte OSM/Overpass e seu fallback continuam como estavam na entrega anterior.

Para avaliar a troca, baixar somente Places na área da cidade com o cliente oficial, comparar nomes/endereço/posição com o catálogo atual, conferir praças e estabelecimentos conhecidos e revisar duplicatas/locais fechados. Para integrar, associar GERS a IDs internos existentes, guardar origem/data da versão e preservar avaliações, favoritos, relatos e overrides administrativos. Executar a importação no servidor, não baixar o catálogo global no celular. O schema atual da documentação de setembro de 2026 usa `basic_category` e `taxonomy`; o antigo campo `categories` foi removido.

## Referências consultadas

- [Awwwards — App Style](https://www.awwwards.com/inspiration_search/app-style/): galeria pública consultada; inspiração geral em hierarquia, controles compactos e superfícies arredondadas. Não foi copiada uma identidade de terceiros.
- [Mobbin — apps iOS](https://mobbin.com/discover/apps/ios): consulta tentada; o navegador recebeu 403. Não foram inspecionadas telas protegidas nem alegadas referências específicas desse acervo.
- [Overture Places](https://docs.overturemaps.org/guides/places/): estrutura, acesso e limites do catálogo.
- [Cliente Python do Overture](https://docs.overturemaps.org/getting-data/overturemaps-py/): extração por bounding box.
- [react-native-maps — MapView](https://github.com/react-native-maps/react-native-maps/blob/master/docs/mapview.md): padding para evitar sobreposição de marcadores e controles.

## Validação e limites

Resultados finais registrados nesta entrega: TypeScript, ESLint, testes de categorias/estado, teste de geometria do painel e horários, e exportação Expo Android/iOS/web. A comparação com o ZIP anterior verifica a preservação dos arquivos de marca e dos arquivos de backend.

Não houve alteração de schema, função Overpass, autenticação, contas ou dados de produção nesta etapa. Os testes novos não escrevem no Supabase.

A prévia local retornou conexão recusada no navegador desta sessão. Não há capturas antes/depois do ELAS nem prova de conferência visual em aparelho. Os achados aqui são derivados do código e das verificações descritas, não de uma auditoria visual concluída.

Conferir no celular: ponto → painel compacto → expansão/recolhimento → Avaliar e botão +; nomes longos; tamanho de texto ampliado; rolagem dos detalhes; busca com teclado; filtros e voltar; perfil com/sem avatar; relato pendente/verificado; abertura e leitura de notificações. Conferir também TalkBack/VoiceOver e gestos do mapa. Exportar com sucesso não substitui esses testes.

## Executar

```sh
npm ci
npx expo start
```

Para conferir a demonstração explicitamente identificada: `npm run demo`. Para repetir os testes novos: `npm run test:mobile`.

Documentos anteriores têm datas e resultados históricos; este arquivo descreve o polimento atual, e `VERIFICACAO-ONLINE-2026-10-13.md` descreve a verificação anterior dos serviços.
