# Interface com foco em aplicativo móvel — 15/10/2026

A gravação enviada mostra o formulário de Impactos com caixas cinzentas, a busca de lugar exposta no meio do formulário e os detalhes de evento apresentados como um bloco de mensagem. Esta atualização reorganiza esses fluxos em componentes React Native, mantendo Expo Router, a marca, as carinhas, os prédios e a paleta do ELAS.

## O que mudou

| Etapa | Diagnóstico da gravação | Comportamento atualizado |
| --- | --- | --- |
| Impactos → sugerir | Formulário longo depois de todos os exemplos | Cartão “Sugerir melhoria” antes da lista; abre um painel para a tarefa |
| Escrever sugestão | Campos sem rótulo persistente e pouco espaço para leitura | Rótulos visíveis, campos de 16 px, cantos arredondados, contador e erros junto aos campos |
| Escolher lugar | “Buscar no catálogo importado”, busca e formulário misturados | Etapa “Escolher lugar”, resultados com nome, endereço e ícone da categoria |
| Enviar | Botão pequeno e confirmação abaixo dos campos | Ação ampla no rodapé do painel, estado de envio e confirmação dedicada com acompanhamento |
| Eventos → detalhes | Mensagem com título e descrição concatenados | Painel com título, data, horário, local e descrição em blocos separados |
| Diálogos compartilhados | Caixa flutuante com ações pequenas | Painel inferior em telas de até 600 px, fechamento explícito e ações largas; janela central em telas maiores |
| Navegação | Ícone central alto e pouca diferenciação dos demais | Botão central com rótulo “Avaliar”, ícones alinhados e destaque da aba atual em uma cápsula |

Os cartões de eventos mostram dia e mês em destaque, local e uma prévia da descrição. Os de impactos usam status em etiquetas e descrição resumida; tocar abre o conteúdo completo. A busca de lugar também foi atualizada no fluxo de novo relato, que reutiliza o mesmo componente.

## Fluxos preservados e corrigidos

- Fechar e reabrir o painel mantém o rascunho. O armazenamento por conta continua usando o mecanismo existente.
- A escolha do lugar dentro da sugestão reutiliza o mesmo painel. Voltar dessa etapa retorna aos campos, sem abrir uma segunda janela sobre a primeira.
- O lugar recebido pela ação “Solicitar melhoria aqui” do mapa é carregado antes de habilitar o envio e passa a fazer parte do rascunho.
- O primeiro campo inválido recebe foco. Uma falha de envio mantém o texto para tentar novamente.
- O envio mantém o bloqueio contra toque duplo e a chave de idempotência. Durante o envio, o painel não é dispensado pelo botão Voltar.
- A confirmação leva ao registro salvo. “Enviar outra sugestão” inicia com os campos e o lugar limpos.
- Eventos reais mantêm inscrição e cancelamento pelo serviço existente, agora dentro do painel de detalhes. Eventos fictícios continuam sem inscrições reais.
- Datas e horários dos eventos usam o fuso de São Paulo; não dependem do fuso do aparelho.
- Os conteúdos de demonstração continuam identificados. Não houve alteração de banco nesta etapa.

Os campos compartilhados das telas auxiliares receberam o mesmo acabamento: fundo branco, borda discreta, foco em rosa, rótulo e espaço para orientação/erro. Não foram acrescentadas dependências de produção ou novas rotas.

## Referências consultadas

- [Material Design — Bottom sheets](https://github.com/material-components/material-components-android/blob/master/docs/components/BottomSheet.md): conteúdo contextual, ação concentrada no painel e tratamento dos limites da tela.
- [Material Design — Text fields](https://github.com/material-components/material-components-android/blob/master/docs/components/TextField.md): organização de campos e seus estados.
- [Apple — Writing](https://developer.apple.com/design/human-interface-guidelines/writing): rótulos claros, exemplos de preenchimento e erros próximos do campo.

As referências orientam o comportamento; a implementação usa os componentes, ícones e cores já adotados pelo aplicativo.

## Verificação e limites

Passaram TypeScript, ESLint sem avisos, os testes de conteúdos demonstrativos, a regressão de estabilidade do mapa, os testes existentes de limites móveis e os novos testes de fluxo `npm run test:app`.

O teste novo monta os componentes reais de formulário, campos, seleção, painel e detalhes de evento. Verifica uma janela por tarefa, retorno da escolha de lugar, validação e foco, preservação dos campos ao fechar/reabrir e após falha, carregamento do lugar recebido do mapa, conteúdo enviado, bloqueio de envio duplo, confirmação, acompanhamento, separação de eventos fictícios e reais, confirmação/cancelamento de diálogos e datas no fuso correto. Serviços e hosts nativos são simulados nesse teste; ele não grava dados reais nem mede layout.

As exportações web, Android e iOS passaram. O painel considera a área segura, oferece rolagem e usa `KeyboardAvoidingView` para o teclado nativo. A renderização, as animações, o foco de teclado e a leitura com tecnologia assistiva ainda precisam de conferência visual em aparelho: o navegador disponível bloqueou a prévia local, e o navegador de teste local não pôde ser instalado neste ambiente. Não se trata de uma auditoria completa de acessibilidade.

## Abrir e conferir

Extraia o ZIP, entre na pasta `Elas` e execute:

```sh
npm ci
npx expo start --clear
```

No app, confira Impactos → Sugerir melhoria → Adicionar um lugar → Enviar; depois abra Eventos → Ver exemplo/Ver detalhes. Entre na conta para carregar os conteúdos já cadastrados no Supabase. Não é necessário aplicar SQL para esta atualização.

Para repetir as verificações:

```sh
npm run typecheck
npm run lint
npm run test:app
npm run test:showcase
npm run test:stability
npm run test:mobile
npx expo export --platform all
```
