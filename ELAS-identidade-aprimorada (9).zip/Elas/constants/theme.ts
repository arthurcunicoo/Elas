// Product palette: use semantic roles in screens. Artwork and map geometry have explicit exceptions.
export const palette = {
  brand: "#BD1C51",
  wine: "#760B20",
  accent: "#7955B0",
  accentFill: "#9774D0",
  background: "#F5F5F5",
  surface: "#FFFFFF",
  surfaceTint: "#FFF2F2",
  text: "#30213C",
  muted: "#66616E",
  border: "#E8DFE5",
  icon: "#EDA1B8",
  success: "#26775F",
  successTint: "#EAF7F1",
  warning: "#8C5800",
  warningTint: "#FFF5E9",
  error: "#B31848",
  errorTint: "#FFF2F4",
  info: "#3178C6",
  infoTint: "#F3EDFB",
  disabled: "#E3E7EF",
  focusSurface: "#FFFCFD",
  overlay: "#24152199",
  warningFill: "#F5A623",
  successFill: "#49A789",
  attentionFill: "#FF7155",
  dangerFill: "#D82041",
};
export const artwork = {
  cityWine: "#760A22",
  clearCream: "#FFF2F200",
  clearWine: "#760B2000",
};
export const mapCanvas = {
  land: "#F0EEEA",
  road: "#FFFFFF",
  ink: "#333333",
  user: palette.info,
};
export const colors = {
  surface: palette.background,
  achievement: palette.accentFill,
  cream: palette.surfaceTint,
  wine: palette.wine,
  cityWine: artwork.cityWine,
  pink: palette.brand,
  white: palette.surface,
  icon: palette.icon,
};
export const ui = {
  action: palette.brand,
  text: palette.text,
  muted: palette.muted,
  surface: palette.background,
  input: palette.disabled,
  accentText: palette.accent,
};
export const statusText = {
  safe: palette.success,
  moderate: palette.warning,
  attention: palette.error,
  danger: palette.error,
  requested: palette.accent,
};
export const achievementColors = {
  reviews: "#FF438B",
  votes: "#40A68C",
  places: palette.accentFill,
  improvements: "#FF5752",
  recognition: "#FFAD25",
};
export const radius = { small: 8, medium: 12, large: 20, pill: 999 };
export const layout = {
  touch: 48,
  pageMax: 520,
  pageWidth: "100%" as const,
  pagePadding: 20,
  sectionGap: 24,
  cardRadius: radius.large,
  buttonRadius: radius.medium,
};
export const typography = {
  page: 22,
  section: 18,
  card: 15,
  body: 14,
  secondary: 13,
  input: 16,
  button: 16,
  caption: 12,
  navigation: 12,
};
export const cardShadow = {
  shadowColor: palette.text,
  shadowOpacity: 0.08,
  shadowRadius: 8,
  shadowOffset: { width: 0, height: 3 },
  elevation: 2,
};
export const cardSurface = {
  backgroundColor: palette.surface,
  borderRadius: radius.large,
  padding: 20,
  borderWidth: 1,
  borderColor: palette.border,
};
export const pageContent = {
  width: layout.pageWidth,
  maxWidth: layout.pageMax,
  paddingHorizontal: layout.pagePadding,
  alignSelf: "center" as const,
};
export const formLayout = {
  pageMax: layout.pageMax,
  padding: layout.pagePadding,
  gap: 14,
  cardRadius: radius.large,
  controlRadius: radius.medium,
  headerRadius: radius.large,
  inputHeight: 54,
  buttonHeight: 52,
};
