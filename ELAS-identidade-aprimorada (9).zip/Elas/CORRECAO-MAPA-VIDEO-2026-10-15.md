# Correção do mapa apontada no vídeo — 15/10/2026

Base: entrega anterior com ícones para celular e densidade reduzida. A gravação enviada foi inspecionada por quadros; nenhum trecho ou conteúdo do vídeo foi modificado ou incluído no ZIP.

## Problema e correção

Ao selecionar um lugar, o mapa ajusta o enquadramento para deixar o marcador visível entre os controles e o painel inferior. O indicador “Atualizando lugares” e o botão “Sobre a área” faziam parte da mesma área medida dos controles. Mostrar ou ocultar esses elementos alterava o espaço reservado; o mapa recentralizava e consultava uma nova região; a nova consulta alterava novamente a altura. Isso produzia o ciclo visível na gravação.

Agora somente busca e filtros entram na medida dos controles. As mensagens ocupam uma camada separada, com uma faixa de espaço fixa, sem alterar o enquadramento quando chegam resultados. O indicador de atualização do catálogo em segundo plano foi removido; o carregamento inicial e a recuperação de falhas continuam disponíveis. Uma mensagem da última resposta só é substituída pelo resultado seguinte ou pelo erro, sem desaparecer por causa do início de uma requisição.

Callbacks que representam a mesma região reutilizam o estado. A tolerância é de 0,00000001 grau, aproximadamente um milímetro de latitude, e não substitui as coordenadas de uma consulta real. Medidas dos painéis são arredondadas em pixels; coordenadas de lugares permanecem intactas. Os efeitos de enquadramento do relato passam a depender de ID e coordenadas, em vez de toda nova cópia do objeto.

A faixa solta “Parques: 12 nesta área”, abaixo de “Sobre a área” no vídeo, foi removida. A categoria continua identificada no filtro e as contagens permanecem no painel de filtros. Atribuições dos provedores do mapa e das fotos permanecem visíveis.

## Verificação

Foi acrescentado `npm run test:stability`, que monta em React a tela real do mapa, seu hook de consultas e o mapa web. Os componentes visuais nativos são hosts de teste, e as medidas são simuladas explicitamente. O teste não representa uma captura visual ou um aparelho.

- Na versão anterior, o cenário de término de consulta e mudança de altura dispara 12 consultas em 12 ciclos e falha na verificação de estabilização.
- Na versão corrigida, a seleção estabiliza após uma consulta nesse cenário e outros 20 ciclos não iniciam novas consultas.
- Uma alteração real da região ainda consulta os dados; ruído numérico de callback não consulta de novo.
- Trocar categoria continua funcionando, sem recolocar a faixa removida.
- TypeScript, ESLint, testes de relevância, cache/desempenho e limites dos painéis passaram.
- Exportações web, Android e iOS passaram.

O teste usa `react-test-renderer` 19.2.0, correspondente ao React do projeto, como dependência de desenvolvimento fixada no lockfile. Não acrescenta dependências ao aplicativo em produção. Não há alteração de schema ou configuração do servidor.

A gravação confirma o comportamento anterior; a correção foi validada em teste React e nas exportações. A execução visual posterior em navegador/aparelho continua pendente, pois a prévia local não está acessível ao navegador desta sessão.

## Abrir a entrega

Extraia o ZIP, entre em `Elas`, rode `npm ci` e `npx expo start --clear`. Para navegador, use `npm run web`. Não é necessário aplicar SQL.
