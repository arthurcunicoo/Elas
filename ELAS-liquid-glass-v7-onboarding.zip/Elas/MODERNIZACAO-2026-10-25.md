# Modernização do ELAS — 25/10/2026

Base autorizada: entrega deste chat de quinta-feira, 22/10/2026, versão 22, com Cidade viva. SHA-256 da referência: `282e97ed11d454431d6fe85620f580fbcf0399356d511df2ff651ca9ce7339a1`. O código local foi comparado byte a byte com os 359 arquivos desse ZIP antes das alterações. Não houve reescrita do aplicativo, alteração de produção, disparo push, importação externa ou aplicação de migration.

## Correções implementadas

| Problema confirmado | Mudança | Evidência |
| --- | --- | --- |
| Cada mudança de texto gerava uma gravação local | Debounce de 450 ms; snapshot serializado antes de entrar na fila; fila por chave; flush no background e desmontagem | 100 edições sequenciais: 100 → 1 gravação, com conteúdo final conferido |
| Navegação podia começar antes de concluir o salvamento | DraftGuard aguarda `draft.flush`; falha conserva a tela e oferece descarte explícito | Teste segura a Promise de armazenamento; nenhuma navegação antes da conclusão; falha não navega |
| Autosave podia recriar um rascunho depois da limpeza | Cancelamento dos timers antes de remover, remoção serializada e ausência de autosave do estado inicial | Envio/clear/timer posterior e logout testados |
| Dados restaurados poderiam estar vencidos, corrompidos ou no futuro | Validação de formato/tipos/tempo; descarte dos inválidos; projeção apenas dos campos conhecidos | Restauração, isolamento de contas e timestamp futuro testados |
| Atualizar uma lista apagava o conteúdo antes da resposta | Revalidação conserva itens e cursor enquanto busca; resposta obsoleta ignorada; refresh duplicado coalescido | Testes de refresh, concorrência, falha e continuação |
| Cursor anterior podia sobreviver à troca de filtro/conta | Cursor vinculado à identidade; dados e erros anteriores ocultos | Primeiro carregamento com falha não reutiliza cursor de outro escopo |
| Falha ao recarregar cidades removia a área e desmontava o mapa | Mantém áreas da mesma conta em memória com aviso de erro | Falha de rede conserva área; trocar conta continua limpando dados |
| Estado de tile ignorava a identidade do provedor | Camada remontada por template/limite de zoom; callbacks antigos descartados | Troca de provedor aguarda suas próprias imagens |
| Cada tile notificava repetidamente ausência de falha | Só notifica mudança do estado de falha | Seis tiles iniciais: 7 → 1 callbacks; fontes de imagem continuam estáveis em 100 pans |
| Mesmo carregamento completo em listas e abertura | Cidade viva completa na abertura/mapa; skeleton estático com um indicador compacto nas listas | Testes de variantes, redução de movimento e ciclo de vida |
| Relato exibia apenas erro geral | Erros junto aos campos de local, descrição e proposta, sem criar etapas extras | TypeScript, testes de app e componentes compartilhados |
| Conversão de data assumia UTC−3 | Fuso IANA configurável; conversão validada por round-trip; horários ambíguos/inexistentes de DST rejeitados | São Paulo, Manaus, Kathmandu, mudança de dia e DST de Nova York |
| 403 era tratado como sessão expirada | Estado próprio de permissão, separado de 401 e falha de conexão | Classificação e mensagem testadas |
| Worker mascarava toda falha como upstream/import genérico | Códigos limitados distinguem HTTP, timeout/rede, payload e importação; nenhuma mensagem arbitrária do erro é persistida | Falha 429 e falha de importação testadas |

## Desempenho medido

Os resultados são de Node/React test renderer, AsyncStorage e relógios simulados. Não medem I/O real, FPS, RAM ou latência de rede em celular. As referências anteriores estão em `qa/benchmarks/baseline/` como texto, fora do runtime.

- Rascunhos: 100 gravações antes e 1 depois, para 100 edições seguidas de disparo do debounce. Salvamento explícito, envio e saída podem acrescentar gravações deliberadas.
- Tiles: 7 callbacks de falha/ausência de falha antes e 1 depois na carga de seis imagens. A estabilidade das fontes durante pequenos movimentos já existia e foi preservada.
- Seleção JavaScript de lugares: entradas de 100, 500, 1.500 e 5.000 lugares; 5 aquecimentos e 30 execuções. Medianas e p95 estão em `qa/benchmarks/map-results.json`. Este ensaio caracteriza o algoritmo atual, sem alegar ganho antes/depois onde o algoritmo foi mantido. Não equivale a renderizar 5.000 pins nativos.
- `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` em PostgreSQL/PGlite isolado: busca de lugares usou Bitmap Heap Scan; consulta geográfica usou Seq Scan nesse conjunto pequeno. Elegibilidade GIN/GiST é verificada separadamente. Planos completos em `qa/benchmarks/postgres-plans.json`. Os tempos não representam produção.

## Arquitetura, mapa e banco mantidos

A aplicação continua em Expo Router/React Native, com providers por domínio, hooks, services e Supabase. Os testes existentes cobrem paginação keyset, busca normalizada, pg_trgm, PostGIS, seleção SQL limitada, clusters de relatos, cache regional com TTL/cancelamento e isolamento entre contas. O motor web já separa geometria, interação e tiles; não há medição de aparelho que justifique substituí-lo agora. Nenhuma biblioteca de mapa foi adicionada.

A fila de catálogo já usa lease, backoff, subdivisão, reconciliação e upsert; leituras do app usam o banco, não uma consulta Overpass por interação. Esses mecanismos foram preservados. A mudança do worker melhora o diagnóstico; não comprova disponibilidade atual do Overpass nem corrige um HTTP 406 externo. Deploy do worker continua pendente: o arquivo modificado não foi publicado.

Os índices e limites existentes foram exercitados no banco local. Não foi identificada nesta rodada uma mudança SQL comprovada que justificasse uma nova migration. Portanto, **não há migration nova para aplicar**. Não execute comandos de push/db reset contra produção por causa desta entrega.

## Datas e configuração

`EXPO_PUBLIC_SERVICE_TIMEZONE` em `.env.example` centraliza o fuso dos eventos do serviço; o padrão preserva America/Sao_Paulo. `cityInstant`, `cityDateParts` e `eventSchedule` aceitam fuso explícito, inclusive `ServiceArea.timezone`. Armazenamento continua em ISO UTC. Eventos ainda são do serviço, sem associação de cada evento a uma cidade: mudar a cidade do viewport não muda silenciosamente o fuso de um evento.

## Dependências e segurança

Nenhuma dependência foi adicionada/removida/atualizada e o lockfile foi preservado. A referência continua com Expo SDK 55, React 19.2.0, RN 0.83.10 e TypeScript 5.9.3. As versões instaladas de todas as dependências estão em `qa/benchmarks/installed-versions.json`.

A consulta oficial confirmou uma linha mais nova de Expo (SDK 58) e React (19.3). A documentação de RN/versões e o guia de Expo precisam ser conciliados antes de escolher o par exato. Não se fez uma migração de várias versões de SDK junto das alterações de estado. Fontes consultadas: https://expo.dev/changelog/sdk-58, https://docs.expo.dev/workflow/upgrading-expo-sdk-walkthrough/, https://react.dev/versions, https://reactnative.dev/versions, https://www.typescriptlang.org/download/ e https://supabase.com/changelog.

`npm audit --omit=dev --json` identificou **15 entradas: 1 crítica, 8 altas e 6 moderadas**, incluindo dependências transitivas. O JSON original está em `qa/benchmarks/dependency-audit.json`. As entradas não equivalem a 15 explorações confirmadas no aplicativo; parte está no ferramental de build. Também não devem ser ignoradas: shell-quote, source-map-js, decode-uri-component, node-forge e zod precisam de triagem e correção compatível. O audit propõe inclusive downgrades grandes de Expo/Sentry; tais sugestões não foram executadas automaticamente.

A revisão automática de comandos bloqueou a obtenção do resultado de consultas de metadados npm por limite de uso da sessão. Isso não foi uma avaliação de insegurança desses comandos. A atualização de pacotes permanece **pendente**, sem afirmar que o aplicativo está livre de vulnerabilidades.

Sessões nativas e rascunhos continuam em AsyncStorage, sem criptografia adicionada nesta entrega. Isolamento lógico de contas não equivale a proteção contra acesso ao armazenamento do dispositivo. Foi reduzida a persistência de rascunhos inválidos/vencidos quando recuperados, mas não existe limpeza de arquivos com o app fechado. SecureStore/criptografia exigem desenho de migração e validação nativa. O fluxo completo de exclusão de conta e todos os dados associados também não foi implementado; continua pendência de produto/backend. Não confundir remoção de registros individuais ou logout com exclusão da conta.

## Offline, push, administração e acessibilidade

- Conteúdo já carregado permanece disponível em falhas de revalidação. Não foi criado um cache persistente de relatos privados nem um modo offline completo. O SchemaGate continua exigindo uma versão válida ao iniciar uma sessão ainda não verificada; liberar telas indiscriminadamente poderia mascarar incompatibilidade ou permissão negada.
- Push permanece desativado, sem instalar segredos/cron/disparos. Testes existentes verificam consentimento, tokens, revogação, duplicidade, troca de conta e falhas com mocks. Recebimento em Android/iOS não foi certificado.
- Administração mantém cursores, filtros, pesquisa, histórico, permissões e controle de versão concorrente, cobertos pelos testes existentes. O diagnóstico do catálogo fica mais específico quando o worker for publicado; não foi criado um dashboard operacional novo.
- Leitores de tela recebem descrições de progresso, sem repetir a arte decorativa. Skeletons são estáticos e não acrescentam loops; a abertura usa um único CityPulse. Fontes, áreas de toque, teclado e safe areas mantêm os componentes compartilhados. Testes estruturais não substituem VoiceOver/TalkBack nem captura visual real.

## Testes e limites

Resultados e comandos executados estão em `qa/benchmarks/validation.json`. A suíte completa inclui TypeScript, ESLint, banco isolado/RLS, comunidade, cursores, consultas espaciais, app, arquitetura, web map, estabilidade, mobile, estado, OSM, Overture, cancelamento, operações, restore, push e regressões da revisão. Novos ensaios: `npm run test:modernization` e `node tests/map-benchmark.mjs`.

Os **22 requisitos de aparelho/build/fluxos externos** de `qa/release-evidence.json` continuam pending. Sem aparelho, não se confirma FPS/RAM, Dynamic Type, teclado físico, notificações recebidas, build assinado, SMTP/deep links ou lançamento público. Nenhuma evidência fictícia foi criada.

## Aplicação e reversão

1. Extraia o projeto em pasta separada; confira o relatório e o manifesto de alterações.
2. Use `npm ci` e `npm run verify`. Mantenha os valores públicos de configuração corretos para seu ambiente; o fuso é opcional.
3. Exporte/compile em staging e valide fluxos críticos nos aparelhos antes de distribuir.
4. Publique o worker de catálogo somente em etapa separada autorizada. Não ative push com esta atualização.
5. Para reverter, restaure o ZIP de referência de quinta-feira com seu package-lock. Formato de rascunho continua v1 e esquema continua 11, sem migração de dados nesta entrega.

Riscos específicos: cursor e conteúdo retido podem ficar desatualizados até revalidação; refresh bem-sucedido substitui a primeira página e pode alterar a posição de uma lista longa; armazenamento pode falhar ou o sistema pode encerrar o app antes de um evento de background; horário repetido por DST agora é recusado para evitar escolha silenciosa; troca de provedor remonta apenas a camada de tiles. Vulnerabilidades e validações externas pendentes impedem considerar esta versão certificada para lançamento.
