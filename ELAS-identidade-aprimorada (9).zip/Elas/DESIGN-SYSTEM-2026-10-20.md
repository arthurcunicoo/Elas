# ELAS — aplicação da revisão de UI/UX

A identidade rosa/vinho, o roxo, os fundos claros, o logotipo e as ilustrações foram mantidos. Este bloco consolida a linguagem visual e a aplica às telas existentes, sem alterar banco, autenticação ou regras de publicação.

## O que mudou

| Ponto da revisão | Aplicação |
| --- | --- |
| Cores isoladas | Paleta semântica em `constants/theme.ts`: marca, fundo, superfície, texto, muted, borda, sucesso, aviso, erro, informação e desabilitado. Tintas e cores de preenchimento têm papéis explícitos. Na versão de entrada, havia 89 hexadecimais distintos nos arquivos TSX de app/components/features; agora há zero nesses arquivos. Paletas de categorias e ilustrações permanecem em constantes próprias. |
| Raios | Escala `small=8`, `medium=12`, `large=20`, `pill=999`. Cards, controles, cabeçalhos e avatares usam tokens. Geometria de carinhas e marcadores do mapa permanece como exceção intencional. |
| Cards | Superfície compartilhada com raio 20, padding 20 e borda discreta nos cards de eventos, enquetes, melhorias, conquistas, relatos e formulários. Sombra reservada a componentes que precisam de elevação. |
| Tipografia | Caption e navegação em 12, texto secundário em 13, corpo em 14, títulos de card em 15–17, botões e entradas em 16, seção em 18 e página em 22. Botões de autenticação deixaram de usar 27. Números destacados, como datas e totais, podem continuar maiores. Já não havia fontes 10/11 na versão recebida; a nova regra impede sua reintrodução. |
| Larguras | Conteúdo com largura disponível, máximo 520 e gutters de 20. Aplicado às páginas principais, avaliação, busca de lugar, autenticação e novo relato. Sheets e elementos sobre o mapa preservam limites próprios. |
| Cabeçalhos | `PageHeader`/`AppHeader` fornece título, áreas seguras, navegação opcional e conteúdo adicional. Eventos, Alertas, Impactos, Perfil e Conquistas agora seguem a mesma base das telas de conta e contribuição. O cabeçalho de busca sobre o mapa mantém sua geometria medida para preservar estabilidade. |
| Botões | `PrimaryButton`, `SecondaryButton`, `TextButton`, `DangerButton` e `IconButton`, com altura, raio, tipografia e estado ocupado consistentes. Ações principais de autenticação, conta, avaliação, relato, enquete, inscrição em evento, solicitação de melhoria e confirmação passaram a reutilizar essa base. Exclusão de avaliação usa a variante de perigo. Seletores, chips, links editoriais e ações específicas do mapa continuam sendo controles próprios com tokens. |
| Formulários | `InputField`, `AccountField` e `Field` compartilham a mesma implementação. Estados normal, foco, erro, desabilitado e sucesso; senha visível/oculta; ref para foco; ícone e variante de contraste para autenticação. O comentário da avaliação também usa o campo compartilhado. |
| Botão central | O rótulo visível agora é `Relatar`. Abre o menu com `Relatar uma situação` primeiro e `Avaliar um lugar` em seguida. As duas ações continuam explícitas e preservam o contexto do lugar selecionado. |
| Enquetes | O nome `Enquetes` já estava corrigido e foi mantido. |

## Como evitar regressões

A regra local `elas/design-system` é executada pelo ESLint nas telas, componentes e features TSX. Ela rejeita cores hexadecimais diretas, fontes menores que 12 e raios numéricos fora das exceções geométricas identificadas. Usar tokens é parte da verificação normal do projeto.

## Validação

- `npm run verify`: passou, incluindo TypeScript, ESLint, banco simulado, resumos comunitários, fluxos de demonstração/produção, formulários, estabilidade e desempenho do mapa, relevância por zoom, importações, estado e atualização atômica.
- Testes montados ampliados para campo de autenticação desabilitado, senha, mensagens de erro/sucesso, confirmação de envio, foco e acessibilidade. O menu central é verificado quanto à ordem das opções e ausência de botões aninhados.
- A própria regra de lint é exercitada com estilos inválidos e estilos que usam tokens.
- `npx expo export --platform all`: bundles Android, iOS e web concluídos.

Não houve validação visual em navegador nem em aparelho real neste ambiente. Hosts nativos simulados não medem layout ou comportamento real do teclado. Conferir fontes ampliadas, telas pequenas, navegação por leitor de tela, teclado e toques em Android e iPhone continua sendo uma etapa necessária. A exportação não é um APK/IPA assinado e não demonstra prontidão para lançamento público em escala.
