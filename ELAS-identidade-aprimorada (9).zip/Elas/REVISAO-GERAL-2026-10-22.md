# Revisão geral do ELAS — 22/10/2026

**Não está tudo concluído nem validado para lançamento.** Esta revisão confrontou o código atual com os 63 pontos numerados e os pedidos anteriores sobre mapa, celular, conteúdo e distribuição.

Base: último ZIP entregue, versão 20, com 349 arquivos, comparado byte a byte antes das alterações. Banco conectado: schema 11, 20 migrações. Nesta revisão o banco foi consultado somente por leitura; nenhuma avaliação, evento, usuário ou notificação de teste foi criado. As correções abaixo são de código/configuração local e estão neste ZIP.

## Correções encontradas e aplicadas

1. **Leitura atrasada do push:** estado podia ser consultado durante registro/revogação e sobrescrever a tela com um valor antigo. Leituras passaram à mesma fila serial; gerações da tela invalidam respostas antigas. Permissão revogada no sistema é refletida na UI.
2. **Auth temporário sem o middleware normal:** recuperação/verificação de senha tinha cliente isolado, mas sem o limite de espera e monitoramento do cliente principal. Agora compartilha o fetch instrumentado com timeout de 20 segundos por requisição, preservando o isolamento da sessão.
3. **AbortSignal no Request:** o wrapper considerava só init.signal e podia perder cancelamento quando o sinal vinha no próprio Request. Passou a preservar os dois formatos e o override explícito.
4. **E2E iOS sem identificar o destino real:** validar apenas a variável do runner não garantia que a build instalada apontava ao staging. O roteiro agora abre diagnóstico QA e confere backend, versão/build, fonte e OS; backend real ou metadados ausentes causam falha.
5. **Validação de evidências permissiva:** uma pasta existente podia ser aceita como arquivo de evidência. O gate agora exige arquivo não vazio no diretório permitido, versão do app, data válida, revisor e IDs únicos. A comparação visual exige metadados reais e o mesmo OS da baseline. Isso não substitui revisão humana nem comprova autenticidade de evidências.
6. **Padronização incompleta:** cores das conquistas ainda estavam duplicadas e havia Consulta em ações administrativas/erros. Cores foram centralizadas e a copy passou a Enquete, mantendo a compatibilidade do SQL antigo.
7. **Smoke test antigo:** verificar-mvp ainda exercitava RPCs legados. Agora verifica schema e caminhos atuais de cursor/fila. Foi checado sintaticamente; execução com conta real dedicada continua pendente.
8. **Faixa de dependência:** declaração de React Navigation foi alinhada à do Expo Router. A versão efetivamente travada continua 7.4.1; nenhuma atualização de binário foi inventada para eliminar o aviso.

## O que foi verificado

- Suíte completa npm run verify, incluindo testes de banco, comunidade, cursor, geografia, UI/interações, estado, mapa, OSM/Overture, cancelamento, operação, restauração local, push e novas regressões da auditoria.
- TypeScript, ESLint e exportação Expo para Android, iOS e web. Revisão React de hooks/estados obsoletos, listeners, consentimento e carregamento condicionado.
- Expo install --check em modo offline após alinhamento: dependências em dia segundo a referência local. A tentativa online falhou por timeout do proxy; isso não é uma consulta bem-sucedida às versões atuais da internet.
- Permissões, migrações, extensões pg_trgm/PostGIS/Cron/pg_net e estado dos jobs por leitura. Não houve nova migração ou alteração operacional remota nesta revisão.
- Assets atuais: city-modern 78.673 bytes, congresso 99.601, nereu 68.286 e nacoes 72.293; largura 800 px.

Testes de React com hosts simulados não medem layout nativo. O protocolo iOS foi testado com fixtures, sem Xcode/iPhone. Não foi executado build assinado, e-mail real, carga no staging ou restauração remota. O vídeo/imagem antigos citados não estavam disponíveis para comparação visual; os pedidos foram conferidos pelo texto e pelo código.

## Situação real do ambiente

- 1.535 lugares cadastrados; zero avaliações, eventos, enquetes e solicitações de melhoria reais. Há 25 conteúdos fictícios separados para demonstração, sem transformá-los em avaliações públicas.
- App usa **Supabase**, conforme os prompts posteriores. O pedido antigo citava Firebase; não há implementação de banco Firestore nesta entrega. Configuração Google Services serve ao futuro FCM de push, não muda a fonte de dados do app.
- Retenção de envios ativa: primeira execução automática bem-sucedida observada, com tabela vazia. Nenhuma limpeza manual foi executada nesta revisão.
- Catálogo: cron ativo não equivale a importação concluída. Na janela de uma hora, seis respostas 503 do worker corresponderam a seis HTTP 406 da fonte Overpass; nenhum tile com sucesso de importação. O app continua lendo o catálogo já salvo. É uma pendência operacional concreta de acesso/ingestão da fonte.
- Push desativado e sem job de entrega. A autorização solicitada anteriormente para criar segredo/agendamento não foi presumida nesta revisão. Sentry/EAS/Maps/staging/contas QA continuam sem configuração disponível aqui.
- Gate de release continua reprovando as 22 validações pendentes. É uma ferramenta local de conferência; não substitui a aprovação humana da publicação nas lojas.
- Aviso anterior de proteção contra senhas vazadas no Auth continua presente; veja a [orientação do Supabase](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection). Há também um índice de FK ausente no histórico administrativo, de baixa prioridade. Tabelas privadas sem policy têm acesso direto revogado intencionalmente; índices novos sem uso não são removidos por isso.

## Pedidos anteriores aos números

| Pedido | Conclusão |
| --- | --- |
| Menos pins, relevância e detalhes só ao aproximar | Implementado no SQL, ranking/zoom e clustering; heurística não é medição de popularidade. Responsividade real ainda exige aparelho. |
| Corrigir ícones/caixas no celular | Wrappers de ícones, toque e controles compartilhados presentes; Dynamic Type real permanece pendente. |
| Remover atualização intermitente ao abrir lugar | Estados/objetos de markers estabilizados e indicadores discretos; sem vídeo/aparelho não foi alegada reprodução visual exata. |
| Melhorar a parte abaixo de Sobre este lugar | Card separado, resumo comunitário e fontes compactas; aprovação visual da tela em celular continua necessária. |
| Dar vida com eventos/impactos/avaliações | Exemplos de demonstração existem; base real permanece vazia. Precisa conteúdo verdadeiro e participação, sem publicar feedback inventado. |
| Entregar app que funciona com internet | Projeto Expo/React Native e perfis EAS estão presentes. ZIP/export não são APK/IPA assinado instalado. |

## Matriz dos 63 pontos

**Verificado** significa implementação encontrada e conferida no código/testes locais, não teste físico. **Parcial** identifica implementação com escopo ou validação faltante. **Pendente** é uma execução externa ainda não realizada. **Adiado** é otimização que o próprio pedido deixou para depois.

Distribuição: **43 verificado**, **14 parcial**, **1 adiado**, **5 pendente**.

| # | Ponto | Estado | Evidência e observação |
| --- | --- | --- | --- |
| 1 | Paleta central | Verificado | Tokens centralizados; cores de conquistas também corrigidas nesta revisão. `constants/theme.ts` · `features/community/progress.ts` |
| 2 | Raios | Verificado | Escala 8/12/20/pill; exceções geométricas de pins/ilustrações permanecem. `constants/theme.ts` · `components/shared/Buttons.tsx` |
| 3 | Linguagem dos cards | Parcial | Base compartilhada presente; sombras e densidades ainda variam em cards específicos. `constants/theme.ts` · `components/impacts/ImpactStatCard.tsx` |
| 4 | Textos de 10/11 | Verificado | Nenhum fontSize 10/11 em telas/componentes/features; escala mínima centralizada. `constants/theme.ts` · `tests/app-flows.mjs` |
| 5 | Largura das páginas | Verificado | pageContent unifica telas; painéis do mapa têm largura própria intencional. `components/shared/FeaturePage.tsx` · `components/map/PlaceCard.tsx` |
| 6 | Headers | Verificado | PageHeader compartilhado; barra do mapa é uma composição específica. `components/shared/PageHeader.tsx` · `features/map/MapScreen.tsx` |
| 7 | Botões | Verificado | Variantes e TouchFeedback comuns; wrappers de conta usam a mesma base. `components/shared/Buttons.tsx` · `components/AccountForm.tsx` |
| 8 | Formulários | Verificado | Field compartilhado com foco, erro, desabilitado e sucesso; ícones não escalam como texto. `components/shared/FormControls.tsx` · `components/InputField.tsx` |
| 9 | Função do botão central | Verificado | Participar segue a decisão posterior do usuário e abre as duas ações distintas. `components/BottomNavigation.tsx` · `components/ParticipationSheet.tsx` |
| 10 | Nome das enquetes | Verificado | Enquetes na área pública e no admin; mensagens antigas do banco são traduzidas no cliente. `app/eventos.tsx` · `lib/errors.ts` |
| 11 | Resultados antes do voto | Verificado | SQL e UI restringem resultados até voto ou encerramento no servidor. `supabase/migrations/20261020133648_community_scopes_poll_visibility.sql` · `tests/community-db.mjs` |
| 12 | Copy dos votos | Verificado | Porcentagem usa dos votos. `components/events/PollCard.tsx` · `tests/production-flows.mjs` |
| 13 | Alertas x relatos | Verificado | Navegação/título públicos usam Relatos; rota antiga alertas permanece compatível. `app/alertas.tsx` · `components/BottomNavigation.tsx` |
| 14 | Hierarquia do relato | Verificado | Destaque identificado como Relato mais recente, sem inventar ranking de gravidade. `components/alerts/AlertCards.tsx` · `services/reports.ts` |
| 15 | Relato próprio pendente | Verificado | Indicação de autoria e verificação nas telas próprias; feed público não apresenta pendências como publicadas. `app/registro.tsx` · `features/reports/OwnRecordsScreen.tsx` |
| 16 | Inbox canônica | Verificado | Perfil e Relatos abrem a mesma rota de notificações. `app/perfil.tsx` · `app/alertas.tsx` |
| 17 | Escopo das contagens de Impactos | Verificado | Números pessoais separados do painel público da cidade. `services/improvements.ts` · `tests/community-db.mjs` |
| 18 | Escopo da lista de Impactos | Verificado | Seções e identificação própria diferenciam pedidos pessoais e melhorias públicas. `app/impactos.tsx` · `components/impacts/ImprovementCard.tsx` |
| 19 | Cores de status | Verificado | impactStatus usa statusText/palette como fonte única. `constants/impactStatus.ts` · `components/impacts/ImpactStatCard.tsx` |
| 20 | Participar e sheet | Verificado | Círculo de 56 por 56, duas opções com ícones/copy e transição com redução de movimento. `components/ParticipationSheet.tsx` · `hooks/useSheetTransition.ts` |
| 21 | Impactos dentro de Mapa | Verificado | Relação explicitada por Mapa › Impactos e ação de voltar ao mapa. `app/impactos.tsx` · `app/_layout.tsx` |
| 22 | addLabel | Verificado | Label visível usa a propriedade e mantém acessibilidade própria. `components/BottomNavigation.tsx` · `tests/production-flows.mjs` |
| 23 | Confirmação genérica | Verificado | Default Confirmar; logout fornece seu texto explicitamente. `components/ProfileDialog.tsx` · `app/perfil.tsx` |
| 24 | APIs mortas | Verificado | useAppData removido; providers compostos ainda usados. SQL legado preservado para clientes antigos; smoke atualizado para RPCs atuais. `providers/AppData.tsx` · `scripts/verificar-mvp.mjs` |
| 25 | Arquivos grandes | Parcial | Mapa e PlaceCard foram divididos; relato, avaliação, eventos, melhoria e admin ainda concentram muita lógica. `features/map/MapScreen.tsx` · `components/impacts/ImprovementRequest.tsx` |
| 26 | PlaceCard | Verificado | 154 linhas com header/media/actions/sources/motion separados. `components/map/PlaceCard.tsx` · `components/map/PlaceHeader.tsx` |
| 27 | Distância no card | Verificado | Um cálculo memoizado por coordenadas/localização. `components/map/PlaceCard.tsx` |
| 28 | Camada de acesso | Parcial | Providers não fazem consultas diretas; ainda há helpers de acesso distribuídos em features além de services. `features/map/CatalogProvider.tsx` · `features/community/community.ts` |
| 29 | Carga antecipada | Verificado | Catálogo regional e fatores são carregados quando usados; não no login global. `features/map/CatalogProvider.tsx` · `tests/architecture-flows.mjs` |
| 30 | Paginação | Verificado | Frontend ativo usa cursor; RPCs de OFFSET antigos seguem só por compatibilidade. Smoke corrigido para o caminho atual. `services/pagination.ts` · `tests/cursor-db.mjs` |
| 31 | Busca de lugares | Verificado | Normalização, pg_trgm/GIN e busca por similaridade no SQL. `supabase/migrations/20261020142143_spatial_search_service_areas.sql` · `tests/spatial-db.mjs` |
| 32 | Busca administrativa | Verificado | Índices/consultas normalizadas e autorização por tipo de fila. `supabase/migrations/20261020142143_spatial_search_service_areas.sql` · `features/admin/admin.ts` |
| 33 | Geografia de relatos | Verificado | Coluna geográfica, índice GiST e consulta espacial no servidor. `supabase/migrations/20261020142143_spatial_search_service_areas.sql` · `tests/spatial-db.mjs` |
| 34 | Corte de 100 relatos | Verificado | Agregação contabiliza região completa; drill-down paginado de grupos não perde registros por esse limite. `services/reports.ts` · `tests/spatial-db.mjs` |
| 35 | Clusters de relatos | Verificado | Agregação no servidor e expansão/lista por grupo. `features/map/reportClusters.ts` · `tests/spatial-ui.mjs` |
| 36 | Semântica dos markers | Verificado | ReportMarker comum no mapa web e nativo. `components/map/ReportMarker.tsx` · `components/map/CityMap.native.tsx` |
| 37 | Cache espacial | Verificado | Viewport/chave quantizados juntos, com margem para preservar bordas. `features/map/region.ts` · `tests/request-cancellation.mjs` |
| 38 | Seleção no banco | Verificado | SQL ranqueia e retorna até 500 lugares; frontend reduz a apresentação pelo zoom. `services/places.ts` · `tests/spatial-db.mjs` |
| 39 | Importação em background | Parcial | App lê o banco. Job existe, mas seis respostas 503 na última hora vieram de HTTP 406 da fonte; nenhuma importação bem-sucedida registrada. `supabase/functions/catalog-refresh/worker.ts` · `supabase/functions/lugares-osm/network.js` |
| 40 | Múltiplas cidades | Parcial | service_areas e troca de cidade funcionam; piloto só em Criciúma, datas/heurísticas ainda têm referências locais. `services/serviceAreas.ts` · `features/community/dates.ts` |
| 41 | Tiles web | Parcial | Provedor configurável e gate existem; ambiente atual continua no modo piloto OSM. `features/map/web/tileProvider.ts` · `scripts/qa/release-check.mjs` |
| 42 | Política comunitária | Verificado | Regras/metadados vêm do backend e são validados no cliente; 8 avaliações/90 dias cobertos em teste. `supabase/migrations/20261022133600_review_policy_metadata.sql` · `tests/community-db.mjs` |
| 43 | Percepção não é verdade objetiva | Verificado | UI comunica percepções, mínimo e distribuição; não rotula o lugar como perigoso automaticamente. `constants/community.ts` · `components/map/CommunityReviewSummary.tsx` |
| 44 | Eventos em uma viagem | Verificado | pagina_app inclui inscrito; frontend não faz segunda busca de inscrições por página. `features/community/community.ts` · `tests/request-cancellation.mjs` |
| 45 | RPC de Impactos | Verificado | Painel com escopos pessoais/públicos usa uma viagem; API anterior mantida para compatibilidade. `services/improvements.ts` · `tests/community-db.mjs` |
| 46 | Resumo materializado | Adiado | Agregação atual mantida conforme pedido; materialização depende de carga real futura. `supabase/migrations/20261022134052_compact_review_policy_payload.sql` |
| 47 | Cancelamento | Parcial | Mapa/busca/detalhe/resumo cancelam no fetch; Request.signal e Auth temporário corrigidos. Algumas listas ainda só ignoram respostas fora de foco. `lib/request.ts` · `features/profile/usePagedList.ts` |
| 48 | Tamanho dos assets | Verificado | Quatro JPEGs com largura 800 px e cerca de 68–100 KB; sem alteração de identidade nesta revisão. `docs/design/ASSETS.md` · `assets/places/nereu.jpg` |
| 49 | Referências de design | Verificado | PNGs de referência ficam em docs/design, separados dos assets de execução. `docs/design/ASSETS.md` · `docs/design/reference-cadastro.png` |
| 50 | Engine web | Parcial | 362 linhas mais módulos de geometria/drag/tiles e testes; mantém engine própria, sem biblioteca especializada. `components/map/CityMap.tsx` · `tests/web-map.mjs` |
| 51 | Suíte e CI | Verificado | Suíte completa local passou; workflow existe. Nenhuma execução remota de CI foi alegada. `package.json` · `.github/workflows/verify.yml` |
| 52 | E2E físico | Pendente | Fluxos preparados, iOS corrigido para validar build/backend real. Nenhum aparelho conectado nesta revisão. `qa/maestro/flows/01-critical.yaml` · `scripts/qa/ios-device.mjs` |
| 53 | Regressão visual | Parcial | Diff/baseline/CI preparados; metadados/OS reforçados. Nenhuma baseline física aprovada. `scripts/qa/visual.mjs` · `qa/visual/baselines/README.md` |
| 54 | Dynamic Type real | Parcial | Controles adaptam fonte; verificações 130/160 por aparelho ainda não executadas. `components/shared/FormControls.tsx` · `docs/qa/MATRIZ-APARELHOS.md` |
| 55 | Observabilidade de produção | Parcial | Logs Edge confirmados; Sentry sem DSN/recebimento real e alertas externos não configurados. `lib/monitoring/index.ts` · `qa/monitoring-queries.sql` |
| 56 | Carga no Supabase | Pendente | k6 preparado e protocolo local testado; não há execução de 500 usuários no staging. `qa/load/read-flows.js` · `docs/qa/CARGA.md` |
| 57 | FPS/RAM de Android médio | Pendente | Coletor/procedimento presentes; sem medições físicas. `scripts/qa/perf-android.mjs` · `docs/qa/MATRIZ-APARELHOS.md` |
| 58 | Build de produção instalada | Pendente | Exports e prebuild anterior passam; faltam assinatura/instalação, chaves/configuração e ícone final de distribuição. `eas.json` · `docs/qa/BUILD-E-OBSERVABILIDADE.md` |
| 59 | Recuperação real de conta | Pendente | Fluxo por código isolado e HTTP com timeout; e-mail/SMTP e login final em produção não testados. `services/account.ts` · `docs/qa/MATRIZ-APARELHOS.md` |
| 60 | Backup/restauração real | Parcial | Scripts e exercício local com 20 migrações passam; restauração gerenciada remota continua pendente. `scripts/operations/backups.mjs` · `tests/restore-drill.mjs` |
| 61 | Retenção da idempotência | Verificado | 30 dias, hold justificado, lotes, fingerprint e cron ativo; primeira execução automática bem-sucedida observada com tabela vazia. `supabase/migrations/20261022163527_operational_retention_and_moderation.sql` · `tests/operational-growth.mjs` |
| 62 | Operação administrativa | Parcial | Fila/revisões/histórico/permissões presentes; lotes, atribuição e gestão auditada de papéis ainda no backlog. `features/admin/AdminScreen.tsx` · `docs/operations/PAINEL-ADMIN.md` |
| 63 | Push real | Parcial | Cliente/outbox/worker prontos; envios desativados, sem cron de entrega/credenciais e sem recebimento físico. `services/push.ts` · `docs/operations/PUSH.md` |

## Arquivos ainda grandes

| Arquivo | Linhas atuais |
| --- | --- |
| `features/map/MapScreen.tsx` | 498 |
| `components/map/CityMap.tsx` | 362 |
| `features/reviews/ReviewForm.tsx` | 437 |
| `components/impacts/ImprovementRequest.tsx` | 513 |
| `components/map/PlaceCard.tsx` | 154 |
| `app/novo-relato.tsx` | 479 |
| `app/eventos.tsx` | 431 |
| `features/admin/AdminScreen.tsx` | 413 |
| `features/map/PlacePicker.tsx` | 344 |

## Próximo trabalho que fecha lacunas reais

Resolver a ingestão do catálogo; configurar staging, EAS/credenciais/ícone, Sentry e push com autorização operacional; cadastrar conteúdo verdadeiro; executar a matriz em Android/iPhone e aprovar baselines. Depois validar SMTP/recuperação, carga de 500 usuários e restore remoto. Continuar decompondo os formulários/telas grandes sem reescrever regras já testadas.

Nenhum item pendente foi marcado como aprovado para deixar o relatório verde. A matriz legível por ferramenta está em `qa/prompt-audit.json`; evidências de lançamento continuam em `qa/release-evidence.json`, separadas desta revisão de código.
