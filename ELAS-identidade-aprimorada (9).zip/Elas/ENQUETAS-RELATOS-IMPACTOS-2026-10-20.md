# Enquetes, relatos e impactos — 20/10/2026

As correções dos pontos 11–20 foram implementadas preservando a identidade visual do ELAS e o fluxo Participar.

| Ponto | Comportamento entregue |
| --- | --- |
| 11 | Enquetes abertas ocultam contagens, percentuais e barras até a conta votar. Enquetes encerradas liberam resultados também para quem não votou. |
| 12 | A interface e os rótulos de acessibilidade usam “25% dos votos”. |
| 13 | A área e a navegação agora se chamam Relatos; o feed contém ocorrências verificadas, sem transformar toda ocorrência em alerta. |
| 14 | O destaque informa “Relato mais recente”. O texto explica a ordem cronológica e que ela não indica gravidade. |
| 15 | Pendentes ficam em Meus relatos, identificados como “Seu relato · aguardando verificação”, com aviso de que só autor e equipe têm acesso. Detalhes repetem a explicação; o mapa mantém o rótulo de relato próprio. |
| 16 | Relatos e Perfil abrem a mesma tela Notificações. A inbox embutida e o seletor sem consumidores foram removidos. |
| 17 | Os três números do cabeçalho pertencem apenas a Minhas solicitações. A cidade tem dois números próprios: Em andamento e Concluídas. |
| 18 | Listas pessoais e públicas aparecem em seções separadas, com rótulos “Sua solicitação” e “Melhoria pública da cidade”. Cada seção leva ao histórico correspondente. |
| 19 | `constants/impactStatus.ts` concentra texto, cor e fundo por chave de estado, usando os tokens do tema. Cards, estatísticas e estados das listas usam essa fonte. |
| 20 | Participar permanece circular, com opções distintas para avaliar e relatar, descrições curtas e transição que respeita redução de movimento. O fluxo existente foi preservado e seus testes passaram. |

A terminologia Enquetes também foi uniformizada nas telas administrativas.

## Contratos e privacidade

A migração `20261020133648_community_scopes_poll_visibility.sql` foi aplicada ao projeto conectado. O schema passou para **7**, com **13 migrações**, e o frontend exige essa versão. Não há SQL adicional a executar neste projeto.

A proteção dos resultados acontece no banco. `pagina_app('enquetes')` e a API legada `listar_enquetes` retornam `votos: null` antes de a conta votar ou a enquete encerrar. A projeção confere autenticação, publicação, voto da conta e horário do servidor. Consultar votos diretamente continua restrito aos próprios votos. A interface não libera resultados só por sucesso local ou pelo relógio do aparelho; falhas de envio mantêm os resultados ocultos e permitem tentar novamente. Ao chegar ao prazo, o card pede atualização ao servidor; também há atualização manual quando necessária.

`painel_impactos()` retorna `minhas` e `cidade` separadamente, em uma leitura. Números pessoais incluem solicitadas, em andamento e concluídas da conta atual; retiradas ficam fora desse painel e continuam no histórico pessoal. Números públicos incluem apenas em andamento e concluídas. Cada lista recente é limitada a 20, sem limitar as contagens. Uma melhoria própria já pública pode aparecer nas duas seções; os universos estão explicitamente identificados. Identificadores de autores não são retornados.

O feed e o histórico público solicitam `publicas: true`, com filtro aplicado antes da paginação. Pendentes próprios continuam acessíveis pela área pessoal. As políticas existentes não foram ampliadas. APIs legadas foram mantidas para compatibilidade; o antigo `resumo_impactos` continua disponível para clientes antigos e não é consumido por esta versão.

Trocar de conta, sair ou receber uma resposta atrasada não reaproveita os números pessoais anteriores. Exemplos fictícios continuam explicitamente identificados e fora das estatísticas reais.

## Verificação

- `npm run verify`: passou, incluindo tipagem, lint, banco, paginação por cursor, interação, arquitetura, mapa, demonstrações, atualização atômica e desempenho.
- Testes adicionais cobrem neutralidade visual e acessível das enquetes, falha/reenvio, bloqueio de toque duplicado, voto/alteração/encerramento, proteção das duas APIs, escopos de contagem, feed público, conta diferente e respostas atrasadas.
- O SQL de atualização foi regenerado a partir das migrações canônicas por `node scripts/generate-update.mjs`. O teste confirma rollback de falha tardia e duas execuções sem duplicar histórico nem perder dados.
- Leitura autenticada no banco remoto confirmou os contratos novos e o bloqueio de execução anônima. Não foram cadastradas pessoas, votos, relatos ou melhorias reais para testar.
- Preservados os 1.535 lugares, três relatos, zero avaliações reais e zero solicitações reais existentes antes da migração.
- Exportação Expo concluída para Android, iOS e web. São bundles, sem APK/IPA assinado.

Os testes de componentes usam hosts nativos simulados; não medem geometria, teclado nem animação em aparelhos. Validação visual em Android/iPhone, monitoramento e teste de carga continuam pendentes. Esta entrega não equivale a validação para lançamento em escala.

O diagnóstico de segurança manteve os avisos anteriores: quatro tabelas internas com RLS sem políticas e proteção contra senhas vazadas desativada. Referências: [RLS sem políticas](https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy) e [proteção de senhas](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection). Não foi alterada a configuração de autenticação.

O diagnóstico de desempenho manteve uma FK antiga sem índice e índices sem uso registrado. Referências: [FK sem índice](https://supabase.com/docs/guides/database/database-linter?lint=0001_unindexed_foreign_keys) e [índices sem uso](https://supabase.com/docs/guides/database/database-linter?lint=0005_unused_index).
