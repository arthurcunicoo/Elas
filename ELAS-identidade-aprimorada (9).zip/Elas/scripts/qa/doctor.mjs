import {spawnSync} from 'node:child_process';
const available=binary=>!spawnSync(binary,['--version'],{encoding:'utf8',timeout:10000,env:{...process.env,SUPABASE_TELEMETRY_DISABLED:'1',DO_NOT_TRACK:'1',MAESTRO_CLI_NO_ANALYTICS:'1',K6_NO_USAGE_REPORT:'true'}}).error;
const report={node:process.versions.node,platform:process.platform,tools:Object.fromEntries(['adb','maestro','k6','psql','supabase','xcrun'].map(name=>[name,available(name)])),configured:{staging:!!process.env.QA_SUPABASE_URL,qaAccount:!!process.env.QA_EMAIL&&!!process.env.QA_PASSWORD,sentry:!!process.env.EXPO_PUBLIC_SENTRY_DSN,eas:!!process.env.EAS_PROJECT_ID}};
console.log(JSON.stringify(report,null,2));if(!report.tools.adb&&!report.tools.xcrun)process.exitCode=1;
