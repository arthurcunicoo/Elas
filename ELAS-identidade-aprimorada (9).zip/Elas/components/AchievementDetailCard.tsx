import { colors, palette, radius, typography } from "../constants/theme";
import { StyleSheet, Text, View } from "react-native";
import Ionicons from "./icons/Ionicon";
import MaterialCommunityIcons from "./icons/CommunityIcon";
import { Achievement } from "../constants/achievements";

import { AchievementProgressBar } from "./AchievementProgressBar";
import { MotionReveal } from "./MotionReveal";
export function AchievementDetailCard({
  item,
  index,
}: {
  item: Achievement;
  index: number;
}) {
  return (
    <MotionReveal duration={320} delay={index * 45} distance={12}>
      <View style={styles.card}>
        <MaterialCommunityIcons
          name={item.icon}
          size={30}
          color={item.color}
          style={styles.icon}
        />
        <View style={styles.detail}>
          <Text style={styles.title}>{item.title}</Text>
          <Text style={styles.description}>{item.description}</Text>
          {!item.completed && (
            <AchievementProgressBar
              value={item.value}
              total={item.total}
              delay={index * 45 + 130}
            />
          )}
        </View>
        {item.completed && (
          <MotionReveal duration={280} delay={index * 45 + 100} distance={0}>
            <Ionicons
              name="checkmark-circle"
              size={25}
              color={palette.successFill}
              accessibilityLabel="Conquista concluída"
            />
          </MotionReveal>
        )}
      </View>
    </MotionReveal>
  );
}
const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.white,
    borderRadius: radius.large,
    paddingHorizontal: 12,
    paddingVertical: 12,
    minHeight: 60,
    gap: 9,
    shadowColor: palette.overlay,
    shadowOpacity: 0.09,
    shadowRadius: 9,
    shadowOffset: { width: 0, height: 3 },
    elevation: 3,
  },
  icon: { width: 36, flexShrink: 0, textAlign: "center" },
  detail: { flex: 1, minWidth: 0 },
  title: {
    fontSize: typography.input,
    lineHeight: 22,
    color: colors.wine,
    fontWeight: "600",
  },
  description: {
    fontSize: typography.secondary,
    color: colors.wine,
    marginTop: 2,
    lineHeight: 18,
  },
});
