# ELAS — ajustes para celular e densidade do mapa

Esta atualização parte do ZIP anterior com seleção por relevância. Mantém a paleta, os prédios, a logo, as carinhas, as rotas e os fluxos de dados existentes.

## Alterações

- Ícones Ionicons e MaterialCommunityIcons passam por componentes pequenos e separados, preservando o carregamento de cada família. As métricas de altura, linha, alinhamento e preenchimento Android ficam explícitas; ícones não encolhem nas linhas. Os textos comuns continuam respeitando a ampliação de fonte do sistema.
- Controles de voltar, fechar, filtros, localização e zoom têm caixas centralizadas nos pontos revisados. Caixas de eventos, alertas, favoritos, conquistas e menus não disputam largura com textos longos.
- Navegação inferior: espaços regulares, botão central proporcional em telas estreitas, rótulos com largura limitada ao espaço disponível e realce ativo preservado. As animações continuam respeitando a preferência de redução de movimento.
- Eventos: cartões com mais espaço, descrição mais legível, ícone em uma caixa maior e ação com largura suficiente. O seletor Eventos/Consultas segue o formato arredondado de Avisos/Notificações.
- Alertas: cartão principal branco com borda suave, hierarquia de texto mais limpa e ícone com espaço próprio. Notificações mantêm ponto de não lida e borda suave, com ação de leitura alinhada.
- Perfil e conquistas: ícones de menu uniformes, texto com espaço para quebrar linha e cartões de conquistas arredondados. A estrutura do perfil existente foi preservada.
- Diálogos aparecem perto da base em telas de até 500 pontos, com ação principal preenchida. Em larguras menores que 360 pontos, as ações ficam empilhadas. Mensagens longas mantêm rolagem e áreas seguras.
- Nas telas menores que 350 pontos, as quatro carinhas da avaliação podem ocupar duas linhas, preservando os desenhos e rótulos originais.

## Mapa menos cheio

A exibição completa começa no nível de aproximação geográfica 18,5, em vez de 17. Isso corresponde a cerca de 2,8 vezes mais aproximação linear que na entrega anterior. O cálculo usa uma referência geográfica de 390 pontos, para um tablet ou navegador largo não liberar as lojas menores antes do celular.

Antes desse nível, a seleção considera prioridade, distância entre os marcadores e um limite proporcional à área da tela. Em uma tela de referência 390 × 700, o orçamento fica em torno de cinco a nove pontos nos níveis 15 a 18, antes de considerar coincidências e lugares elegíveis. Categorias continuam utilizáveis com o mesmo controle de densidade. Um lugar escolhido explicitamente permanece visível.

A versão web permite agora chegar ao zoom 19, mantendo tiles da área visível. No nível de detalhe completo, portas sobrepostas continuam agrupadas. Os marcadores nativos têm margem na imagem usada para sua animação.

Busca em lista, favoritos e dados persistidos não foram removidos. A regra de seleção do servidor é a mesma; a mudança de densidade acontece no cliente. Não há migration ou atualização manual do banco nesta etapa.

## Referências consultadas

- [Profile and settings UI Mobile App — Harunur Rashid, Dribbble](https://dribbble.com/shots/26532779-Profile-and-settings-UI-Mobile-App): referência pública de perfil/configurações, com grupos de opções e hierarquia compacta. Nenhum asset foi copiado para o app.
- [Tamanho da área de toque — Android](https://support.google.com/accessibility/android/answer/7101858?hl=pt): controles com espaço ao redor do ícone; recomendação de 48 dp.
- [Text — React Native](https://reactnative.dev/docs/text): propriedades de texto e ampliação de fonte. A dependência local de ícones já desabilita ampliação por padrão; o ajuste acrescenta métricas explícitas e preserva a ampliação dos rótulos.
- Mobbin retornou apenas a página pública sem as telas; Awwwards não respondeu às consultas nesta sessão. Não são tratados como referências visuais efetivamente inspecionadas.

## Verificação e limites

TypeScript, ESLint, testes de mapa/relevância, desempenho/cache, estado e limites dos painéis passaram. Novos testes cobrem a ausência de lojas menores no zoom intermediário, exibição em nível de rua, elegibilidade em tablet, densidade de categorias e seleção explícita. Exportação web, Android e iOS passou.

Não houve captura válida do app em execução: o navegador desta sessão recebeu `ERR_CONNECTION_REFUSED` ao abrir a prévia local. Portanto, isto é uma revisão de código com pesquisa de referências e testes, não uma auditoria visual concluída. Não se afirma que todos os ícones foram conferidos em um Android/iPhone. Fonte ampliada, gestos, leitura de tela e recorte dos marcadores ainda precisam de conferência em aparelho.

## Abrir

Extraia o ZIP, entre em `Elas`, rode `npm ci` e `npx expo start --clear`. No navegador, use `npm run web`.
