# Operação da moderação

O painel abre relatos pendentes; cada área seleciona seu filtro inicial de análise. Busca com debounce, filtros e cursor continuam no servidor. A lista mostra registros carregados, ordem dos mais recentes, carregamento incremental, botão de próxima página e tentativa após erro. O número carregado não é apresentado como total da cidade.

`fila_moderacao` reaproveita a paginação e acrescenta a revisão de cada item. `moderar_revisao` trava a linha e compara uma revisão inteira antes de usar a regra de moderação. Edição do autor ou mudança A → B → A invalida decisão antiga. Conflito não cria histórico/notificação: a tela fecha o editor, recarrega e pede nova leitura. Na classificação de lugares, o snapshot é o timestamp emitido pelo banco, sem conversão por `Date`.

Regras preservadas: usuário comum não acessa fila; moderador atua em relatos/melhorias; avaliações e catálogo exigem administrador; ninguém aprova conteúdo próprio. Decisão aceita registra motivo/histórico. APIs antigas continuam para instalações anteriores; clientes novos usam revisão. Um cliente antigo continua checando status/categoria, sem a nova proteção por revisão.

## Rotina mínima

1. Revisar filtros, contexto, histórico e lugar vinculado antes de decidir.
2. Informar motivo claro. Após conflito, conferir conteúdo atualizado antes de escolher novamente.
3. Em dúvida de permissão, interromper a decisão. O badge do frontend não autoriza ações.
4. Registrar erros, idade da fila e necessidade de escalonamento. `qa/operations-queries.sql` permite monitorar agregados.

## Papéis

`private.papeis` continua restrita à operação do banco. `user_metadata` não concede papéis. Cadastros não promove usuários. Antes de uma mudança, identificar a conta pelo UUID/identidade, registrar papel anterior/novo, motivo, responsável e chamado. Conferir que permanece pelo menos um administrador ativo; aplicar/verificar a transição em transação e validar com a conta destinatária. Uma sessão aberta não substitui a autorização atual consultada por RPC.

Não foram adicionados editor de papéis, histórico próprio de mudanças de papéis nem trava automática do último administrador. Esses itens permanecem no backlog.

## Próximos incrementos

- Atribuição/reserva de revisão e métricas de idade/tempo de fila.
- Lotes pequenos, revisão individual, resultado por item e proteção contra retry.
- Fluxo administrativo de papéis com histórico e proteção do último administrador.
- Painel operacional separado quando equipe/fila justificarem.

Os testes validam permissões e conflitos por snapshots/revisões em PostgreSQL local. Não substituem dois moderadores em aparelhos reais simultaneamente.
