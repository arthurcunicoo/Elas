# Execução das seis frentes de backend — 27/10/2026

Esta entrega continua a revisão administrativa do **Liquid Glass v7**, SHA-256 de base `0f95e4bf9bf191f2edc0d7589aa2b7a7552657f34ed498774b50a7436ddc1e93`. Não usa um pacote antigo como base. Assets, identidade visual, onboarding e dependências do app foram preservados.

**Há implementação nova testada localmente, mas a ativação em produção não foi concluída.** A criação de staging pelo conector falhou duas vezes com `Invalid or expired requestState`. A verificação posterior retornou nenhuma branch. Não houve cobrança confirmada, implantação de função, alteração de papéis, envio de e-mail/push, exclusão de conta ou aplicação de SQL em produção nesta rodada.

| Frente solicitada | Implementado/verificado nesta entrega | Situação online |
| --- | --- | --- |
| 1. Duas migrations pendentes | Migrações de exclusão e jitter testadas junto com as três novas; atualização transacional gerada e testada com repetição e rollback | Continuam pendentes no banco real, respeitando a validação prévia em staging pedida pelo usuário |
| 2. Catálogo e atomicidade | Worker ativo no código usa um único RPC para gravar, registrar origem/recibo e finalizar a reserva; replay limitado do mesmo lote; reserva vencida não grava; escrita direta de service_role revogada | Worker novo ainda não implantado. A fonte externa continua recusando chamadas com HTTP 406; importação ao vivo não foi restabelecida |
| 3. Exclusão de conta | Handler, guards e testes preservados; último administrador recebe recusa explícita antes de revogar sessões ou remover arquivos; opção permanece desativada | Falta staging, migrations e implantação de account-erasure antes de ativar o app |
| 4. Gestão de administradores | Tela Equipe e permissões, busca/paginação, concessão/revogação, motivo obrigatório, histórico, conflito otimista e proteção do último administrador no banco | Código pronto para homologação; tabela/RPCs novos ainda não existem em produção |
| 5. Operação real | Logs reais do importador analisados; runner de permissões com três contas de staging; preflight sem expor credenciais; backup registra versão consultada em vez de hardcode | E-mail/deep link, sessões reais de QA, carga, crash reporting e restauração remota continuam sem validação |
| 6. Push | Cliente/outbox/worker e testes de protocolo existentes preservados; quatro Edge Functions passaram na checagem Deno | Não ativado: projeto/credenciais Expo e aparelhos não estão disponíveis neste ambiente; sem prova de entrega física |

## Implementação

**Catálogo:** `supabase/functions/catalog-refresh/index.ts` deixou de fazer upsert seguido de finalização separada. `ingestion.ts` valida origem, licença, hash, data, tamanho, duplicações e limites; prepara um lote imutável e reconcilia IDs. `confirmar_catalogo_ingestao` trava a reserva, grava lugares e proveniência, conclui o job e registra um recibo na mesma transação. Alteração inválida ou falha de finalização reverte o lote. Um ACK perdido permite apenas um replay idêntico no handler; se a confirmação continuar incerta, não se marca o job como falho às cegas. Recibos têm retenção limitada. Correções manuais e dados já salvos permanecem protegidos.

A revogação de INSERT/UPDATE/DELETE diretos de service_role em lugares impede que o worker antigo contorne a proteção. Por isso o cutover exige **pausar e drenar workers antigos antes de aplicar a migration**, e só reativar após publicar e verificar o novo worker. Não existe fallback para o caminho inseguro.

**Administração:** a nova rota `admin-equipe` participa do mesmo grupo protegido das outras rotas administrativas e mantém uma segunda verificação na tela. Somente admin pode usar os novos RPCs; user_metadata não concede papéis. Um contador privado atualizado condicionalmente impede que remoções concorrentes deixem zero administradores. Triggers cobrem mudanças diretas na tabela e exclusão pelo Auth; iniciar a exclusão do último admin também é recusado em transação. O histórico é privado, com responsável, papel anterior/novo e motivo; exclusão de contas anonimiza referências. O primeiro administrador de um staging vazio deve ser cadastrado pela operação confiável, nunca por autopromoção do app.

A contagem protege a existência do papel admin; não certifica que o único administrador tenha senha/e-mail recuperáveis. Isso integra a validação operacional.

O backend completo retorna versão **12**. As telas comuns continuam compatíveis com a versão 11 atual; recursos novos mostram feedback de atualização quando seu RPC ainda não existe. As permissões limitadas já existentes dos moderadores no backend foram mantidas. O painel e a gestão de equipe exigem admin.

**Backup:** o manifesto passou a registrar a versão lida do banco. Selagem sem versão tem `null`, nunca uma versão presumida. A restauração bloqueia backup sem versão comprovada e continua proibindo o projeto de produção. Isso melhora o procedimento; não constitui uma restauração remota executada.

## Evidência externa e bloqueios

O projeto conectado permanece com 20 migrations; o pacote contém 25. As duas anteriores pendentes são `20261025213938_account_erasure_controls.sql` e `20261025214404_catalog_job_jitter.sql`. As três novas foram criadas pelo CLI 2.122.0, com telemetria desativada:

1. `20261027142216_atomic_catalog_ingestion.sql`.
2. `20261027142217_backend_capabilities.sql`.
3. `20261027142305_admin_roles_audit.sql`.

Os logs reais na janela padrão de 24 horas mostraram **144 chamadas de catalog-refresh, 144 falhas HTTP 5xx e p95 de aproximadamente 2,18 s**. Os eventos da fonte registram HTTP 406. Uma consulta pública mínima feita a partir deste ambiente expirou sem resposta em 20 segundos. Nenhum desses resultados demonstra a causa exata da recusa, nem sucesso do importador novo em produção.

Os responsáveis do Overpass documentam recusa de aplicações e regras de identificação/carga. Não foram usados spoofing de User-Agent, rotação de identidade ou troca automática de instância após 406. A recuperação exige acesso autorizado à fonte ou uma fonte/extração operada de forma apropriada. Não houve contratação de provedor. [Discussão dos responsáveis](https://github.com/drolbr/Overpass-API/issues/791).

A integração Supabase está instalada e habilitada, mas a criação da branch falhou no fluxo de solicitação. Não foi demonstrado que a causa seja falta de permissão OAuth. Não foi tentada mudança nas permissões globais da integração.

O preflight encontrou indisponíveis neste ambiente: destino/chave de staging, três contas QA, caixa de recuperação, Sentry, projeto/token Expo, conexão/material de backup e destino descartável de restauração. Valores de credenciais não são incluídos nas evidências. Não há integração Expo/EAS ou Sentry disponível no catálogo consultado.

## Validação

Resultados e limitações ficam em `qa/backend-completion-evidence/`.

- Suíte automatizada, incluindo os testes novos de administração e ingestão atômica. O lint mantém três avisos anteriores, com zero erros.
- Checagem Deno 2.9.6 das quatro Edge Functions, usando o SDK já instalado e sem baixar dependências durante a checagem.
- PostgreSQL isolado: RLS/grants, RPCs, atualização idempotente e rollback, reservas substituídas/vencidas, ACK perdido, origem/licença/hash, preservação manual e retenção.
- Administração: bloqueio de autopromoção, moderação limitada, concessão/revogação auditadas, conflito otimista, remoção do último admin por RPC/tabela/Auth/exclusão, anonimização e paginação.
- Restauração local com banco novo e metadados/bytes separados. Não é backup gerenciado ou restore remoto do Supabase.
- O runner `qa:staging-permissions` exige três contas reais, recusa produção antes de criar clientes e não gera evidência aprovada sem executar. Não foi executado contra staging nesta rodada.

PGlite serializa as transações locais. Intenções concorrentes locais não substituem conexões independentes, carga real, Auth/Storage completos ou aparelhos. A exportação web também não certifica navegação nativa ou push físico.

O roteiro de implantação está em `docs/operations/ROLLOUT-BACKEND.md`. **Não aplicar o pacote diretamente em produção para contornar a ausência de staging.**
