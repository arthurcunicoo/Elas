# Conteúdos de demonstração — 15/10/2026

O banco utilizado pelo aplicativo é o Supabase. A estrutura e os 25 conteúdos abaixo já foram gravados no projeto existente. Não é necessário executar SQL manualmente nesta base.

## O que aparece no app

| Área | Quantidade | Onde conferir |
| --- | ---: | --- |
| Eventos | 4 | Eventos → Em aberto |
| Impactos | 6 | Impactos na cidade; dois exemplos em cada etapa |
| Avaliações | 15 | Detalhes de cinco lugares no mapa; três avaliações por lugar |

Os lugares com avaliações são Praça Nereu Ramos, Praça do Congresso, Parque das Nações, Shopping Della e Criciúma Shopping. Selecione o lugar e expanda seu cartão ou toque no contador de avaliações.

Todo o conteúdo recebe identificação de **DEMONSTRAÇÃO**. Os perfis, experiências, atividades, datas e resultados são fictícios. As avaliações não representam a segurança ou a condição real do lugar e não alteram a classificação dos marcadores.

Na agenda, os exemplos aparecem enquanto não houver eventos reais futuros publicados. O botão **Ver exemplo** abre a descrição; não registra participação. A camada de serviço também bloqueia inscrições em IDs de demonstração. O filtro Histórico consulta somente os eventos reais.

Em Impactos, os exemplos aparecem enquanto a lista real estiver vazia. Os números são identificados como demonstração. Assim que houver solicitações reais visíveis para a conta, a tela usa os registros e contagens reais; a criação de solicitações continua funcionando.

As avaliações demonstrativas são consultadas ao selecionar um lugar, sem reutilizar resultados de outro lugar ou de uma sessão anterior. As avaliações privadas existentes continuam com as mesmas permissões.

## Banco e manutenção

- Nova tabela `public.conteudos_demonstracao`, com leitura apenas para contas autenticadas, linhas ativas e obrigatoriamente fictícias.
- RLS habilitada; os clientes não podem inserir, editar ou apagar os exemplos.
- Migration local e remota: `20261015173653_app_demonstration_content`.
- `supabase/DEMONSTRACAO.sql` contém os 25 exemplos e pode ser repetido sem duplicar registros. As datas fictícias são definidas na primeira execução e não se deslocam ao repetir o script.
- Os quatro eventos foram cadastrados para 17/10, 20/10, 24/10 e 31/10/2026, no fuso de São Paulo. Após essas datas, deixam a agenda futura; não são encontros confirmados.
- Para ocultar um exemplo, uma conta de manutenção autorizada pode definir `ativo=false` nessa tabela.
- O script é específico para os cinco lugares já existentes no catálogo deste projeto. Em uma base nova, aplique as migrations e prepare o catálogo antes de executar esse seed opcional.

As tabelas reais foram preservadas. A conferência remota após a inclusão encontrou 0 eventos, 0 avaliações, 0 solicitações de melhoria, 3 relatos e 0 enquetes, além dos 25 novos exemplos na tabela separada. Não foram criados usuários, relatos, inscrições ou troféus fictícios.

## Verificação

Passaram TypeScript, ESLint, os 120 testes existentes do banco, os novos testes de demonstração e a regressão React de estabilidade do mapa. Os testes novos verificam repetição do seed, permissões por conta, bloqueio de escrita, troca de lugar/sessão, identificação dos exemplos, bloqueio de inscrições fictícias e substituição dos impactos demonstrativos pelos reais.

A API real do Supabase foi testada com a conta de teste: leitura dos 25 registros, três avaliações da Praça Nereu Ramos e quatro eventos futuros. A leitura anônima e a tentativa de edição pelo cliente foram negadas. A sessão criada para essa verificação foi encerrada.

As exportações Android, iOS e web passaram. A execução visual posterior em aparelho/navegador permanece pendente; os testes React usam hosts nativos simulados e não equivalem a uma captura visual.

Para repetir as verificações locais:

```sh
npm ci
npm run typecheck
npm run lint
npm run test:db
npm run test:showcase
npm run test:stability
npx expo export --platform all
```

Para abrir a entrega, extraia o ZIP, entre em `Elas`, rode `npm ci` e `npx expo start --clear`. Entre normalmente na conta para consultar os conteúdos do banco. O modo offline `npm run demo` permanece separado desses exemplos remotos.
