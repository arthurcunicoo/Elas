import { layout } from "../constants/theme";
import { type PropsWithChildren, useEffect, useRef } from "react";
import { type AccessibilityRole, type AccessibilityState, Animated, Platform, Pressable, type StyleProp, type ViewStyle } from "react-native";

import { useReducedMotion } from "../hooks/useReducedMotion";
const AnimatedPressable = Animated.createAnimatedComponent(Pressable);
type Props = PropsWithChildren<{
  onPress: () => void;
  testID?: string;
  label: string;
  selected?: boolean;
  spring?: boolean;
  pressedScale?: number;
  disabled?: boolean;
  busy?: boolean;
  role?: AccessibilityRole;
  checked?: AccessibilityState["checked"];
  style?: StyleProp<ViewStyle>;
}>;
export function TouchFeedback({
  children,
  testID,
  onPress,
  label,
  selected,
  style,
  spring = true,
  pressedScale = 0.95,
  disabled = false,
  busy = false,
  role = "button",
  checked,
}: Props) {
  const scale = useRef(new Animated.Value(1)).current,
    opacity = useRef(new Animated.Value(1)).current;
  const reduced = useReducedMotion(),
    unavailable = disabled || busy;
  useEffect(() => {
    if (unavailable) {
      scale.stopAnimation();
      opacity.stopAnimation();
      scale.setValue(1);
      opacity.setValue(1);
    }
  }, [unavailable, scale, opacity]);
  useEffect(
    () => () => {
      scale.stopAnimation();
      opacity.stopAnimation();
    },
    [scale, opacity],
  );
  function animate(down: boolean) {
    scale.stopAnimation();
    opacity.stopAnimation();
    const native = Platform.OS !== "web";
    Animated.timing(opacity, {
      toValue: down ? 0.72 : 1,
      duration: down ? 45 : 150,
      useNativeDriver: native,
    }).start();
    if (reduced) {
      scale.setValue(1);
      return;
    }
    if (!down && spring)
      Animated.spring(scale, {
        toValue: 1,
        stiffness: 360,
        damping: 19,
        mass: 0.7,
        useNativeDriver: native,
      }).start();
    else
      Animated.timing(scale, {
        toValue: down ? pressedScale : 1,
        duration: down ? 55 : 140,
        useNativeDriver: native,
      }).start();
  }
  return (
    <AnimatedPressable
      testID={testID}
      accessibilityRole={role}
      accessibilityLabel={label}
      accessibilityState={{ selected, checked, disabled: unavailable, busy }}
      disabled={unavailable}
      onPress={() => {
        if (!unavailable) onPress();
      }}
      onPressIn={() => animate(true)}
      onPressOut={() => animate(false)}
      style={[
        { minHeight: layout.touch, justifyContent: "center" },
        style,
        { opacity: unavailable ? 0.65 : opacity, transform: [{ scale }] },
      ]}
    >
      {children}
    </AnimatedPressable>
  );
}
