# ELAS — paginação por cursor

## Entrega

Os pontos 21–29 da revisão já estavam aplicados na versão anterior. Este bloco migra as listas paginadas e a busca do catálogo para keyset, usando a nova RPC `pagina_app`. Os services, `usePagedList` e `usePlaceSearch` recebem `Cursor | null` e retornam `{ rows, nextCursor }`.

Não há mais `.range(page * 20, ...)`, `p_pagina` ou contador de página nos caminhos ativos do frontend. As migrações históricas e as RPCs antigas foram mantidas para compatibilidade com versões instaladas do aplicativo; o frontend novo não as usa.

| Listas | Ordem e limite |
| --- | --- |
| Relatos, melhorias, notificações, registros próprios, histórico, enquetes e publicações | Data de criação e ID, ambos decrescentes |
| Minhas avaliações | Data de atualização e ID, ambos decrescentes, preservando o propósito da lista |
| Favoritos | Data em que foi favoritado e ID do lugar, decrescentes |
| Eventos | Data de início e ID, crescentes |
| Busca de lugares e administração de lugares | Nome e ID, crescentes |
| Administração de relatos, melhorias, avaliações e perfis | Data de criação e ID, decrescentes |

São 18 rotas de listagem. O servidor lê até 21 registros, entrega até 20 e constrói o próximo cursor com o último registro entregue. O registro extra apenas informa se há continuação. O ID desempata datas ou nomes iguais. As datas dos cursores preservam os microssegundos do PostgreSQL, sem passar por `Date` no JavaScript.

O cursor identifica a conta, a lista e seus filtros. Trocar de conta, filtro ou texto de busca reinicia a consulta. A referência temporal das janelas de 24 horas e dos eventos fica fixa durante a sequência de páginas. As autorizações continuam sendo verificadas no servidor; o cursor não concede permissões.

As consultas comuns executam como invoker, sob RLS e os grants existentes. Os modelos que já precisavam de acesso privilegiado — moderação, registros próprios, histórico e totais de votos — usam função privada com as mesmas checagens explícitas de autor/papel das RPCs anteriores. Não houve abertura de tabelas ou exposição adicional de autores e comentários privados.

Foram acrescentados índices compostos correspondentes às ordenações e aos filtros de proprietário/registro. O plano de teste confirmou comparação por tupla em `Index Cond`, sem percorrer um OFFSET. Filtros textuais e RLS ainda têm custo próprio; a migração não é um benchmark de carga nem prova de tempo constante para qualquer consulta.

## Comportamento no app

- Refresh inicia um cursor novo.
- Falha ao carregar mais preserva o cursor e os itens já exibidos; retry tenta a mesma posição.
- Toques repetidos durante uma requisição são bloqueados.
- Respostas atrasadas de outra conta, filtro, busca ou refresh são descartadas.
- A união das páginas remove defensivamente IDs repetidos.
- A busca mantém debounce para mudanças de texto; páginas seguintes carregam pelo cursor.
- Favoritos e lugares preservam o cursor do servidor ao transformar os dados para o formato da interface.
- O overlay espacial de relatos permanece limitado a 100 itens por região. Ele não usa paginação por OFFSET e não foi convertido em uma lista infinita.

## Banco conectado e atualização

A migração `20261020124725_cursor_pagination.sql` já foi aplicada ao projeto conectado. O schema agora é **6**, com **12 migrações**. Os tipos TypeScript foram regenerados a partir desse banco, e o app exige schema 6 para usar a nova API.

As contagens antes/depois ficaram iguais: 1.535 lugares, 3 relatos, 0 avaliações e 0 melhorias reais. A migração adiciona funções e índices; não apaga, recria ou popula os dados existentes.

**Neste projeto conectado, atualize os arquivos do app. Não é necessário reaplicar SQL.**

Para outra instalação, aplique as migrações pendentes antes de abrir este frontend. O `supabase/ATUALIZACAO.sql` foi regenerado como transação única, com trava, checagem de histórico e execução idempotente, para instalações com as seis migrações originais. Não use reset nem seed em um banco com dados reais. As RPCs antigas continuam disponíveis durante a transição dos clientes.

## Verificação realizada

`npm run verify` passou integralmente, incluindo o novo `test:cursor`, TypeScript, ESLint e os testes anteriores de banco, comunidade, formulários, arquitetura, mapa, importação e atualização atômica.

Os novos testes cobrem as 18 rotas, autor/papel, privacidade do histórico e dos votos, filtros, desempates e microssegundos. Um cenário percorre 65 relatos enquanto um novo relato entra e o registro que serviu de limite é apagado: os itens originais restantes não são repetidos nem pulados. Refresh passa a mostrar a inclusão.

Os testes dos hooks verificam cursor idêntico após erro, concorrência de toques, troca de conta/filtro/busca, refresh com resposta antiga pendente, debounce e rejeição de páginas malformadas. A atualização SQL foi executada duas vezes com preservação dos dados e histórico, e uma falha forçada no último bloco comprovou rollback integral.

No banco conectado, uma consulta sob o papel `authenticated` percorreu duas páginas reais do catálogo: 20 + 20 lugares, com zero IDs repetidos. As contagens e a versão do schema também foram verificadas após a aplicação.

`npx expo export --platform all` concluiu os bundles de Android, iOS e web. Após regenerar os tipos e alinhar o nome local da migração ao histórico remoto, TypeScript e o teste de atualização atômica passaram novamente.

O comando `supabase migration list --local` não conseguiu conectar à instância Docker local, ausente neste ambiente. O histórico remoto foi consultado diretamente, o arquivo local foi alinhado à versão aplicada, e a execução local foi verificada em PostgreSQL via PGlite com Auth/Storage simulados.

## Limites

Keyset evita o deslocamento de páginas causado por inclusões/remoções anteriores ao cursor. Alterações na própria chave de ordenação, como renomear um lugar ou atualizar uma avaliação, ainda podem mover um item durante uma navegação. Refresh obtém o estado atualizado; não foi criada uma transação de snapshot mantida entre requisições.

O diagnóstico de segurança permaneceu igual ao anterior: informações sobre tabelas internas sem políticas e um aviso preexistente de proteção contra senhas vazadas desativada. Referências: [RLS sem políticas](https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy) e [proteção de senhas](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection). Não houve ampliação de acesso nessa migração.

O diagnóstico de desempenho também registra uma FK antiga sem índice em `private.publicacoes_historico.responsavel_id` e índices ainda sem uso, inclusive os recém-criados para tabelas sem dados. Referências: [FK sem índice](https://supabase.com/docs/guides/database/database-linter?lint=0001_unindexed_foreign_keys) e [índices sem uso](https://supabase.com/docs/guides/database/database-linter?lint=0005_unused_index). Avaliar uso real antes de remover índices.

Continuam pendentes monitoramento, teste de carga e validação em aparelhos reais. Os testes automatizados e bundles não equivalem a um lançamento público validado em escala.
