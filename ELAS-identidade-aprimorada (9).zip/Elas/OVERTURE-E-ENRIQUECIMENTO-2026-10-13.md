# Catálogo Overture e dados dos lugares — 13/10/2026

## Resultado aplicado

O app consulta agora o catálogo combinado persistido no Supabase: OpenStreetMap, Overture Places e revisões de fontes oficiais. Não houve troca do componente nativo de mapa nem da identidade visual. Nenhuma conta, relato, avaliação ou favorito foi removido.

| Medida | Resultado real |
| --- | --- |
| Recorte baixado | 6.618 registros Overture Places, release 2026-09-23.1 |
| Área | Longitude -49.39 a -49.34; latitude -28.72 a -28.66, em Criciúma |
| Selecionados após os filtros e a revisão | 1.381 registros; 21 vínculos a lugares existentes e 1.360 novas entidades |
| Registros físicos inseridos | 1.362; dois foram posteriormente conciliados por alias após a verificação das categorias de farmácias |
| Total no banco | 1.535 linhas de lugares, incluindo aliases e itens ocultos |
| Destinos visíveis | 1.520 lugares |
| Duplicatas confirmadas conciliadas | 4, mantendo os IDs antigos como aliases |
| Itens que não são destinos | 11 canteiros de avenida ocultos do catálogo; linhas preservadas |
| Endereços revistos em fontes oficiais | 6 |
| Endereços genéricos complementados por correspondência Overture | 10 |
| Fotos reais identificadas e incluídas | 3, com autoria, licença, data e cópia local de fallback |
| Sobreposições mantidas fora da importação | 18, listadas em data/overture-revisao-pendente.json |
| Endereços genéricos ainda visíveis | 98; não receberam números ou ruas presumidos |

Os 173 IDs anteriores continuam existindo. As três contas Auth e os três relatos existentes foram preservados. Na verificação desta etapa, avaliações, favoritos e solicitações tinham contagem zero; não foram criados dados pessoais de teste para preencher telas.

## Causas encontradas e corrigidas

O índice STAC estava acessível por HTTPS, mas o leitor S3 do cliente Python não herdava o proxy usado nessa sessão. A leitura do Parquet falhava com `Could not resolve host` no endpoint S3. O script scripts/overture_download.py passa a configuração de proxy aprovada explicitamente ao PyArrow, mantém TLS e faz download somente dos shards/linhas que intersectam o recorte.

A primeira proteção de 5.000 registros era menor que os 6.618 encontrados. O extrator agora aceita até 20.000 registros para uma área limitada a 0.08 grau por eixo, interrompendo a operação se esse limite for ultrapassado. Não há download do dataset global no aplicativo. O resultado completo é escrito atomicamente, sem anunciar sucesso para um arquivo truncado.

O campo antigo `categories` foi substituído na versão atual por `basic_category` e `taxonomy`. O preparo considera a hierarquia nova e mantém leitura compatível do campo antigo. Categorias específicas como `pharmacy` têm prioridade sobre o pai genérico de comércio, para aparecerem em Saúde.

A tecla Buscar mostra os resultados para escolha explícita, evitando abrir automaticamente um comércio cujo endereço contém o nome da praça pesquisada.

O catálogo do mapa é limitado a 500 lugares por resposta. A ordem alfabética pura podia excluir Nereu Ramos/Congresso de uma área com muitos registros. A consulta agora prioriza parques, fotos revisadas e o catálogo anterior, completa com outros estabelecimentos e avisa sobre cobertura parcial. Buscar no catálogo continua paginado; não é limitado aos 500 pontos carregados no mapa.

## Duplicatas: evidência e preservação

Overture Places não contém dados OSM, conforme a documentação do projeto. Duplicatas podem existir dentro de cada conjunto e também ser criadas ao juntar fontes sem conciliar a identidade. Nome igual sozinho não é prova de duplicação.

| Caso | Evidência | Ação |
| --- | --- | --- |
| Praça do Congresso | Cadastro demonstrativo estava em outra posição; polígono OSM e página municipal identificam a mesma praça | ID congresso preservado, ponto corrigido; ID OSM antigo redireciona ao principal |
| Pomar | Nó OSM está dentro do prédio OSM com mesmo nome e categoria; cerca de 9m do centro | Um destino no catálogo; ambos os IDs preservados |
| Droga Raia | Mesmo nome, mesma categoria específica e pontos OSM/Overture separados por cerca de 2.7m | Fonte GERS vinculada ao ID OSM; demais unidades mantidas separadas |
| O Gral | Site oficial confirma rua, número e sala; ponto Overture a cerca de 12m do OSM | Nome/endereço revisados; fonte GERS vinculada ao ID OSM |
| Unisul | Dois polígonos OSM distintos, sem sobreposição | Mantidos separados; não houve união automática por nome/proximidade |

O servidor resolve aliases em avaliações, favoritos, relatos e solicitações. A função resolver_lugar redireciona links antigos. A busca e o mapa excluem aliases; um refresh OSM não os reativa. O trigger impede alias encadeado e impede unir silenciosamente uma linha com participação vinculada. Os casos conciliados foram conferidos sem vínculos antes da alteração.

## Fotos e endereços

As buscas na web levaram a páginas do Wikimedia Commons que identificam o lugar e permitem reutilização, e a páginas oficiais para os endereços. Não foram copiados thumbnails de busca nem fotos de avaliações sem permissão identificada.

| Foto | Crédito | Licença | Data informada |
| --- | --- | --- | --- |
| Praça Nereu Ramos | Latinov | CC BY-SA 3.0 | 2010 |
| Praça do Congresso | Secretaria de Turismo de Criciúma / Ruy Luiz Machado | CC BY-SA 4.0 | 2013 |
| Parque das Nações | Secretaria de Turismo de Criciúma | CC BY-SA 4.0 | 2023 |

Os arquivos JPEG foram mantidos sem edição. O cartão mostra crédito, data e links para origem/licença. As fotos são históricas e não são apresentadas como registro da aparência atual. Os demais lugares mantêm fallback de categoria; não foram usadas imagens genéricas como se fossem fotos do estabelecimento.

O endereço municipal prevaleceu sobre o Overture para Nereu Ramos e Parque das Nações. No Shopping Della, o site oficial distingue estacionamento e acesso de pedestres; o app usa o acesso de pedestres na Praça Nereu Ramos, 364. O Banco do Brasil foi conferido no site do banco. O Gral foi conferido no site da própria farmácia.

Revisões humanas são protegidas por cadastro_revisao e não são substituídas na atualização de catálogos. Novos dados Overture carregam origem, GERS, release, score e fontes; o score indica confiança de existência, não segurança da usuária. Horários e situação de funcionamento não foram presumidos: operating_status veio nulo nos 6.618 registros deste recorte.

## Dados e atualização reproduzível

- scripts/overture_download.py: extrai recorte versionado com PyArrow, usando o proxy da máquina quando disponível. Dependências opcionais em scripts/overture-requirements.txt, fora do aplicativo mobile.
- scripts/overture_catalog.mjs: filtra registros inválidos, baixa confiança, residenciais, outra cidade, categoria sem mapeamento e endereços insuficientes; concilia nomes, posição e endereço, separando sobreposições para revisão.
- data/catalogo-overture-2026-09-23.1.json: dados preparados e contagens. data/catalogo-proveniencia.json: área, release, hash do download e dos JPEGs.
- data/overture-vinculos-revisados.json: somente correspondências verificadas; não é uma regra geral de juntar nomes parecidos.
- supabase/ATUALIZACAO.sql: atualização de schema repetível, agora com versão 4. A migration nova já foi aplicada no projeto existente.
- supabase/ENRIQUECIMENTO-VERIFICADO.sql: revisões documentadas e aliases; não exclui linhas.
- supabase/IMPORTAR-OVERTURE.sql: importação privilegiada e idempotente por GERS; não é chamada pelo frontend. Para uma instalação nova, executar após schema e enriquecimento. No projeto atual, os dados já estão aplicados.

Um novo recorte/release deve passar por preparo e revisão; não preencher campos por inferência nem unir filiais apenas pelo nome. Este recorte cobre uma parte da cidade, não garante cobertura completa de Criciúma. O OSM permanece como fonte complementar e mantém seus limites de cache, autenticação, área e quota.

## Verificações

Passaram TypeScript, ESLint, 120 verificações de banco em PGlite com Auth/Storage simulados, atualização SQL executada duas vezes localmente, testes de Overture, mapa, estado, limites/transporte OSM e geometria mobile. Passou a exportação Expo Android/iOS/web.

No servidor real: schema 4, importação, contagens, aliases, leitura das fotos e classificação das farmácias conferidos por SQL. A função lugares-osm foi publicada na versão 10 com JWT obrigatório e verificação da conta.

Um login HTTP real com a conta de teste conferiu resolver_lugar, fotos, schema e o catálogo combinado. A resposta final trouxe 500 lugares, incluindo Nereu Ramos e Congresso, com 397 cadastros Overture, e indicou cobertura parcial. O RPC de importação foi negado ao cliente autenticado; a sessão criada para verificação foi encerrada. Os testes não gravaram avaliações, relatos ou favoritos.

Os advisors não apontaram novos problemas nessa estrutura. Permanecem os avisos anteriores sobre as tabelas internas fechadas e a proteção de senhas vazadas do Auth; não houve mudança de plano ou cobrança.

A prévia do ELAS continua inacessível ao navegador desta sessão. Não há auditoria visual concluída em aparelho; GPS, gestos, texto ampliado e o layout final devem ser conferidos no celular. As fotos foram abertas e inspecionadas individualmente.

## Fontes

- [Overture Places](https://docs.overturemaps.org/guides/places/) e [cliente Python](https://github.com/OvertureMaps/overturemaps-py)
- [Nereu Ramos: prefeitura](https://viva.criciuma.sc.gov.br/pontoturistico/6), [Congresso: prefeitura](https://viva.criciuma.sc.gov.br/pontoturistico/7), [Parque das Nações: prefeitura](https://viva.criciuma.sc.gov.br/pontoturistico/23)
- [Shopping Della](https://www.shoppingdella.com.br/), [Banco do Brasil](https://www.bb.com.br/site/pro-seu-negocio/agencias-empresa/), [O Gral](https://www.ogral.com.br/)
- [Foto Nereu Ramos](https://commons.wikimedia.org/wiki/File:Pra%C3%A7a_Nereu_Ramos1.JPG), [foto Congresso](https://commons.wikimedia.org/wiki/File:Pra%C3%A7a_do_Congresso.jpg), [foto Parque das Nações](https://commons.wikimedia.org/wiki/File:Parque_das_Na%C3%A7%C3%B5es_Crici%C3%BAma.jpg)
- [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) e [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Metadados Overture preservam as licenças de suas fontes; [CDLA Permissive 2.0](https://cdla.dev/permissive-2-0/) e [Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0).
