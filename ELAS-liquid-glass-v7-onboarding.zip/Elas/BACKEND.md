> Atualização de apresentação: banco com 21 migrations aplicadas, pacote com 26; apenas a extensão dos exemplos foi aplicada nesta rodada. As cinco migrations do rollout anterior continuam pendentes. [Conteúdo gravado e instruções](APRESENTACAO-ELAS.md).

> Estado atual de 27/10/2026: consulte [a execução do backend](BACKEND-EXECUCAO-2026-10-27.md) e [o roteiro de rollout](docs/operations/ROLLOUT-BACKEND.md). Há cinco migrations pendentes no banco real; não aplicar antes da homologação em staging.

> Busca e mapa preparados para crescimento em 20/10/2026: schema **8**, **15 migrações**, GIN/pg_trgm, PostGIS, clusters de relatos, seleção SQL limitada, cache espacial e cidades configuráveis. O catálogo é lido do banco; atualização periódica ativa a cada 10 minutos. O Overpass retornou HTTP 406 nas tentativas online e a fila agendou retentativas; uma importação externa bem-sucedida não foi confirmada nesta etapa. Veja [ESCALA-BUSCA-MAPA-2026-10-20.md](ESCALA-BUSCA-MAPA-2026-10-20.md) para regras, operação, testes e limites. As notas anteriores abaixo são históricas.

> Enquetes, relatos e impactos revisados em 20/10/2026. Banco conectado no schema **7**, com **13 migrações** já aplicadas. Resultados protegidos antes do voto, área Relatos, inbox única e números pessoais separados das melhorias públicas. Veja [ENQUETAS-RELATOS-IMPACTOS-2026-10-20.md](ENQUETAS-RELATOS-IMPACTOS-2026-10-20.md) para regras, testes, compatibilidade e limites. As notas anteriores abaixo são históricas.

> Paginação por cursor aplicada em 20/10/2026. Banco conectado no schema **6**, com **12 migrações**; frontend exige essa versão. A migração já foi aplicada neste projeto. Veja [PAGINACAO-CURSOR-2026-10-20.md](PAGINACAO-CURSOR-2026-10-20.md) para rotas, testes, compatibilidade e atualização de outras instalações. As notas anteriores abaixo são históricas.

> Atualização de 19/10/2026: avaliações aprovadas agora alimentam resumos reais no mapa; demonstração ficou explícita, interações e assets foram corrigidos. O banco remoto já está no schema **5**, com **11 migrations**. Não execute SQL novamente neste projeto. Veja [REVISAO-PRIORIDADES-2026-10-19.md](REVISAO-PRIORIDADES-2026-10-19.md) para correções, método, testes e pendências. As notas anteriores abaixo são históricas.

> Atualização de 14/10/2026: popup e otimizações do mapa. Consulte [OTIMIZACAO-MAPA-2026-10-14.md](OTIMIZACAO-MAPA-2026-10-14.md) para mudanças, medidas e limites de verificação.

> Atualização seguinte: Overture está integrado ao catálogo. Veja [OVERTURE-E-ENRIQUECIMENTO-2026-10-13.md](OVERTURE-E-ENRIQUECIMENTO-2026-10-13.md) para dados aplicados, schema 4, fotos, aliases e verificações atuais. As seções abaixo registram o estado da entrega anterior.

# Atualização desta entrega — 13/10/2026

**As oito migrations estão aplicadas no projeto remoto, que está ACTIVE_HEALTHY.** O banco responde com versão 3 e o login da conta de teste foi confirmado. ATUALIZACAO.md e VERIFICACAO-ONLINE-2026-10-13.md descrevem o estado atual. As informações históricas abaixo são da base da entrega anterior.


# Banco e configuração — ELAS na Cidade

## Projeto existente

Projeto Supabase: [ELAS na Cidade](https://supabase.com/dashboard/project/pxcbzjxgxdmdayqwpqcj), região sa-east-1. Em 08/10/2026 respondeu **ACTIVE_HEALTHY**.

A entrega usa o banco existente. Nenhuma conta foi excluída, senha alterada ou dado reinicializado nesta atualização. Não execute reset/seed no projeto ativo.

O `.env` inclui somente URL e chave publicável, apropriadas ao cliente. Para outro projeto, copie `.env.example` e preencha esses dois valores. Não coloque service_role, chave secreta, senha de banco ou senha de usuário em EXPO_PUBLIC_*.

## Schema e aplicação

As seis migrations incluídas já constam no projeto ativo:

1. 20260929122801_initial_mvp
2. 20261001133122_reports_improvements
3. 20261001180453_osm_places_catalog
4. 20261001182911_osm_shared_upstream_lease
5. 20261008145118_mvp_evolution
6. 20261008145137_community_features

Não reaplique manualmente o conteúdo dessas migrations ao banco ativo. Para uma instalação nova, aplique-as em ordem com o CLI Supabase; o seed é opcional e deve ser usado apenas em banco separado de desenvolvimento. Os tipos de `lib/database.types.ts` foram gerados do projeto ativo.

Há 16 tabelas públicas: perfis, lugares, fatores, avaliacoes, avaliacao_fatores, relatos, solicitacoes_melhoria, catalogo_osm_cache, favoritos, historico_status, notificacoes, eventos, inscricoes, enquetes, enquete_opcoes e votos. Os papéis ficam em `private.papeis`.

## Acesso e privacidade

| Dados/operação | Permissão |
| --- | --- |
| Perfil e avaliações privadas | Próprio usuário; avaliações não são expostas como comentários comunitários. |
| Favoritos, inscrições, votos e notificações | Dados próprios, com regras de unicidade e operações autorizadas. |
| Relatos/melhorias | Autor acompanha seus registros; demais usuários veem apenas o conteúdo permitido pela moderação. |
| Moderação e histórico | RPC com papel verificado no servidor, motivo, estado anterior/novo e responsável. Autoaprovação bloqueada. |
| Painel e publicação | Moderador/admin conforme a operação; publicação de eventos/enquetes reservada ao admin. |
| Papéis e cache interno OSM | Sem acesso direto do cliente. |

RLS, grants e RPCs fazem a autorização. O botão/rota administrativa é apenas apresentação; user_metadata não concede privilégios. As funções públicas chamam auxiliares restritos com validação de identidade/papel. O cliente não contém credenciais administrativas nem operações de exclusão de contas Auth.

A conta **teste.elas@example.com** já possui papel admin no servidor. Entre com a senha de teste definida anteriormente; ela não está no ZIP. Acesse Perfil → Administração. Não é necessário promovê-la novamente.

## Overpass

A função existente `lugares-osm` está ativa, versão 5, com verify_jwt habilitado e validação da sessão. O código está em `supabase/functions/lugares-osm`.

Mantém consulta QL POST, área delimitada, referência única por tipo/ID OSM, cache compartilhado, lease de atualização, fallback de endpoint, tratamento de 429, limite de resposta e indicação de possível resultado parcial. Atualizações OSM preservam `categoria_app`.

O registro `supabase/overpass-verificacao.json` é histórico. Os testes desta atualização simulam as respostas do transporte e não equivalem a uma nova chamada ao Overpass real.

## E-mail e recuperação

Para validar cadastro/confirmação/recuperação com destinatários reais:

1. Configure SMTP em Authentication → Email no projeto Supabase.
2. Em Email Templates → Reset Password, use o modelo `supabase/templates/recovery.html`, que envia `{{ .Token }}`.
3. Confira expiração/limites de envio e teste recebimento, código vencido, reenvio e nova senha.
4. Faça novo login depois da troca e confira logout/sessão ao reabrir o app.

A recuperação utiliza cliente temporário isolado e espera de 60 segundos para reenvio. O cliente temporário é limpo ao concluir ou abandonar o fluxo. A entrega do e-mail e o fluxo Auth ponta a ponta não foram confirmados nesta atualização.

O advisor do projeto indicou proteção contra senhas vazadas desabilitada: [configuração do Supabase](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection). Os avisos informativos de RLS sem políticas em papeis/cache correspondem ao acesso direto intencionalmente fechado.

## Verificações e recuperação operacional

Os testes PGlite aplicam migrations em banco isolado. A verificação SQL no banco ativo usou dois IDs existentes e JWT claims simuladas; as escritas transitórias foram revertidas com ROLLBACK. Não foi um teste de login HTTP.

`scripts/verificar-mvp.mjs` é uma verificação HTTP somente de leitura, com credenciais por variáveis locais ELAS_TEST_EMAIL e ELAS_TEST_PASSWORD. Não grave essas variáveis no projeto. Nesta execução, o login expirou por timeout; nenhum fluxo Auth foi confirmado por esse script.

`scripts/verificar-rls.sql` requer conexão de operador e duas contas existentes, incluindo uma comum. Faz escritas transitórias e termina com ROLLBACK. Revise a seleção das contas antes de executá-lo em outro banco.

Não há migration nova aplicada nesta atualização. Antes de mudanças futuras, preserve backup e aplique migrations incrementais primeiro num projeto de desenvolvimento. Para desfazer mudanças futuras, prepare uma migration de correção que preserve dados; não faça reset do banco ativo.

Não foram adicionados PostGIS, push, Realtime, contrato jurídico ou infraestrutura empresarial. O volume atual não exigiu esses recursos.

