type Listener = (completed: boolean) => void;
const listeners = new Set<Listener>();
let completed = false;

export function isOnboardingCompleted() {
  return completed;
}

export function completeOnboarding() {
  completed = true;
  for (const listener of listeners) listener(true);
}

export function resetOnboarding() {
  completed = false;
  for (const listener of listeners) listener(false);
}

export function subscribeOnboardingState(listener: Listener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
