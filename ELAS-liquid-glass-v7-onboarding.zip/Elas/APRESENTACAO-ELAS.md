# ELAS pronto para apresentar

Esta versão continua o último pacote revisado, versão 2, sem voltar às primeiras versões do projeto. Os exemplos abaixo já foram gravados no Supabase conectado.

## Abrir

No Windows, extraia o ZIP e abra **Apresentar-ELAS.cmd**, dentro de Elas. O atalho instala as dependências se necessário e abre o Expo com o cache limpo. É necessário Node.js 24 ou superior e internet.

Se havia um Expo antigo aberto, feche-o e reinicie pelo atalho desta versão.

Pelo terminal: `npm ci` na primeira vez e depois `npm run apresentacao`. Você pode abrir no celular pelo QR do Expo ou usar a opção web. O login continua sendo real; não existe um botão que concede papel de administrador.

O atalho desta entrega usa o backend e habilita explicitamente o modo de apresentação. O desenvolvimento também mostra os exemplos; uma exportação comum sem modo presentation continua sem exemplos. O modo offline `npm run demo` é outro fluxo e não deve ser usado para demonstrar permissões reais.

## Conta administradora

A conta existente **teste.elas@example.com** é a única administradora atual. As outras duas contas do banco são usuárias comuns. Nenhum papel ou senha foi alterado nesta entrega, e nenhuma conta adicional foi criada no Auth.

O endereço ditado no áudio ficou ambíguo. A pergunta de confirmação não recebeu resposta; portanto não foi promovido um endereço presumido. Se o endereço pretendido for outro, ele precisa ser informado por escrito antes de mudar as permissões.

O papel é consultado no banco pelo ID autenticado. Não há regra de administrador baseada em um e-mail escrito no frontend, nem em metadados editáveis pela própria conta. Menu e rotas exigem o papel admin. Para apresentar a diferença, entre na conta admin, abra Perfil → Administração, saia e entre em uma conta comum: a entrada administrativa não aparece.

Os testes no banco conectado confirmaram que o admin executa o resumo e a fila de moderação, enquanto as duas contas comuns foram recusadas no resumo administrativo. Contas autenticadas leem os exemplos; acesso anônimo foi recusado. Esses testes usam papéis e claims transacionais no PostgreSQL; não são um teste de login por senha em aparelho.

## Conteúdo já gravado

| Conteúdo de demonstração | Quantidade |
| --- | ---: |
| Eventos futuros | 8 |
| Impactos | 9: três por etapa |
| Avaliações de exemplo | 30: seis em cada um de cinco lugares |
| Enquetes | 3: duas abertas e uma encerrada |
| Relatos | 6 |
| Total | 56 |

Os eventos foram renovados para datas futuras, no fuso America/Sao_Paulo. Reexecutar supabase/DEMONSTRACAO.sql renova apenas estes IDs de exemplo, sem duplicação. Isso deve ser feito pela operação confiável do banco caso a apresentação ocorra depois das datas.

Para ver as avaliações, abra no mapa Praça Nereu Ramos, Praça do Congresso, Parque das Nações, Shopping Della ou Criciúma Shopping e expanda as avaliações de demonstração. Dados reais, quando disponíveis, continuam tendo prioridade sobre os exemplos.

Em Enquetes, use **Simular voto**. Os resultados de exemplo aparecem depois da simulação ou quando a enquete está encerrada. Nenhum voto simulado é enviado ao RPC de votação real. Em Relatos, os exemplos são identificados como fictícios e o botão abre o local usado no exemplo; não afirma que houve uma ocorrência verificada ali.

Em Impactos, quando não houver dados reais, o cabeçalho mostra o acompanhamento de exemplo com identificação de demonstração, sem uma sequência de zeros. Os números continuam separados das solicitações reais. Assim que houver dados reais, as telas priorizam esses dados.

## O que foi alterado no banco

Foi aplicada somente a migration **20261028010052_presentation_content_types**, que amplia a tabela existente de demonstração para enquetes/relatos e acrescenta dados estruturados. As permissões e políticas existentes foram preservadas. Depois foram atualizados/adicionados os 56 exemplos em conteudos_demonstracao.

As tabelas reais mantiveram as mesmas contagens observadas antes da operação: zero eventos, zero enquetes, duas avaliações, três relatos e zero solicitações de melhoria. Os exemplos não representam participação de pessoas reais, obras realizadas ou evidência de segurança de lugares. Não foram enviados e-mails, notificações ou push.

O banco agora tem 21 migrations aplicadas; o pacote contém 26. As cinco migrations da implantação anterior continuam pendentes de staging. A administração básica já existente funciona; a gestão avançada de papéis do backend 12 continua dependendo desse rollout. A ingestão do catálogo, exclusão de conta e ativação de push não foram implantadas como parte desta preparação de conteúdo.

## Testes e uso posterior

A suíte automatizada, testes específicos dos exemplos e exportação web foram executados. As evidências ficam em qa/presentation-evidence. O lint mantém os três avisos anteriores; não surgiram erros novos. Não foi produzido um APK assinado nem realizado teste físico nesta entrega.

A apresentação usa o banco real com exemplos explicitamente identificados. Os perfis EAS de produção mantêm EXPO_PUBLIC_SHOWCASE=0. Para uma publicação web normal, use EXPO_PUBLIC_APP_ENV=production e EXPO_PUBLIC_SHOWCASE=0; os exemplos exigem desenvolvimento ou modo presentation explícito. O perfil EAS presentation permite uma build interna com identificação de apresentação; depende das credenciais nativas já necessárias ao projeto. Desligar o modo de apresentação não remove dados reais nem altera permissões.
