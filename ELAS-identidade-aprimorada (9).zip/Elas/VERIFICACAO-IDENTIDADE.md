# Diagnóstico, alterações e validação

Data: 08/10/2026. Base: ELAS-avaliacao-com-carinhas(1).zip. Requisitos: ha.md.

## Ajuste seguinte: avaliação unificada

O botão central das abas abre a rota avaliar. Sem seleção, a tela pede o nome do lugar e apresenta resultados com categoria/endereço. Escolher um resultado incorpora o formulário existente na mesma rota, preservando carinhas, fatores e comentário. No mapa com seleção, a busca é pulada.

Trocar lugar desmonta o formulário anterior e reinicia seu estado. As respostas atrasadas são ignoradas ao desmontar; um comentário escrito para A não é usado na avaliação de B. O carregamento da avaliação própria existente continua usando a mesma consulta e a mesma gravação transacional. Concluir/voltar retorna à tela de origem, incluindo Alertas.

A busca é paginada e tem retry, carregamento e estado vazio; também oferece abrir o mapa ou criar relato. O modo demonstrativo pesquisa os lugares locais somente quando o backend não está configurado. Não houve mudança de dependências, schema ou dados do banco.

Verificação do ajuste: TypeScript e ESLint passaram; exportação Android/iOS/web conferida. Uma consulta no banco ativo, com papel authenticated e JWT claims simuladas, encontrou o ID nereu para a busca Nereu. Isso verifica o catálogo/RPC existente, não comprova interação visual ou login HTTP. A prévia visual continua sem captura neste ambiente.

## Diagnóstico e decisões

| Prioridade | Problema/necessidade | Resultado |
| --- | --- | --- |
| P0 | Versão anterior alterava a identidade rejeitada pelo usuário | ZIP escolhido retomado como base. Assets, tema, skyline, logo, carinhas e navegação originais preservados. |
| P0 | Perfil e nome do mapa podiam divergir | ProfileProvider usa perfis como fonte persistida e atualiza após edição; sessão e papel separados do catálogo. |
| P0 | Catálogo global limitado arbitrariamente e contexto amplo | Carga por região, cache limitado com TTL, proteção contra respostas atrasadas/troca de conta e hooks por domínio. |
| P1 | Busca/relatos e posições fixas do mapa | Escopo área/catalogo explícito, listas paginadas/virtualizadas, relatos filtrados por área e período; cabeçalho/painéis medidos. |
| P1 | Falta de acompanhamento/admin | Favoritos, registros próprios, histórico, painel e moderação com permissão no servidor. |
| P1 | Eventos/consultas/notificações/progresso fictícios | Persistência e contagens reais; estado vazio quando não há registros. |
| P1 | Verificação externa incompleta | Limites de HTTP, SMTP, navegador e aparelho explicitados abaixo. |

## Preservação comprovada no código

Comparação SHA-256 com a base enviada, registrada em baseline-visual.json:

- As cinco imagens de referência/cidade permaneceram idênticas.
- constants/theme.ts permaneceu idêntico.
- CitySkyline, Logo, BottomNavigation e MoodSelector permaneceram idênticos.
- AccountForm, AccountLink, AuthScreen, InputField, PrimaryButton, TouchFeedback, MotionReveal e ReferenceCrop permaneceram idênticos.
- ProfileHeader, ProfileMenuItem, ProfileDialog, ProfileDestination, AchievementDetailCard, AchievementProgressBar, AnimatedTabSelector, ImpactStatCard e ImprovementCard permaneceram idênticos.

Alguns componentes receberam lógica/dados/ações adicionais mantendo seus estilos de origem: cartão do lugar, filtros, cards de eventos/enquetes e conquistas. O motor do mapa recebeu agrupamento, pan/zoom web e localização sob demanda. As novas páginas adotam os componentes e cores da base.

A comparação de arquivos não é prova de que todas as telas tenham aparência idêntica em execução. A conferência visual final ainda precisa ocorrer no aparelho.

## Funcionalidades reais e demonstração

Com a configuração Supabase incluída, o app lê/grava no projeto existente. Conteúdo vazio não gera dados fictícios. O modo demo existe apenas sem configuração e apresenta aviso global.

As avaliações/comentários permanecem privados ao autor. O app não transforma poucas avaliações ou relatos em garantia objetiva de segurança. Fotos indisponíveis usam fallback; não foram inventadas fotografias de estabelecimentos.

As conquistas usam os nomes/ícones originais com critérios verificáveis: 5 avaliações, 3 votos, 10 locais avaliados, 3 solicitações e 20 locais avaliados. Não há contagem fictícia de “avaliações úteis”.

## Resultados desta entrega

| Verificação | Resultado e alcance |
| --- | --- |
| TypeScript | Passou: tsc --noEmit. |
| ESLint | Passou, sem avisos. |
| Banco local | 85 verificações em PGlite, com papéis Auth simulados: migrations, RLS, privacidade, moderação, histórico, favoritos, votos/inscrições e paginação. |
| Mapa | 27 verificações de categorias, filtros, agrupamento, seleção e distância. |
| Estado | 11 verificações de cache/TTL/limite, seleção e respostas atrasadas após logout/troca de conta. |
| OSM | Parser, cache, autenticação, QL POST, fallback, quota, truncamento e limites passaram com fixtures/transporte simulados. |
| Expo | Exportação final Android, iOS e web passou. |
| Banco ativo | ACTIVE_HEALTHY; seis migrations presentes, 167 lugares, 3 contas Auth, 0 avaliações/eventos/enquetes na consulta realizada. Conta de teste já era admin. |
| Permissões no banco ativo | Verificações com IDs existentes e JWT claims simuladas passaram; todas as escritas de fixture foram revertidas. |
| Login HTTP | Tentativa com a conta de teste expirou por timeout; não confirma nem invalida a senha. |
| Interface em execução | Navegador bloqueou o endereço da prévia; não houve capturas da versão final. |

Não houve exclusão/reset de contas, alteração de senhas, nova promoção administrativa, redeploy da função Overpass nem reaplicação de migrations.

## Pendências concretas

- Validar SMTP e entrega real dos códigos de confirmação/recuperação.
- Conferir telas, teclado, navegação de volta, GPS, gestos, texto ampliado e TalkBack/VoiceOver em aparelho.
- Upload de avatar ainda não implementado; nome/avatar persistidos existentes são lidos do perfil.
- Cache de catálogo é em memória; não há rascunhos offline persistentes, mapas offline ou notificações push.
- Medição de fluidez e cobertura OSM real da cidade ainda não realizada.

## Roteiro de teste no celular

1. Faça login, reabra o app e confira a sessão. Altere o nome em Perfil e confira o mesmo nome no mapa.
2. Em Mapa, arraste/zoom, filtre parques/restaurantes e alterne busca na área/catalogo. Abra um ponto e expanda o card.
3. Em Alertas, toque em +, busque Nereu e escolha a praça. Confira que as quatro carinhas aparecem na mesma tela. Troque de lugar e confira que campos não persistidos foram reiniciados. Conclua uma avaliação e confira o retorno a Alertas. Repita pelo mapa com lugar selecionado, onde o formulário deve abrir diretamente. Abra Minhas avaliações, edite e confirme que continua uma por lugar.
4. Favorite o lugar; retorne pela lista de favoritos. Negue GPS e confira que a navegação manual continua disponível.
5. Envie um relato e uma melhoria vinculados opcionalmente ao lugar. Confira status e histórico nas listas próprias.
6. Com outra conta autorizada, modere com motivo. Confira publicação para usuários comuns e notificação/histórico para o autor. O autor não deve aprovar seu próprio registro.
7. No admin, publique um evento e uma enquete. Na conta comum, inscreva/cancele e vote; confira unicidade e contagens.
8. Teste conexão indisponível, toques repetidos, logout/troca de conta e recuperação de senha. Nenhum erro deve aparecer como envio concluído.

## Entrega

Projeto completo com fontes, assets, lockfile, migrations, tipos, testes e documentação. Sem node_modules, cache Expo, bundles de exportação, senhas de teste ou chaves privadas.

