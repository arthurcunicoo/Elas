> Busca e mapa preparados para crescimento em 20/10/2026: schema **8**, **15 migrações**, GIN/pg_trgm, PostGIS, clusters de relatos, seleção SQL limitada, cache espacial e cidades configuráveis. O catálogo é lido do banco; atualização periódica ativa a cada 10 minutos. O Overpass retornou HTTP 406 nas tentativas online e a fila agendou retentativas; uma importação externa bem-sucedida não foi confirmada nesta etapa. Veja [ESCALA-BUSCA-MAPA-2026-10-20.md](ESCALA-BUSCA-MAPA-2026-10-20.md) para regras, operação, testes e limites. As notas anteriores abaixo são históricas.

> Enquetes, relatos e impactos revisados em 20/10/2026. Banco conectado no schema **7**, com **13 migrações** já aplicadas. Resultados protegidos antes do voto, área Relatos, inbox única e números pessoais separados das melhorias públicas. Veja [ENQUETAS-RELATOS-IMPACTOS-2026-10-20.md](ENQUETAS-RELATOS-IMPACTOS-2026-10-20.md) para regras, testes, compatibilidade e limites. As notas anteriores abaixo são históricas.

> Paginação por cursor aplicada em 20/10/2026. Banco conectado no schema **6**, com **12 migrações**; frontend exige essa versão. A migração já foi aplicada neste projeto. Veja [PAGINACAO-CURSOR-2026-10-20.md](PAGINACAO-CURSOR-2026-10-20.md) para rotas, testes, compatibilidade e atualização de outras instalações. As notas anteriores abaixo são históricas.

> Revisão de arquitetura e participação em 20/10/2026: Participar circular, relação Mapa/Impactos explícita, MapScreen e PlaceCard divididos, consultas extraídas e fatores sob demanda. Escopo e testes em [ARQUITETURA-E-PARTICIPACAO-2026-10-20.md](ARQUITETURA-E-PARTICIPACAO-2026-10-20.md).

> Design system aplicado em 20/10/2026: paleta e raios centralizados, cabeçalhos e cards padronizados, botões e campos compartilhados e ação central Relatar. Detalhes e limites em [DESIGN-SYSTEM-2026-10-20.md](DESIGN-SYSTEM-2026-10-20.md).

> Atualização de 20/10/2026: cabeçalhos e controles compartilhados, organização da avaliação e contextos específicos. Veja [UI-COMPONENTES-2026-10-20.md](UI-COMPONENTES-2026-10-20.md) para escopo, testes e pendências.

> Atualização de 19/10/2026: avaliações aprovadas agora alimentam resumos reais no mapa; demonstração ficou explícita, interações e assets foram corrigidos. O banco remoto já está no schema **5**, com **11 migrations**. Não execute SQL novamente neste projeto. Veja [REVISAO-PRIORIDADES-2026-10-19.md](REVISAO-PRIORIDADES-2026-10-19.md) para correções, método, testes e pendências. As notas anteriores abaixo são históricas.

> Interface de aplicativo móvel em 15/10/2026: sugestão de melhoria e escolha de lugar em um painel, eventos com detalhes estruturados, campos e navegação revisados. Veja [UI-APP-MOBILE-2026-10-15.md](UI-APP-MOBILE-2026-10-15.md). O banco continua atualizado; esta etapa não exige SQL.

> Conteúdos de 15/10/2026 já cadastrados no Supabase: 4 eventos, 6 impactos e 15 avaliações fictícias, identificados como demonstração. A estrutura remota também foi aplicada; não é necessário executar SQL. Veja [CONTEUDOS-DEMONSTRACAO-2026-10-15.md](CONTEUDOS-DEMONSTRACAO-2026-10-15.md).

> Correção de 15/10/2026 baseada no vídeo: removido o ciclo entre carregamento e enquadramento do lugar, além do contador solto sob “Sobre a área”. Veja [CORRECAO-MAPA-VIDEO-2026-10-15.md](CORRECAO-MAPA-VIDEO-2026-10-15.md).

> Novo ajuste de 15/10/2026: ícones e controles para celular, refinamento dos cartões/diálogos e mapa com menos pontos no zoom intermediário. Veja [UI-MOBILE-E-DENSIDADE-2026-10-15.md](UI-MOBILE-E-DENSIDADE-2026-10-15.md).

> Atualização de 15/10/2026: seleção de lugares por relevância e zoom, com a função remota já atualizada. Consulte [MAPA-POR-RELEVANCIA-2026-10-15.md](MAPA-POR-RELEVANCIA-2026-10-15.md). Esta etapa substitui o aviso de excesso de lugares e a seleção alfabética anterior.

> Atualização de 14/10/2026: popup e otimizações do mapa. Consulte [OTIMIZACAO-MAPA-2026-10-14.md](OTIMIZACAO-MAPA-2026-10-14.md) para mudanças, medidas e limites de verificação.

> Atualização seguinte: Overture está integrado ao catálogo. Veja [OVERTURE-E-ENRIQUECIMENTO-2026-10-13.md](OVERTURE-E-ENRIQUECIMENTO-2026-10-13.md) para dados aplicados, schema 4, fotos, aliases e verificações atuais. As seções abaixo registram o estado da entrega anterior.

# Atualizar o ELAS na Cidade

Esta entrega usa o frontend de **ELAS-avaliacao-unificada.zip**. Mantém React Native, Expo SDK 55, Expo Router e Supabase. As quatro carinhas, os prédios, a marca e a paleta original permanecem.

## Estado atual — 13/10/2026

**A atualização remota foi concluída.** O projeto foi reativado, voltou a ACTIVE_HEALTHY e recebeu as duas migrations. O banco responde com versão **3** e **oito migrations**. A conta de teste autenticou com sucesso e manteve o papel admin.

Os 173 lugares, três relatos e uma avaliação existentes foram preservados durante a atualização. As verificações de conteúdo temporário foram revertidas. O bucket de avatars está privado, com limite de 5 MB; upload, URL temporária, leitura e bloqueio de acesso público foram testados pela API real. A imagem temporária foi removida.

Nesta base, **não é necessário aplicar SQL manualmente**. Abra o app normalmente; se uma sessão antiga ainda mostrar a tela de atualização, toque Verificar novamente ou reinicie o Expo.

O guia abaixo fica como referência para reaplicação e instalação em outra base. O script verifica o histórico antes de aplicar cada migration.

## Aplicação simples pelo painel

1. Abra o projeto Supabase já utilizado pelo app: **pxcbzjxgxdmdayqwpqcj**.
2. No SQL Editor, abra uma consulta nova. Copie o conteúdo completo de `supabase/ATUALIZACAO.sql` e execute uma vez.
3. A atualização é transacional, preserva dados e registra as duas migrations. Foi testada duas vezes seguidas em PostgreSQL local para confirmar que repetir o mesmo script não reaplica as estruturas.
4. Verifique com a consulta abaixo. A versão deve ser **3**, o bucket deve ser privado e o histórico deve conter oito migrations.
5. No aplicativo, toque **Verificar novamente** ou reinicie o Expo.

```sql
select public.versao_app();
select version, name from supabase_migrations.schema_migrations order by version;
select id, public, file_size_limit from storage.buckets where id = 'avatars';
```

O script é para a base atual que já tem as seis migrations anteriores. Para uma instalação nova, aplique as migrations em ordem. Não execute seed sobre os dados existentes.

As duas migrations incluídas são:

- `20261008182530_app_flow_polish.sql`: envios idempotentes, detalhes, correção/retirada pelo autor, conflitos, gestão de publicações, preservação das correções cadastrais e filtros.
- `20261008182608_private_avatars.sql`: bucket privado, políticas por conta e marcador final de versão.

Também é possível usar o fluxo normal do Supabase CLI com o projeto vinculado e `supabase db push`. O script único já registra o histórico, portanto não use `migration repair` para inventar versões adicionais.

## Executar o aplicativo

Dentro da pasta `Elas`:

```sh
npm ci
npm start
```

O `.env` contém somente a configuração pública do projeto; não contém senha de usuário, chave administrativa ou token de sessão. `.env.example` permite configurar outra base.

Para conferir a interface sem depender da atualização remota:

```sh
npm run demo
# ou no navegador
npm run demo -- --web
```

A integração de catálogo preserva os dados existentes quando o Overpass externo está indisponível. Veja o resultado online em VERIFICACAO-ONLINE-2026-10-13.md.

O modo demo é identificado na interface, usa os dados demonstrativos anteriores e não grava informações no Supabase. As funcionalidades administrativas e uploads reais exigem o banco atualizado e uma conta com o papel correto.

## Verificações

```sh
npm run typecheck
npm run lint
npm run test:db
npm run test:update
npm run test:state
npm run test:map
npm run test:osm
npx expo export --platform all
```

A exportação passou em Android, iOS e web. Isso comprova a geração do bundle; não equivale a um APK/IPA instalado ou teste de aparelho.

Para builds próprios de Android, configure a chave do provedor do mapa conforme as orientações do react-native-maps/Expo; o ZIP não inventa credenciais nem cria serviços pagos. O identificador nativo foi definido como `br.com.elasnacidade.app`. Ícones de distribuição e validação de loja continuam pendentes de revisão com a marca final.
