import { observeEdge } from "../_shared/observe.ts";
import { createClient } from "npm:@supabase/supabase-js@2.117.1";
import { createRefreshHandler, type CatalogLease } from "./worker.ts";
import { reconcilePlaces } from "../lugares-osm/catalog.ts";
const admin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false, autoRefreshToken: false } },
);
Deno.serve(
  observeEdge(
    createRefreshHandler({
      async reserve(hash) {
        const { data, error } = await admin.rpc("reservar_catalogo_job", {
          p_token_hash: hash,
        });
        if (error) throw error;
        return data as CatalogLease | null;
      },
      async import(places) {
        if (!places.length) return;
        const { data, error } = await admin.rpc("candidatos_catalogo", {
          p_lugares: places,
        });
        if (error) throw error;
        const rows = reconcilePlaces(places, data ?? []);
        if (rows.length) {
          const { error } = await admin
            .from("lugares")
            .upsert(rows, { onConflict: "id" });
          if (error) throw error;
        }
      },
      async finish(lease, received, error) {
        const result = await admin.rpc("finalizar_catalogo_job", {
          p_lease: lease,
          p_recebidos: received,
          p_erro: error,
        });
        if (result.error) throw result.error;
      },
    }),
    "catalog-refresh",
    "1.1.0-observability.2",
  ),
);
