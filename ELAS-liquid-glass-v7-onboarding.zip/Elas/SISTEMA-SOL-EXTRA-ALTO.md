# ELAS — revisão técnica Sol Extra Alto (11–22)

Base: última entrega `ELAS-interface-sol.zip`, versão 24. Esta entrega continua essa base; não reinicia o projeto. A identidade visual, CityPulse, debounce de 450 ms, proteção de saída dos rascunhos, cursor, cache/cancelamento e engine de tiles foram preservados. Data da execução: 25/10/2026.

O código e os testes locais avançaram. A tabela diferencia implementação de validação externa: nenhuma migração foi aplicada em produção, nenhuma conta real foi excluída e push permanece desativado. Não é uma declaração de prontidão para lançamento.

## Resultado por tarefa

| Tarefa | Entrega e evidência | Limite de conclusão |
|---|---|---|
| 11 · Dependências | Auditoria inicial/final; atualizações seletivas; decoder corrigido com adaptação CommonJS auditável; instalação limpa e exportação das três plataformas. De 15 alertas (1 crítico) para 7 altos, sem críticos ou moderados. | Os sete alertas restantes estão justificados em `qa/system-evidence/dependencias.md`; ferramentas de desenvolvimento/CI continuam exigindo acompanhamento. |
| 12 · Importação | POST codificado, limites, backoff/jitter apenas para falhas transitórias, preservação de dados, leases e deduplicação. Teste com parser/reconciliação/SQL reais: 5 recebidos, 1 criado, 1 atualizado, 1 duplicado descartado, 2 rejeitados. | Payload HTTP sintético. A consulta externa mínima ainda respondeu 406; o HTML genérico não comprova a causa. Importação ao vivo continua pendente. |
| 13 · Sessões/rascunhos | AES-GCM, chave por entrada em SecureStore no nativo; sessões grandes permanecem criptografadas fora do Keychain. Migração preserva o texto antigo se a nova gravação falhar. Testes de AAD, nonce, perda de chave, serialização e contas. | Migração é por leitura: rascunhos legados ainda não abertos não são migrados antecipadamente. Keychain/Keystore e background precisam de aparelhos reais. No web a proteção tem alcance menor, descrito abaixo. |
| 14 · Exclusão | Confirmação EXCLUIR + senha atual, JWT validado no Auth, lease, revogação, limpeza de avatar e exclusão Auth com cascatas. Conta em processamento é bloqueada por RLS e RPCs elevados; outro usuário é preservado. Rollback local testado. | Feature flag falsa. Falta staging com Auth/Storage reais, política aprovada de retenção, canal operacional de recuperação e validação jurídica. Critério de staging não concluído. |
| 15 · Fusos | Cidade selecionada fornece timezone IANA para eventos, edição e publicação administrativa. Removida construção manual UTC−3. Mantidos UTC e tratamento de horários ambíguos/inexistentes. | Seleção é por conta em memória; antes de selecionar, vale o fuso padrão configurado. Não inventa geolocalização nem altera instantes já persistidos. |
| 16 · Offline | Catálogo público mínimo por projeto/conta, versão 1, até 500 lugares e validade de 7 dias. Consulta isolada pelo SchemaGate, com data e reconexão manual. | Sem tiles offline, resumo comunitário privado ou envio automático. Sem cache anterior válido não há catálogo a mostrar. Sessão não recuperável/expirada pode exigir conexão para login. |
| 17 · SQL/RLS | Planos reais no PostgreSQL isolado, pg_trgm/PostGIS/cursor mantidos; varredura de privilégios; novas guards de conta ativa e migrations/rollbacks. | Busca usou GIN. A consulta geográfica ampla escolheu Seq Scan por retornar 833/834 registros; não foi forçado índice sem evidência. Sem benchmark de produção ou migração remota. |
| 18 · Mapa | Medição JS em 100/500/1500/5000 lugares, testes de cache, cancelamento, markers e tiles preservados. Persistência offline acontece no carregamento de rede, sem repetir em cada cache hit. | Nenhuma alegação de ganho de FPS/RAM. O seletor de markers é o mesmo da base 24; os números de baseline antigo do harness não medem uma melhoria desta entrega. Android/iOS físicos e latência real pendentes. |
| 19 · Autenticação | Persistência protegida; processLock e recovery client isolado mantidos. Testes positivos/negativos de RLS, troca de conta e resultados antigos; conclusão de exclusão não desloga uma nova conta. | E-mail, deep links de produção, renovação real e recuperação em aparelho continuam pendentes. |
| 20 · Push | Revisão dos testes de consentimento, owner, revisão/lease, idempotência, tokens inválidos e recibos. Resposta externa agora limitada a 256 KiB. Conteúdo da tela bloqueada continua genérico. | Entrega real segue desligada. Sem chaves novas, cron ou mensagens reais. App fechado/background exige dispositivos e autorização de ativação posterior. |
| 21 · Formulário | Payload/validação e hook de envio extraídos da rota. Lock de duplo toque, chave estável de tentativa, restauração/debounce e localização aproximada opt-in preservados. Testes de erro, retry, saída e sucesso. | Fluxo permanece em uma tela; não se adicionaram etapas sem evidência de benefício. Tests React usam hosts simulados, não teclado/GPS reais. |
| 22 · Moderação | Cursor, revisão esperada, locks, histórico, papéis e retenção mantidos. Dois intents com a mesma revisão: um commit, um conflito 40001, uma linha de histórico. | PostgreSQL local serializa transações; não equivale a carga com duas conexões reais. Atribuição de casos e ações em lote não foram implementadas nesta entrega. |

## Onde ficam os dados no aparelho

| Categoria | Persistência | Remoção/risco |
|---|---|---|
| Sessão e refresh token | AsyncStorage criptografado; chave AES-256 por entrada no SecureStore, `WHEN_UNLOCKED_THIS_DEVICE_ONLY` | Logout usa a remoção do SDK. Chaves são excluídas após o ciphertext. Perder a chave não autoriza sobrescrever dados cifrados. |
| Rascunhos e tentativa idempotente | Mesmo adaptador; namespace de conta/escopo; debounce e fila anteriores mantidos | Limpeza por conta no logout/fluxos existentes e exclusão. Leitura migra os registros legados; falha conserva o original. Dados antigos nunca acessados podem continuar em texto até abertura/limpeza. |
| Catálogo offline | Somente id, nome, endereço, latitude e longitude; sem comentários, relatos, usuários ou percepções | Namespace de projeto/conta, TTL/versionamento; limpeza no logout/exclusão. Coordenadas são de lugares públicos, não histórico de GPS da pessoa. |
| Push | UUID de instalação e preferência vinculada à conta no AsyncStorage; token no backend conforme consentimento | Desativação/revogação no logout existente; exclusão remove registros do servidor. |
| Estado transitório | Formulários, seleção de cidade, localização e imagens em memória/fluxos existentes | Não foi criado cache de relatos privados ou fila automática offline. Assets de demonstração foram preservados. |

No web, o ciphertext fica em localStorage/AsyncStorage e a CryptoKey não extraível em IndexedDB. Isso protege uma cópia isolada do localStorage; não protege contra JavaScript malicioso na mesma origem, nem contra acesso ao perfil completo do navegador. Não há fallback silencioso para gravação nova sem criptografia. HTTPS/localhost e disponibilidade das APIs criptográficas são necessários. O backup Android gerado exclui as chaves SecureStore; restaurar somente o ciphertext não torna a chave recuperável. Desinstalação, reinstalação, bloqueio do aparelho e encerramento abrupto ainda precisam de validação nativa.

## Exclusão e destino dos dados

A exclusão é uma operação opcional ainda desativada. `EXPO_PUBLIC_ACCOUNT_ERASURE_ENABLED=false` deve permanecer assim até staging. A Edge Function usa o usuário derivado do JWT, ignora IDs enviados pelo cliente e confirma a senha em um cliente Auth temporário. Não registra senha, token ou corpo da solicitação.

A transação Auth remove perfil, avaliações e fatores dependentes, relatos, melhorias, votos, inscrições, favoritos, notificações da própria conta e registros de idempotência pelas FKs existentes. Dados operacionais de push e papéis são revogados ao iniciar. Avatares são removidos antes de Auth; falha nessa etapa mantém a conta restrita e permite nova tentativa após o lease de dois minutos. Outros buckets futuros precisam ser incluídos na política antes de usá-los para dados pessoais.

Histórico cujo sujeito é a conta excluída é removido. Nas decisões da conta sobre registros de terceiros, autoria e motivo são anonimizados; mensagens de notificação propagadas desses motivos são neutralizadas. O recibo de exclusão concluída perde usuário e lease, conservando apenas identificação da operação e datas. Histórico de publicação já tinha FK `ON DELETE SET NULL` para autoria. Conteúdo público de eventos/enquetes e registros pertencentes a outras pessoas não são apagados automaticamente por uma menção textual; pedidos que dependam dessa análise exigem revisão operacional.

Não se promete uma transação única entre Storage e Auth: o fluxo é recuperável, com bloqueio de novas ações enquanto processa. Não existe worker automático de recuperação da exclusão nesta versão. Falhas persistentes precisam de tratamento operacional. Backups, exportações externas, dados já entregues a terceiros e bases de retenção obrigatória precisam de política específica do controlador. A regra existente de 30 dias para payloads de idempotência, com hold justificado e limitado, foi preservada; não constitui uma certificação jurídica de conformidade com a LGPD. A política deve ser aprovada antes da ativação.

## Importação externa

A requisição mínima executada retornou HTTP 406 com HTML nginx genérico. O resultado não diferencia bloqueio do serviço, intermediário de rede ou outra condição. Não foi feito rodízio agressivo para contornar 406/429. Falhas transitórias fazem no máximo uma alternativa com atraso de 500–749 ms; o agendador de jobs conserva backoff de 15 minutos exponencial e recebeu jitter de 0–59 s. Dados válidos permanecem disponíveis se o refresh falhar.

O teste controlado tem HTTP de fixture, mas parser, reconciliação, deduplicação e PostgreSQL reais. Seus números não comprovam a operação ao vivo. O catálogo do app continua consultando o próprio banco, sem fazer a navegação depender de Overpass.

Fontes avaliadas: snapshot OSM/Overpass próprio ou provedor contratado, preservando as obrigações ODbL; e release versionada Overture pelo importador existente, com origem/licença por fonte e atribuições preservadas. Overture Places possui fontes com licenças distintas: não foi assumida uma licença única nem feita importação nova sem conferir sua origem. Não há contratação ou mudança de fonte automática nesta entrega.

Referências primárias consultadas: [Overpass](https://wiki.openstreetmap.org/wiki/Overpass_API), [Overture Places](https://docs.overturemaps.org/guides/places/), [atribuição/licenças](https://docs.overturemaps.org/attribution/), [Expo SecureStore](https://docs.expo.dev/versions/v55.0.0/sdk/securestore/), [Expo Crypto](https://docs.expo.dev/versions/v55.0.0/sdk/crypto/).

## Validação e ativação

Evidências e inventário de alterações ficam em `qa/system-evidence/`. Foram executados instalação limpa, TypeScript, lint, suíte completa, exportação Android/iOS/web com source maps e prebuild isolado. Esses passos não produzem um binário assinado instalado. O prebuild avisou que o ícone iOS não está definido na configuração; isso precisa ser fechado antes da loja.

A revisão automática bloqueou uma conexão de telemetria do CLI Supabase para PostHog, porque o envio não era necessário e o payload/retenção não estavam demonstrados. Não foi repetida essa ação. Os testes de banco seguiram por PGlite local, sem deploy ou validação remota do CLI.

Para homologação: usar projeto staging isolado, aplicar as 22 migrations canônicas ou `supabase/ATUALIZACAO.sql` conforme BACKEND.md, revisar os grants/policies gerados e implantar account-erasure somente nesse ambiente. Testar contas descartáveis A/B, senha inválida, sessão inválida, avatar real, falha parcial/retry, JWT antigo, limpeza local e preservação integral de B. Só depois aprovar política/recuperação operacional e habilitar a flag no build de homologação. A feature flag falsa no frontend não substitui o controle de implantação do endpoint.

Os rollbacks em `supabase/rollback/` foram exercitados localmente. Remover a migration não recupera conteúdo já excluído. O rollback de exclusão recusa jobs pendentes. A reversão deve ser planejada antes de qualquer ativação.

Para liberação ainda faltam: Auth/Storage e importação externa em staging, e-mail/deep links, armazenamento seguro nativo, aparelhos pequenos/intermediários/iPhone, fonte ampliada/teclado, GPS/permissões, background, push autorizado, FPS/RAM, carga real e restauração gerenciada. `qa/release-evidence.json` não foi marcado como aprovado sem essas evidências.
