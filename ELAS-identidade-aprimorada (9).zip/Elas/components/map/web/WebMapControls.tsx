import { useState } from "react";
import { StyleSheet, View } from "react-native";
import { palette, radius } from "../../../constants/theme";
import { TouchFeedback } from "../../TouchFeedback";
import Ionicons from "../../icons/Ionicon";
export function WebMapControls({
  top,
  zoom,
  maxZoom,
  changeZoom,
  pan,
}: {
  top: number;
  zoom: number;
  maxZoom: number;
  changeZoom: (delta: number) => void;
  pan: (dx: number, dy: number) => void;
}) {
  const [panControls, setPanControls] = useState(false);
  return (
    <View style={[styles.controls, { top: top }]}>
      <TouchFeedback
        label="Ampliar mapa"
        onPress={() => changeZoom(1)}
        disabled={zoom === maxZoom}
        style={styles.control}
      >
        <Ionicons name="add" size={22} />
      </TouchFeedback>
      <TouchFeedback
        label="Reduzir mapa"
        onPress={() => changeZoom(-1)}
        disabled={zoom === 10}
        style={styles.control}
      >
        <Ionicons name="remove" size={22} />
      </TouchFeedback>
      <TouchFeedback
        label={
          panControls
            ? "Recolher controles de movimento"
            : "Mostrar controles de movimento"
        }
        onPress={() => setPanControls((v) => !v)}
        style={styles.control}
      >
        <Ionicons name="move-outline" size={20} />
      </TouchFeedback>
      {panControls && (
        <>
          <View style={styles.controlRow}>
            <TouchFeedback
              label="Mover mapa para norte"
              onPress={() => pan(0, -1)}
              style={styles.control}
            >
              <Ionicons name="chevron-up" size={22} />
            </TouchFeedback>
            <TouchFeedback
              label="Fechar controles de movimento"
              onPress={() => setPanControls(false)}
              style={styles.control}
            >
              <Ionicons name="close" size={20} />
            </TouchFeedback>
          </View>
          <View style={styles.controlRow}>
            <TouchFeedback
              label="Mover mapa para oeste"
              onPress={() => pan(-1, 0)}
              style={styles.control}
            >
              <Ionicons name="chevron-back" size={22} />
            </TouchFeedback>
            <TouchFeedback
              label="Mover mapa para leste"
              onPress={() => pan(1, 0)}
              style={styles.control}
            >
              <Ionicons name="chevron-forward" size={22} />
            </TouchFeedback>
          </View>
          <View style={styles.controlRow}>
            <TouchFeedback
              label="Mover mapa para sul"
              onPress={() => pan(0, 1)}
              style={styles.control}
            >
              <Ionicons name="chevron-down" size={22} />
            </TouchFeedback>
          </View>
        </>
      )}
    </View>
  );
}
const styles = StyleSheet.create({
  controls: { position: "absolute", right: 12, gap: 4, alignItems: "flex-end" },
  controlRow: { flexDirection: "row", gap: 3 },
  control: {
    width: 48,
    minHeight: 48,
    flexShrink: 0,
    backgroundColor: palette.surface,
    borderRadius: radius.medium,
    alignItems: "center",
    borderWidth: 1,
    borderColor: palette.border,
  },
});
