import { colors, radius, typography } from "../constants/theme";
import { PageHeader } from "./shared/PageHeader";
import { Image, ImageSourcePropType, StyleSheet, Text, View } from "react-native";
import Ionicons from "./icons/Ionicon";

import { MotionReveal } from "./MotionReveal";
import { TouchFeedback } from "./TouchFeedback";
export function ProfileHeader({
  onEdit,
  avatar,
  name = "Nome Sobrenome",
  email = "nomesobrenome@gmail.com",
}: {
  name?: string;
  email?: string;
  onEdit: () => void;
  avatar?: ImageSourcePropType;
}) {
  return (
    <PageHeader title="Perfil">
      <View style={styles.profile}>
        <MotionReveal duration={340} distance={8}>
          <View style={styles.avatar}>
            {avatar ? (
              <Image source={avatar} style={styles.photo} />
            ) : (
              <Ionicons name="person" size={58} color={colors.pink} />
            )}
            <TouchFeedback
              label="Alterar foto do perfil"
              onPress={onEdit}
              style={styles.edit}
            >
              <View style={styles.editCircle}>
                <Ionicons name="create-outline" size={19} color={colors.pink} />
              </View>
            </TouchFeedback>
          </View>
        </MotionReveal>
        <MotionReveal duration={340} delay={50} distance={8}>
          <Text style={styles.name}>{name}</Text>
          <Text style={styles.email}>{email}</Text>
        </MotionReveal>
      </View>
    </PageHeader>
  );
}
const styles = StyleSheet.create({
  profile: { alignItems: "center", paddingTop: 18, paddingBottom: 38 },
  avatar: {
    width: 88,
    height: 88,
    borderRadius: radius.pill,
    backgroundColor: colors.white,
    alignItems: "center",
    justifyContent: "center",
  },
  photo: { width: 88, height: 88, borderRadius: radius.pill },
  edit: {
    position: "absolute",
    bottom: -4,
    right: -10,
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
  },
  editCircle: {
    width: 32,
    height: 32,
    borderRadius: radius.medium,
    backgroundColor: colors.white,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: colors.wine,
    shadowOpacity: 0.12,
    shadowRadius: 3,
    shadowOffset: { width: 0, height: 1 },
    elevation: 2,
  },
  name: {
    color: colors.white,
    fontSize: typography.page,
    lineHeight: 26,
    fontWeight: "700",
    marginTop: 7,
    textAlign: "center",
  },
  email: {
    color: colors.white,
    fontSize: typography.secondary,
    lineHeight: 19,
    textAlign: "center",
    flexShrink: 1,
    marginTop: 4,
  },
});
