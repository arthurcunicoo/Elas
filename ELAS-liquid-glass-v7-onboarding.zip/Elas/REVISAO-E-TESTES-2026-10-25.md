# ELAS — revisões e testes adicionais (25/10/2026)

Esta entrega continua o pacote `ELAS-sistema-sol.zip`, versão 25, preservando seus 434 arquivos. A autorização para revisar e testar foi usada para ampliar verificações locais e consultar o Supabase conectado. Produção recebeu apenas consultas de leitura e quatro chamadas limitadas que devem ser negadas sem autenticação. Não foram criadas contas reais, enviados e-mails/push, excluídos registros ou aplicadas migrations no projeto real.

## Duas correções encontradas

**Concorrência no armazenamento web.** A fila anterior era local a cada instância JavaScript. Duas abas podiam ler que uma entrada ainda não tinha chave, gerar chaves diferentes e terminar com o ciphertext de uma aba e a chave da outra. Isso inviabilizava a leitura da sessão/rascunho. O mesmo problema podia deixar ciphertext órfão quando exclusão e gravação corriam em abas distintas.

O adaptador web agora mantém a operação completa sob um Web Lock por entrada e por origem: leitura, migração, criação de chave, criptografia, gravação e remoção. A fila local continua existindo. O adaptador nativo mantém o comportamento anterior. Em browser sem a API necessária, a operação falha antes de tocar nos dados; não há fallback para texto sem criptografia. O web exige navegador atualizado em contexto seguro (HTTPS ou localhost). A proteção continua sem impedir XSS na mesma origem.

O teste foi aplicado à implementação da versão 25 e reproduziu erro de descriptografia. A implementação atual passa. Ele usa WebCrypto real e duas instâncias independentes, com um broker de locks simulado. Isso é evidência de regressão da lógica, não prova de execução do Web Locks/IndexedDB em Chrome, Safari ou Firefox. A integração do adaptador web com esse lock também está coberta.

**Diagnóstico sem efeitos externos.** `qa:doctor` executava `--version` em cada ferramenta. Agora verifica arquivos executáveis no PATH, sem iniciar os CLIs, autenticar ou disparar sua telemetria. Os testes cobrem Windows/PATHEXT, arquivo não executável, diretório e ausência do binário. Credenciais aparecem somente como indicadores booleanos de configuração. A checagem informa disponibilidade, não valida versões ou funcionamento dos dispositivos.

## O que foi executado

| Verificação | Resultado | Alcance |
|---|---|---|
| Suíte completa `npm run verify` | Passou | Inclui banco isolado, RLS, cursor, mapa, formulários, storage, cancelamento, retenção, push simulado, recuperação e novos testes. |
| TypeScript e lint | Passaram | Código do app; checagem Edge é separada. |
| Instalação limpa | Passou | `npm ci --ignore-scripts --no-audit --no-fund`, em diretório isolado. Não compila binários nativos. |
| Expo export Android/iOS/web | Passou | Compilação/exportação; não é APK/IPA assinado instalado. |
| Deno 2.9.8 | Passou nas quatro Edge Functions | `lugares-osm`, `catalog-refresh`, `push-delivery`, `account-erasure`; SDK Supabase 2.117.1 já instalado, resolução local, sem alterar lock/config. Não implanta funções. |
| Concorrência de storage | Base 25 falha; atual passa | WebCrypto real, broker simulado; migração/falha/chave perdida/remoção/isolamento. |
| k6 2.3.0 real | Passou | Cinco usuários virtuais, 82 requisições HTTP ao fixture local, zero falhas HTTP; sete contratos. Não mede carga do Supabase. |
| HTTP real sem sessão | Quatro rejeições esperadas | RPC de versão, tabela de perfis, catalog-refresh e push-delivery: 401. A versão também foi confirmada por SQL de leitura. |
| Browser E2E | Bloqueado pelo ambiente | Chromium não conseguiu criar socket interno: `Operation not permitted`. Nenhuma página ou asserção de browser foi executada. |
| Gate de lançamento | Continua reprovado | Faltam configuração de monitoramento/build e evidências físicas; não foram marcadas como concluídas. |

O teste local de protocolo do k6 verifica busca, mapa, resumos, relatos, eventos, impactos e Edge. As latências do fixture não representam o desempenho do banco/usuários reais. O binário foi obtido do release oficial e sua integridade foi conferida pelo digest publicado. Binários e arquivos de sessão dos testes não estão no ZIP.

Playwright 1.62.1 foi adicionado como dependência de desenvolvimento, com lockfile. Também foram preparados `tests/browser-storage.mjs` e seu servidor local: eles testam duas abas reais, IndexedDB, WebCrypto, migração, falhas, nonce, chave não extraível, remoção e cache público. O servidor/compilação/rotas do fixture foram testados por HTTP. A execução do browser permanece bloqueada nesta máquina e não integra o resultado aprovado de `verify`.

Para executar em uma máquina que permita iniciar Chromium: `npm ci`, `npx playwright install chromium`, `npm run test:browser`. Um Chrome já instalado pode ser indicado por `QA_BROWSER_EXECUTABLE`; `QA_BROWSER_OUTPUT` salva o resultado JSON. O servidor é temporário, local e usa somente dados sintéticos. Para tipos Edge, com Deno instalado: `npm run test:edge`. Para protocolo, com k6 instalado: `npm run test:load-protocol` (ou `K6_BIN` apontando para o executável).

## Revisão do Supabase real

O projeto está ativo e tem 20 migrations aplicadas; o pacote mantém 22. A versão contratual continua 11, compatível com o código. As duas migrations novas da entrega anterior ainda não foram aplicadas; exclusão continua desativada e o endpoint não foi implantado. Push também foi confirmado como desativado no banco.

As consultas confirmaram: nenhuma tabela do schema público sem RLS; nenhum grant de tabela privada para anon/authenticated; cache OSM sem SELECT direto para clientes; nenhuma função SECURITY DEFINER pública acessível aos clientes; nenhuma função elevada dos schemas do app sem search_path explícito. Isso verifica configuração, não substitui testes autenticados entre duas contas em staging.

Os oito avisos informativos de RLS sem policy são compatíveis com tabelas de acesso negado aos clientes e uso interno por funções/serviços. Não foi aberta uma policy apenas para zerar o linter. O advisor de performance apontou uma FK sem índice em `private.publicacoes_historico.responsavel_id` e 33 índices ainda sem uso registrado. Não se removeram índices nem se criou uma migration sem um plano/volume que justificasse a mudança.

Há um aviso real: proteção contra senhas vazadas está desativada. A organização está no plano Free; a documentação atual reserva esse recurso para Pro ou superior. Nenhum plano foi alterado ou cobrado. [Configuração e condição do recurso](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection).

O PostgreSQL observado é 17.6. O changelog oficial anuncia 17.11 com correções de segurança e mudanças que pedem revisão. O upgrade gerenciado precisa ser planejado com backup, staging e janela apropriada; não foi iniciado durante testes. `ltree` e `btree_gist` não estão entre as extensões instaladas e não foram encontrados operadores personalizados nos schemas public/private; isso não certifica todo o upgrade. [Changelog e verificações oficiais](https://supabase.com/changelog/postgres-15-19-17-11-breaking-changes).

## Limites que continuam reais

- Não existe staging configurado no projeto/ambiente. Exclusão com Auth/Storage reais, recuperação por e-mail, deep links, concorrência em conexões independentes e carga de backend continuam pendentes.
- Não há Android SDK, dispositivo, emulador ou Xcode disponível. E2E físico, Keychain/Keystore, FPS/RAM, fonte ampliada, teclado, GPS e build assinado não foram simulados como se tivessem ocorrido.
- O Chromium foi obtido de fonte oficial, mas o sistema operacional recusou o socket necessário para inicialização. Não houve tentativa de contornar essa restrição.
- O HTTP 406 do Overpass continua sem causa demonstrada. Esta entrega não afirma ter restabelecido importação ao vivo.
- Auditoria final continua com sete alertas altos e nenhum crítico/moderado. As justificativas individuais da entrega anterior continuam em `qa/system-evidence/dependencias.md`; a nova auditoria está em `qa/revision-evidence/audit.json`.

As evidências desta rodada ficam em `qa/revision-evidence/`. As anteriores foram preservadas como histórico, e `qa/release-evidence.json` permanece com as validações físicas pendentes.

Referência técnica da coordenação entre contextos: [Web Locks API, W3C](https://www.w3.org/TR/web-locks/).
