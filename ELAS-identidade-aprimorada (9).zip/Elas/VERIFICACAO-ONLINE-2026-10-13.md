# Verificação online — 13/10/2026

## Resultado

Projeto ELAS na Cidade reativado e saudável (`ACTIVE_HEALTHY`). As duas migrations pendentes foram aplicadas em uma transação, e o histórico registra oito migrations. A RPC `versao_app` retorna 3, liberando o gate da versão atual do aplicativo.

A atualização preservou 173 lugares, três relatos e uma avaliação existentes. Não foi feita exclusão de contas nem alteração de senha. Tipos TypeScript foram regenerados do banco remoto.

## Verificações executadas

| Verificação | Evidência |
| --- | --- |
| Saúde do Auth | HTTP 200 depois da reativação. |
| Login da conta de teste | HTTP 200, sessão recebida e validada pelo endpoint de usuário. |
| Papel administrativo | RPC retornou admin. |
| Versão exigida pelo app | RPC retornou 3 pela API autenticada. |
| Busca de lugares | HTTP 200 em buscar_lugares. |
| Registros próprios | HTTP 200 em meus_registros. |
| Consultas públicas | HTTP 200 no endpoint novo com filtro de encerradas. |
| Resumo administrativo | HTTP 200 em admin_resumo. |
| Foto de perfil | Upload real de fixture PNG, geração de URL temporária e download: HTTP 200. A leitura pública foi bloqueada e o arquivo temporário foi removido. Não foi alterada a foto existente do usuário. |
| Isolamento de registros | Transação no banco real com duas identidades existentes e role authenticated: uma identidade não acessou nem retirou o registro privado da outra. |
| Envio/gerenciamento | Duplicação impedida, lugar vinculado sem GPS, edição pendente e retirada testados no banco real. |
| Participação | Inscrição e voto repetidos resultaram em um registro por identidade; moderação gerou notificação e leitura do registro correspondente. |
| Preservação | A transação de verificação foi revertida; registros artificiais, votos, eventos e notificações de teste não ficaram no projeto. Sessões HTTP de teste foram encerradas. |
| Código | Tipagem, lint, 106 checks de banco local, script de atualização repetido, checks de estado, mapa e OSM passaram. |
| Bundle | Exportação Android/iOS/web passou. |

As verificações de conteúdo no banco real usaram `set_config` para as identidades em uma transação; não representam interação de dois celulares. As verificações HTTP de autenticação/Storage usaram uma sessão real da conta de teste. Senhas, tokens e URLs assinadas não são distribuídos nesta documentação.

## Overpass: limitação externa confirmada

A função autenticada de catálogo retornou **HTTP 200 e 114 lugares existentes** na área central de Criciúma testada. A cobertura do cache desse recorte foi importada em 01/10/2026. A atualização externa não foi concluída: os servidores públicos retornaram HTTP 406/504 ou timeout. Não se apresenta uma resposta de cache como importação nova bem-sucedida.

O transporte passou a usar o POST documentado com campo `data` codificado, um endpoint de fallback com cobertura mundial e timeout de cliente compatível com as duas tentativas de upstream. HTTP 406/429 interrompe a tentativa, preservando o cache e respeitando o limite, sem alternar servidor para contornar quota. A função foi publicada mantendo autenticação obrigatória e todas as proteções anteriores.

Fonte técnica para formato, instâncias públicas e limites: https://wiki.openstreetmap.org/wiki/Overpass_API

O mapa pode continuar explorando, buscando e avaliando os lugares persistidos. A importação de novos lugares depende de disponibilidade do serviço externo. Não foram contratados serviços pagos, simuladas fotos, inventados estabelecimentos ou removidos dados para mascarar essa condição.

## Validação ainda necessária em aparelho

Não há aparelho disponível neste ambiente. Permanecem pendentes abertura da galeria no dispositivo, gestos/GPS/teclado, fonte ampliada, Android Back, retomada e TalkBack/VoiceOver, além da entrega real de e-mail de recuperação. Upload e autenticação de servidor já foram verificados pela API real. A exportação não comprova uma instalação APK/IPA.
