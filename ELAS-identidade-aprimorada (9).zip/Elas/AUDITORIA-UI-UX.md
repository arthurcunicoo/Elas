# ELAS na Cidade — auditoria e evolução incremental

## Etapa 1 — diagnóstico anterior às alterações

Base: versão Elas-polimento-mobile. Revisão do código e das referências fornecidas, abrangendo boas-vindas, autenticação, perfil, conquistas, mapa/detalhes/filtros, avaliação, alertas, eventos, impactos e rotas demonstrativas. Não é teste visual em dispositivo. Riscos inferidos pelo layout estão identificados como riscos.

### Crítico

| Problema | Onde | Por que | Melhoria planejada | Impacto |
|---|---|---|---|---|
| Botão + absoluto com top -33 dentro de um slot da barra | BottomNavigation | Risco de a parte visível fora dos limites do pai não receber toque nativo; ação principal fica difícil de acionar | Reservar altura para todo o círculo dentro da barra e do slot, mantendo a aparência flutuante | Alto |
| Estilo/padding no Animated.View externo e Pressable apenas no conteúdo | TouchFeedback, todos os botões | A borda/padding aparenta ser clicável, mas o receptor de toque não cobre a mesma região; minHeight externo não garante alvo inteiro | Tornar o próprio Pressable animado o dono do estilo e do espaço de toque | Alto |

### Importante

| Problema | Onde | Por que | Melhoria planejada | Impacto |
|---|---|---|---|---|
| Diálogo central sem ScrollView, limite de altura ou safe area | ProfileDialog | Texto ampliado e telas baixas podem esconder ações de fechar/confirmar | Área segura, altura limitada, conteúdo rolável, ações com quebra de linha | Alto |
| Descrições de 10 e navegação de 9; legenda de progresso de 9 | AlertCards, AchievementCard, BottomNavigation, AchievementProgressBar | Legibilidade fraca no celular | Captions 12, navbar 11, espaçamento proporcional; preservar títulos maiores | Médio |
| Laranja/verde/lilás claros usados em texto pequeno branco sobre branco/fundo claro | MoodSelector, ImprovementCard, ImpactStatCard | Status dependem de cores com pouco contraste; ornamento pode ficar claro, texto precisa ser escuro | Separar cor decorativa de cor de texto de status; manter rótulos explícitos | Médio |
| Margens laterais internas 19 + gap20 com rótulo Notificações de 20 | Tabs de Alertas; Eventos usa 36 de altura | Em 320 de largura, texto pode quebrar sem acomodação; alturas equivalentes diferem | Reduzir inset interno, texto 17, padding e mínimo 44 | Médio |
| Percentuais e opções da enquete na mesma linha sem flexShrink | PollCard | Labels longos ou fonte grande competem com percentuais | Texto principal flexível e percentual preservado | Médio |
| Mostrar senha condicionado a password && icon | InputField | Cadastro usa senha sem icon: não permite conferir o texto; comportamento difere do login | Mostrar ação para todo campo de senha | Médio |
| Estado da seleção mantido separado do placeId da rota | mapa, _layout | Ao remontar, URL pode indicar um local mas o card não estar selecionado; + usa a rota | Inicializar seleção a partir de ID validado e validar antes de navegar | Alto |
| Fade de navegação e de diálogo ignora preferência de movimento | _layout, ProfileDialog | Tratamento de acessibilidade é inconsistente com componentes internos | Remover transição quando redução de movimento estiver ativa | Médio |

### Polimento

| Problema | Onde | Por que | Melhoria planejada | Impacto |
|---|---|---|---|---|
| #BD1C51, #C91E50, #C11B4C sem semântica; superfícies e texto repetidos | theme e telas | Ajustes equivalentes divergem e aumentam manutenção | Expandir theme existente com tokens pequenos; consolidar ações/captions e estilo de cards comparáveis | Médio |
| Participar com minHeight32 | EventCard | Menor que outras ações do sistema | 44 e fonte de ação 14 | Médio |
| Callback de toque usa estado capturado antes de timer | TouchFeedback | Se disabled/busy muda durante o feedback, uma ação antiga ainda pode executar | Ref com estado atual, cancelar/resetar ao desabilitar | Médio |
| Contador chama setState a cada frame, inclusive mesmo número arredondado | ImpactStatCard | Trabalho JS sem mudança visual | Atualizar só quando inteiro mudar | Baixo |
| Título 'Próximos eventos..' | Eventos | Pontuação incompleta reduz acabamento | 'Próximos eventos' | Baixo |

### Preservar e não ampliar escopo

A hierarquia básica já existe: header, tabs, card principal, listas e CTA. Há safe areas nos headers, scroll nas telas e keyboard avoidance nos formulários. Preservar skyline, rosa/vinho, composição dos cards e fluxo pin → detalhes → avaliação. Manter feedback por mola/stagger existente; não acrescentar efeitos decorativos contínuos. Não substituir mapa nem adicionar banco/API/autenticação. Telas demonstrativas continuam demonstrativas.

### Plano de aplicação

1. Corrigir geometria das áreas de toque e ciclo de vida do feedback.
2. Ajustar modal, seleção de rota e acessibilidade de movimento/senha.
3. Aplicar tokens leves, legibilidade, status e tabs responsivas.
4. Verificar TypeScript, exportar plataformas, comparar arquivos e rever imports/estados. Teste visual/gestual e FPS dependem de dispositivo disponível; não declarar esses testes realizados.

## Etapa 2 — implementado

Todos os itens da tabela receberam ajustes no código. Principais refatorações: TouchFeedback usa AnimatedPressable sem camada intermediária; BottomNavigation reserva o espaço do círculo; ProfileDialog limita altura e inclui ScrollView; theme ganhou tokens consumidos pelos componentes existentes. InputField, tabs, cards e indicadores foram ajustados incrementalmente. Nenhum pacote ou rota foi removido.

O feedback por compressão/mola da versão anterior foi preservado no receptor de toque completo; transições agora respeitam redução de movimento também no Stack e no diálogo. Não foram adicionadas bibliotecas de animação nem efeitos contínuos novos.

### Segunda revisão e validação

- TypeScript: aprovado.
- Exportações Metro Android, iOS e web: aprovadas após as alterações.
- Comparação com o ZIP de base: alterações concentradas em 22 arquivos de UI, tema e integração de navegação. Dependências, assets e mapa nativo preservados.
- Tokens de texto de status sobre branco: verde 5,40:1; laranja escuro 5,98:1; atenção 5,85:1; perigo 6,33:1; lilás 5,62:1. Rosa de ação contra branco: 6,09:1. Cálculo de luminância das cores, não medição de screenshots nem certificação de acessibilidade completa.
- Revisão estática: fluxo de parâmetros mapa/avaliação, limpeza de listeners/timers, props de acessibilidade, sombras, alturas mínimas e overflow de modal.
- Não houve teste de execução visual no navegador/Expo Go nesta etapa. Não foi medida taxa de quadros. Gestos, teclado, leitor de tela e texto ampliado ainda precisam de conferência no aparelho.

### Pontos futuros

Foto da praça continua com resolução limitada. Textos menores no card compacto do mapa mantêm a densidade da referência; o card grande continua sendo a leitura principal. Informações pessoais, configurações e consultas permanecem telas demonstrativas. Ajustes finos de fonte ampliada e contraste em estados disabled dependem da inspeção visual, sem promessa de fidelidade pixel a pixel.

### Roteiro curto de validação no celular

1. Tocar no topo, centro e bordas do + e de botões com padding.
2. Selecionar um pin, abrir avaliação, voltar e repetir com outro local.
3. Abrir diálogos em tela pequena e com fonte ampliada; rolar até as ações.
4. Testar tabs de Alertas/Eventos, voto e envio com teclado aberto.
5. Ativar redução de movimento: feedback de opacidade permanece, escala/transições ficam desativadas conforme os componentes.
