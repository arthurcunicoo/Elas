export function cityInstant(date: string, time: string) {
  const instant = new Date(`${date}T${time}:00-03:00`);
  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
    !/^([01]\d|2[0-3]):[0-5]\d$/.test(time) ||
    !Number.isFinite(instant.getTime()) ||
    new Date(instant.getTime() - 3 * 3600000).toISOString().slice(0, 10) !==
      date
  )
    throw new Error("Escolha uma data e hora válidas.");
  return instant.toISOString();
}
export function cityDateParts(iso: string) {
  const p = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date(iso));
  const get = (type: string) => p.find((part) => part.type === type)!.value;
  return {
    date: `${get("year")}-${get("month")}-${get("day")}`,
    time: `${get("hour")}:${get("minute")}`,
  };
}
