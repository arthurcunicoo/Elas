> Apresentação preparada em 27/10/2026: **56 exemplos já gravados no banco**, datas renovadas, enquetes e relatos de demonstração, e atalho Apresentar-ELAS.cmd. A única administradora atual é teste.elas@example.com; papéis e senhas foram preservados. [Como abrir e apresentar](APRESENTACAO-ELAS.md). As notas seguintes registram revisões anteriores.

> Backend de 27/10/2026: worker atômico, gestão auditada de papéis e proteção do último administrador implementados/testados. **Implantação online pendente:** staging falhou no conector; produção permanece com 20 migrations, catálogo com HTTP 406 e push desativado. [Execução das seis frentes e bloqueios](BACKEND-EXECUCAO-2026-10-27.md).

> Revisão de 27/10/2026 sobre o pacote Liquid Glass v7 enviado: menu e quatro rotas administrativas exclusivos de admin, permissões revalidadas e testes de regressão. Banco consultado somente para leitura; duas migrations continuam pendentes. [Situação atual do backend e próximos passos](BACKEND-ADMIN-2026-10-27.md). As notas seguintes registram entregas anteriores.

> Revisões e testes adicionais sobre a versão 25: corrigida corrida de chaves entre abas web; diagnóstico sem executar CLIs; suíte completa, instalação limpa, exportações, tipos Edge no Deno e protocolo k6 verificados. E2E de browser bloqueado pelo sistema; staging e dispositivos continuam pendentes. [Resultados e evidências](REVISAO-E-TESTES-2026-10-25.md).

> Sistema revisado em 25/10/2026 (Sol Extra Alto, tarefas 11–22), continuando a versão 24: armazenamento protegido, exclusão opcional desativada, fusos por cidade, catálogo offline, formulário e proteções de backend. Auditoria: 15 → 7 alertas, sem críticos. [Implementações, evidências e critérios ainda pendentes](SISTEMA-SOL-EXTRA-ALTO.md). Overpass 406 e validações externas continuam abertos.

> Interface refinada em 25/10/2026 (bloco Sol Alto): estados de coleção recuperáveis, skeletons por contexto, filtros administrativos, foco por teclado e ajustes de toque/fonte. [Implementações, testes e validações físicas pendentes](INTERFACE-SOL-2026-10-25.md).

> Modernização de 25/10/2026 sobre a entrega de quinta-feira (versão 22): debounce e salvamento confirmado de rascunhos, listas com revalidação, tiles isolados por provedor, skeletons e datas por fuso. Veja [mudanças, métricas, testes e pendências](MODERNIZACAO-2026-10-25.md). Alertas de dependências e validações físicas continuam pendentes; esta entrega não certifica lançamento.

> Carregamentos atualizados em 22/10/2026: animação exclusiva “Cidade viva”, com pin de coração, ondas e conexões nas cores do ELAS; variantes para abertura, mapa, listas e buscas. [Implementação e validação](CARREGAMENTOS-2026-10-22.md).

> Revisão geral de 22/10/2026: todos os 63 pontos conferidos; correções de rede, push, QA/evidências e consistência aplicadas. [Resultado completo e pendências reais](REVISAO-GERAL-2026-10-22.md). Esta revisão não aprova lançamento.

> Atualização cumulativa de 22/10/2026: retenção de idempotência, revisão da fila administrativa e infraestrutura de push. [Escopo, testes e pendências](RETENCAO-ADMIN-PUSH-2026-10-22.md). O push permanece desativado; as notas anteriores abaixo são históricas.

> Validação operacional preparada em 22/10/2026: E2E Maestro/Appium, regressão visual, Sentry, perfis EAS, carga e backup/restore. Testes locais e logs Edge foram conferidos; aparelhos, baselines físicas, builds assinados, SMTP, carga no staging e restore remoto continuam pendentes. Veja [VALIDACAO-OPERACIONAL-2026-10-22.md](VALIDACAO-OPERACIONAL-2026-10-22.md).

> Revisão de 22/10/2026: schema **10**, **17 migrações** aplicadas. Política comunitária centralizada, resposta compacta, cancelamento das consultas do mapa, tiles web configuráveis, engine organizada e imagens cerca de **78% menores**. Veja [POLITICA-CONSULTAS-MAPA-2026-10-22.md](POLITICA-CONSULTAS-MAPA-2026-10-22.md) para configuração, testes e limites. O provedor de tiles para escala e a validação em celulares reais continuam pendentes. As notas abaixo são históricas.

> Busca e mapa preparados para crescimento em 20/10/2026: schema **8**, **15 migrações**, GIN/pg_trgm, PostGIS, clusters de relatos, seleção SQL limitada, cache espacial e cidades configuráveis. O catálogo é lido do banco; atualização periódica ativa a cada 10 minutos. O Overpass retornou HTTP 406 nas tentativas online e a fila agendou retentativas; uma importação externa bem-sucedida não foi confirmada nesta etapa. Veja [ESCALA-BUSCA-MAPA-2026-10-20.md](ESCALA-BUSCA-MAPA-2026-10-20.md) para regras, operação, testes e limites. As notas anteriores abaixo são históricas.

> Enquetes, relatos e impactos revisados em 20/10/2026. Banco conectado no schema **7**, com **13 migrações** já aplicadas. Resultados protegidos antes do voto, área Relatos, inbox única e números pessoais separados das melhorias públicas. Veja [ENQUETAS-RELATOS-IMPACTOS-2026-10-20.md](ENQUETAS-RELATOS-IMPACTOS-2026-10-20.md) para regras, testes, compatibilidade e limites. As notas anteriores abaixo são históricas.

> Paginação por cursor aplicada em 20/10/2026. Banco conectado no schema **6**, com **12 migrações**; frontend exige essa versão. A migração já foi aplicada neste projeto. Veja [PAGINACAO-CURSOR-2026-10-20.md](PAGINACAO-CURSOR-2026-10-20.md) para rotas, testes, compatibilidade e atualização de outras instalações. As notas anteriores abaixo são históricas.

> Revisão de arquitetura e participação em 20/10/2026: Participar circular, relação Mapa/Impactos explícita, MapScreen e PlaceCard divididos, consultas extraídas e fatores sob demanda. Escopo e testes em [ARQUITETURA-E-PARTICIPACAO-2026-10-20.md](ARQUITETURA-E-PARTICIPACAO-2026-10-20.md).

> Design system aplicado em 20/10/2026: paleta e raios centralizados, cabeçalhos e cards padronizados, botões e campos compartilhados e ação central Relatar. Detalhes e limites em [DESIGN-SYSTEM-2026-10-20.md](DESIGN-SYSTEM-2026-10-20.md).

> Atualização de 20/10/2026: cabeçalhos e controles compartilhados, organização da avaliação e contextos específicos. Veja [UI-COMPONENTES-2026-10-20.md](UI-COMPONENTES-2026-10-20.md) para escopo, testes e pendências.

> Atualização de 19/10/2026: avaliações aprovadas agora alimentam resumos reais no mapa; demonstração ficou explícita, interações e assets foram corrigidos. O banco remoto já está no schema **5**, com **11 migrations**. Não execute SQL novamente neste projeto. Veja [REVISAO-PRIORIDADES-2026-10-19.md](REVISAO-PRIORIDADES-2026-10-19.md) para correções, método, testes e pendências. As notas anteriores abaixo são históricas.

> Atualização de 14/10/2026: popup e otimizações do mapa. Consulte [OTIMIZACAO-MAPA-2026-10-14.md](OTIMIZACAO-MAPA-2026-10-14.md) para mudanças, medidas e limites de verificação.

> Atualização seguinte: Overture está integrado ao catálogo. Veja [OVERTURE-E-ENRIQUECIMENTO-2026-10-13.md](OVERTURE-E-ENRIQUECIMENTO-2026-10-13.md) para dados aplicados, schema 4, fotos, aliases e verificações atuais. As seções abaixo registram o estado da entrega anterior.

# ELAS na Cidade

Aplicativo em React Native + Expo SDK 55 + Expo Router + TypeScript, preservando a identidade visual original. Login, mapa/catálogo Overpass, avaliações, relatos, melhorias, perfil, favoritos, participação e administração usam Supabase.

**O banco remoto está ativo, com duas migrations pendentes nesta revisão de 27/10/2026.** Historicamente, em 13/10/2026, o login, as APIs do app, o acesso administrativo e o upload privado de avatar passaram em verificações reais. ATUALIZACAO.md descreve a versão aplicada; RELATORIO-MELHORIAS.md e VERIFICACAO-ONLINE-2026-10-13.md registram testes e limites.

```sh
cd Elas
npm ci
npm start
```

Para prévia sem banco:

```sh
npm run demo -- --web
```

A conta de teste existente e o papel administrativo permanecem intactos. Nenhuma senha é distribuída neste projeto.
# Polimento mobile de 13/10/2026

Veja [POLIMENTO-MOBILE-2026-10-13.md](POLIMENTO-MOBILE-2026-10-13.md) para os ajustes atuais de mapa, perfil, avisos e notificações, comparação técnica com Overture e limites de validação. React Native e Expo foram mantidos.

