# Mapa por relevância e zoom — 15/10/2026

Esta atualização substitui o aviso “Há muitos lugares cadastrados nesta área” pela seleção progressiva de pontos. Mantém React Native, Expo e a identidade existente.

## Comportamento

- Afastar o mapa prioriza referências locais e destinos de maior porte, com espaço entre os marcadores. O ponto mantém sua coordenada real.
- Aproximar revela progressivamente estabelecimentos menores. No nível de rua, pontos sobrepostos continuam agrupados e acessíveis pela lista do grupo.
- A seleção explícita por busca permanece destacada, mesmo se o lugar normalmente não fosse exibido naquele zoom.
- Ao ativar uma categoria, lugares menores dessa categoria também podem aparecer em visão ampla. O servidor aplica o filtro antes de selecionar a resposta.
- Busca paginada em “Lugares cadastrados” continua independente da redução de pontos no mapa. A lista “Nesta área” representa os registros carregados para o recorte; não é uma contagem completa da cidade.
- Relatos e a localização do usuário mantêm seu comportamento anterior.

## Critérios e limites

`constants/placeRelevance.ts` concentra a mesma regra usada pelo app web, Android/iOS e servidor: referências locais já identificadas no catálogo, tipos de destino (shopping, hospital, universidade, parque, supermercado etc.), pequeno desempate por revisão/foto e distribuição espacial. Há proteção contra rótulos genéricos e consultórios classificados incorretamente como hospitais. A prioridade é uma heurística de exibição: não mede popularidade, movimento, tamanho físico ou segurança. Não inventa avaliações ou dados de visitas.

O servidor considera páginas de até 1.000 registros antes de selecionar até 500 por resposta. Os primeiros destinos relevantes e a distribuição geográfica têm preferência sobre a ordem alfabética. Há limite operacional de 10.000 candidatos por recorte; se ultrapassado, responde com falha, sem afirmar cobertura completa. O catálogo atual do piloto está abaixo desse limite.

O mapa amplo consulta o catálogo cadastrado em Criciúma sem iniciar uma consulta externa de toda a cidade. Importações Overpass continuam restritas a pequenas áreas, autenticadas e protegidas por reserva. Cobertura parcial da importação é informação separada do limite visual, sem o aviso removido. Falhas reais, dados antigos e áreas fora do piloto continuam informados.

O cache agora distingue os limites exatos da região e a categoria. Assim um close não reutiliza os 500 pontos escolhidos para uma região maior. Mantém compartilhamento de chamadas idênticas, oito respostas por 60 segundos, proteção por conta, debounce de 350 ms após movimentos e atualização externa em segundo plano. Não acrescenta bibliotecas ou altera o schema do banco.

## Verificação

- TypeScript, ESLint, categorias e relevância do mapa: passaram.
- Testes com 1.403 candidatos: prioridade de destinos, distribuição, ordenação estável, abertura em zoom de rua, seleção explícita, filtros, limites reais de consulta e autenticação: passaram.
- Testes de cache/desempenho, rede OSM, estado, Overture e limites de painéis: passaram.
- Exportação web, Android e iOS: passou.
- Função remota `lugares-osm`: versão 12, ACTIVE, verificação JWT preservada. Login HTTP real: 200.
- API real: visão ampla retornou 500 candidatos por relevância em 2.162 ms; recorte aproximado retornou 29 lugares em 918 ms; parques retornaram 26 em 2.373 ms. Estas são amostras isoladas de API, sem inferir FPS ou ganho de tempo de abertura.
- Primeiro recorte amplo incluiu Congresso, Nereu Ramos, Shopping Della, hospitais e parques. Recorte próximo incluiu lojas e cafés. Nenhum trouxe o aviso removido. O recorte de rua informou corretamente que a importação salva poderia estar desatualizada.
- Os assets de identidade, marca, carinhas e imagens anteriores foram preservados byte a byte.

A regra foi testada com fixtures e o servidor real. O navegador automatizado local não tem um Chromium instalado nesta sessão; não houve conferência visual em execução nem teste de gestos em aparelho. Não se declara validação visual nativa nem medição de FPS.

## Executar

Extraia o ZIP, entre em `Elas`, execute `npm ci` e `npx expo start --clear`. Use `npm run web` para navegador. A função do servidor já foi atualizada; não há SQL manual a aplicar nesta entrega.
