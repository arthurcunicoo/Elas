# Validação e operação — pontos 51 a 60

Base de trabalho: **o último ZIP entregue**, versão 18, com 290 arquivos. A origem foi comparada byte a byte antes das alterações. As melhorias de mapa, UI, paginação, política comunitária e cancelamento das entregas anteriores foram preservadas.

## O que foi implementado

| Ponto | Entrega | Situação real |
| --- | --- | --- |
| 51 — automação | Suíte anterior mantida; testes de operação e restauração local adicionados ao `verify`; CI continua verificando código/bundles. | Passou neste ambiente. |
| 52 — E2E físico | Fluxos Maestro, runner Android físico e runner Appium/XCUITest para iPhone; matriz e workflow manual de aparelho. | Preparados; aparelhos ausentes. |
| 53 — regressão visual | Capturas nativas nos fluxos, comparação PNG com diff, aprovação de baseline por aparelho/escala e passo no CI de aparelho. | Pipeline testado com fixtures; nenhuma baseline nativa real criada. |
| 54 — Dynamic Type | Formulário adapta altura ao `fontScale`, ícones centralizados e seletor de percepções usa duas colunas a partir de 130%. Capturas previstas para 100/130/160%. | Código verificado; validação física pendente. |
| 55 — observabilidade | Sentry/Metro/Expo Router, versão/build nativas, duração/resultado HTTP, exceção/crash QA e logs estruturados das Edge Functions. | Logs Edge aplicados e conferidos. Sentry real depende de DSN/conta e build instalada. |
| 56 — carga | k6 cobrindo sete leituras, smoke e rampa até 500 contas distintas, com contratos/limites e bloqueio da produção. | k6 real passou contra fixture HTTP local. Carga no Supabase de staging pendente. |
| 57 — RAM/FPS | Runner Android coleta seis amostras de PSS e framestats durante 50 ciclos no mesmo processo; procedimento de revisão/Perfetto. | Ferramenta preparada; nenhum número de aparelho foi inventado. |
| 58 — produção | Perfis EAS QA/APK/AAB/iOS, pacote/scheme QA distintos, chave Maps por plugin e gate de configuração. | Prebuild Android e exports passaram. APK/AAB/IPA assinados não foram gerados. |
| 59 — recuperação | Dois fluxos conectam solicitação de código real, leitura da caixa QA, troca da senha e login final. | Preparados; falta caixa/conta QA e SMTP validado. O app continua usando código por e-mail. |
| 60 — backup/restore | Dumps oficiais do CLI, cópia de Storage, hashes, restauração bloqueada para produção e exercício local com banco novo. | Exercício local passou; restauração gerenciada em destino remoto pendente. |

## Verificações executadas

- TypeScript e ESLint; suíte completa anterior mais `test:operations` e `test:restore`.
- Checagem Deno das duas Edge Functions com o observador.
- Publicação de `lugares-osm` v15 e `catalog-refresh` v3, preservando autenticação.
- Uma chamada sem credencial ao job foi rejeitada com HTTP 401 e correlacionada no stream real de logs por `x-elas-request-id`. Nenhuma importação foi disparada pelo teste.
- k6 **2.3.0**, binário oficial verificado por checksum, cinco VUs contra HTTP isolado; sete operações cobertas. Esse resultado não mede PostgreSQL ou capacidade de 500 pessoas.
- Restauração local: origem fechada, instância nova carregada do snapshot, dados/Auth shim/Storage e bytes separados conferidos, hashes e RLS preservados. Não é um backup real do ambiente gerenciado.
- Exportação Expo para Android, iOS e web. Os bundles Hermes ficaram perto de 6,0 MB / 5,9 MB após instrumentação.
- Prebuild Android em cópia isolada, conferindo pacote QA, metadado Google Maps e integração Gradle Sentry. A chave utilizada no teste era fictícia; não comprova carregamento do mapa em aparelho.

O Supabase de dados continua no **schema 10**, com **17 migrações**. Esta etapa não alterou tabelas nem criou usuários/avaliações de demonstração na base real.

## Como operar

- [Matriz e aparelhos](docs/qa/MATRIZ-APARELHOS.md)
- [Build e observabilidade](docs/qa/BUILD-E-OBSERVABILIDADE.md)
- [Carga](docs/qa/CARGA.md)
- [Backup e restauração](docs/qa/BACKUP-RESTAURACAO.md)
- `qa/release-evidence.json`: 22 requisitos começam **pendentes**; só preencher após execução e revisão reais.
- `qa/visual/baselines/README.md`: formato das baselines. Ausência de baseline causa falha; não criamos imagens sintéticas para obter verde.

## O que ainda impede validar o lançamento

Não há Android/iPhone conectado, Xcode, ADB ou Maestro neste ambiente. Não estão configurados backend/contas QA, projeto EAS, chaves Maps de build, DSN/projeto Sentry ou credenciais de backup/restore remoto. O k6 foi usado temporariamente apenas na fixture local.

O gate de publicação rejeita configuração ausente, demonstração/diagnóstico QA no release e qualquer requisito sem resultado e artefato revisado. Preparar ferramentas não transforma evidência pendente em aprovação de lançamento. O processo de build, email, dispositivo e restauração remota ainda precisa ser executado com esses recursos.
