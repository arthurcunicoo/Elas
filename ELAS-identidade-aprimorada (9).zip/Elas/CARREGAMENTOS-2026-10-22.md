# Carregamentos — Cidade viva

Atualização cumulativa sobre a versão 21, preservando funcionalidades e dados existentes.

A assinatura visual combina um pin com coração, pequenas construções, uma rota percorrida por um ponto roxo, nós pulsantes e ondas rosa/vinho. O pin flutua suavemente enquanto os elementos da cidade se conectam. A abertura inclui o logo e a frase “A cidade é de todas nós.”

## Aplicação

- Abertura da sessão e conexão inicial da comunidade.
- Preparação do mapa e seleção inicial de cidade; etapas reais continuam visíveis, com opção de continuar no app e tentar novamente em caso de erro.
- Estados iniciais de eventos, enquetes, relatos, notificações, avaliações, favoritos, conquistas, registros e históricos.
- Versão compacta com três pontos nas buscas, paginação, resumos e carregamentos dentro de formulários. Variante clara para o cabeçalho de Impactos.
- Botões de envio e controles nativos de atualização mantêm seus indicadores locais e comportamento original.

## Componentes

`components/loading/CityPulse.tsx` desenha a arte em SVG e anima wrappers de View. `LoadingState` apresenta a experiência completa; `LoadingIndicator` atende buscas e estados pequenos. `hooks/useLoadingMotion.ts` concentra o relógio e o ciclo de vida.

O loop dura 3,2 segundos, anima somente transformações e opacidade e usa o driver nativo em Android/iOS. Não há imagens, vídeos, pacotes novos ou atualização do estado React por quadro. O loop não bloqueia listas virtualizadas, não reinicia em renders comuns e é interrompido ao desmontar, ocultar o modal, perder foco da rota ou ir para segundo plano. A preferência de reduzir movimento mantém a ilustração estática. A arte se ajusta à largura disponível e a abertura permite rolagem para fontes grandes e telas baixas.

Os textos descrevem a etapa real; não há porcentagem fictícia nem atraso artificial. Erros e ações de recuperação continuam disponíveis. O desenho é decorativo para leitores de tela; o estado de carregamento tem descrição e semântica de progresso.

## Verificação

`npm run test:loading` verifica loop estável, driver por plataforma, liberação de listeners, pausa e retomada em segundo plano e ao mudar de rota, redução de movimento, modal inativo, escala da arte em contêiner estreito e semântica acessível. Faz parte de `npm run verify`.

A ilustração foi inspecionada em quatro fases renderizadas a partir do próprio componente. Isso verifica sua composição, sem representar uma captura de um aparelho real. TypeScript, lint, regressões do app e exportação para Android/iOS/web complementam a checagem. Fluidez e leitura com tecnologias assistivas em aparelhos físicos ainda precisam ser confirmadas.
