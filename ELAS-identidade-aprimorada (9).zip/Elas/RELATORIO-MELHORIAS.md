# Melhorias aplicadas — ELAS na Cidade

Base: ELAS-avaliacao-unificada.zip, versão 2. Entrega inicial de 08/10/2026, atualizada e conectada ao banco em 13/10/2026.

## O que mudou

| Área | Resultado |
| --- | --- |
| Identidade | Mantidos assets, skyline, logo, quatro carinhas, barra inferior, botão central e rosa/vinho. Textos pequenos receberam tons mais legíveis; novos fluxos usam cabeçalhos, cartões e feedback existentes. |
| Mapa | Geometria real separada do arredondamento; área mínima para consultas próximas, centro preservado. Lista do catálogo funciona sem foco no input. Busca na área considera endereço e acentos. Expandir aviso não dispara rede; atualizar é ação separada. |
| Seleção | O cartão deixa de exibir o lugar anterior quando a seleção muda; ações ficam vinculadas ao conteúdo visível. |
| Avaliação | Um formulário para busca e pin. Indicação de avaliação já existente, rascunho por conta/lugar, proteção de saída, descarte confirmado ao trocar lugar e carregamento sem substituir campos por renovação de token. Comentários continuam privados. |
| Relatos | Consulta pública corrigida para não solicitar o ID privado do autor. Todos os cards abrem detalhes completos. Um vínculo de lugar permite abrir o mapa sem GPS. Editar o nome livre desfaz o vínculo; correções cadastrais identificam campo e proposta. |
| Envio | Uma identidade persistida por tentativa evita duplicação após confirmação perdida. Repetir o mesmo envio não sobrescreve uma correção posterior. Formulários mostram sucesso somente após a gravação. |
| Conteúdo próprio | Autor pode corrigir texto pendente ou retirar registro com confirmação e histórico. Conteúdo moderado fica protegido; retirar não apaga votos, cadastros ou histórico. |
| Rascunhos | Salvos no aparelho, separados por conta e contexto, válidos por 24 horas e limpos no logout. Alterações finais são salvas sem esperar um debounce ao fechar a tela. |
| Conta | Corrida da sessão inicial corrigida. Recuperação comunica cooldown ao corrigir e-mail. Nome/progresso seguem a identidade da conta, sem recarregar por renovação de token. Requests têm prazo de resposta. |
| Perfil | Galeria, prévia, salvar/substituir/remover foto, limite de 5 MB, bucket privado, URLs temporárias e limpeza de imagens antigas. O botão deixou de ser aviso fictício. |
| Notificações | Abrem o registro exato por tipo/ID; leitura confere linha afetada. Marcar todas e contagem não lida na lista/perfil. Registro indisponível tem estado explícito. |
| Conquistas | Removida a regra duplicada que não era usada nas telas. Testes usam originalAchievementProgress e seus limites. O progresso representa contagens atuais; exclusões podem reduzir valores. |
| Administração | Resumo atualizado por foco/mutação, sem consulta a cada paginação. Status precisa de escolha explícita. Categorias e cadastros usam controle de conflito. Cadastros vinculados podem ser revisados diretamente. |
| Catálogo | Nome/endereço/foto podem ser corrigidos pelo admin, mantendo referência OSM, avaliações e favoritos. Uma importação posterior preserva os campos revisados. |
| Publicações | Listagem, edição, ocultar/republicar, cancelar evento e encerrar consulta. Votos/inscrições preservados. Consultas votadas ou encerradas não permitem trocar a pergunta; as opções permanecem imutáveis. Alterações têm auditoria privada. |
| Datas e histórico | Seleção nativa de data/hora, entrada formatada na web e horário de Criciúma. Eventos/consultas têm filtro de abertos/histórico; filtros ocorrem antes da paginação. |
| Impactos | Acesso paginado às melhorias, filtros e detalhes próprios/públicos. O recorte inicial não é tratado como histórico completo. |
| Robustez | Estados de erro/vazio separados nas listas revisadas; falha de perfil preserva dados anteriores da mesma conta. Gate impede usar esta versão com schema antigo. |
| Organização | Imports compactos, dependências compatíveis com SDK 55, lockfile, componentes compartilhados, types atualizados e migrations incrementais. |

## Evidência de verificação

- TypeScript: passou.
- ESLint: passou sem erros ou avisos após os ajustes finais.
- Banco: **106 verificações**, em PGlite, com duas identidades e roles Auth/Storage simuladas. Cobrem isolamento, idempotência, retirada/edição, conflito, catálogo revisado, encerramento e políticas de avatar.
- Atualização única: executada duas vezes no banco local; oito entradas no histórico, schema válido e bucket privado.
- Estado: cache, épocas por conta, conquistas originais, bounds pequenos, escopo da lista, data de Criciúma, sessão inicial e timeout/cancelamento.
- Mapa: **27 verificações** de categorias, fallback, filtros, agrupamento, visibilidade e distância.
- Overpass: parser, IDs, deduplicação, autenticação, limites, cache, quota, fallback, streaming e UTF-8 com fixtures e transporte simulados.
- Exportação Android/iOS/web: passou. Não representa instalação em aparelho.
- Assets originais e componentes centrais de identidade comparados byte a byte com a base.
- Em 13/10/2026: oito migrations aplicadas, tipos regenerados do banco remoto, login/admin/schema/API reais verificados e políticas de foto testadas por HTTP.
- Erros de indisponibilidade HTTP 5xx, falha de rede e timeout agora têm mensagens próprias. O transporte Overpass usa POST com campo data codificado e respeita 406/429 sem alternar instâncias para contornar quota.

## Pendências específicas

**Banco remoto — resolvido em 13/10/2026:** projeto reativado e duas migrations aplicadas, totalizando oito. Login, role admin, gate de schema, busca, registros, consultas, resumo administrativo e Storage privado passaram em verificações HTTP reais. Detalhes em VERIFICACAO-ONLINE-2026-10-13.md.

**Validação real:** não foi possível testar esta entrega em celular, capturar antes/depois ou executar o fluxo completo com o schema novo no servidor. Permanecem pendentes GPS negado, gestos, teclado, fonte ampliada, Android Back, retomada, TalkBack/VoiceOver, galeria/upload real, SMTP/código de recuperação e moderação/voto/inscrição com contas reais. Os testes locais não são apresentados como essas verificações.

**Distribuição:** chave do mapa no build próprio Android, ícones/abertura finais e validação do APK/IPA exigem a etapa de build/dispositivo. Não foi trocado o motor do mapa nem adicionada infraestrutura sem necessidade.

A proteção contra senhas vazadas continuava desabilitada no advisor remoto. Não foi alterada configuração/plano. As tabelas privadas de envios e auditoria mantêm acesso direto fechado intencionalmente.

Não foram criados termos, contratos ou documentos jurídicos.
