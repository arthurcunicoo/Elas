# ELAS — padronização da interface, bloco 1

## Entregue

- `PageHeader` concentra o cabeçalho rosa, área segura, botão de voltar com 48 pontos e título flexível. Aplicado às páginas de conta, às páginas que usam `FeaturePage`, à avaliação e ao novo relato.
- `FormControls` concentra campos, ações, mensagens e estilos de cartões. Os formulários de conta reutilizam essa implementação, com a mesma tipografia, bordas, foco e estados de erro. O campo compartilhado aceita senha com alternância de visibilidade e mantém referência nativa para foco programático.
- `formLayout` reúne dimensões dos formulários em `constants/theme.ts`. Os tokens anteriores permanecem disponíveis para preservar a geometria de telas com composição própria.
- `FeaturePage` fica responsável pelo contêiner, rolagem e teclado; `PageHeader` pela navegação visual; `FormControls` pelas entradas e ações. Os exports antigos continuam compatíveis com os consumidores existentes.
- `app/avaliar.tsx` fica responsável pelos parâmetros de navegação e seleção de lugar. `features/reviews/ReviewForm.tsx` encapsula o formulário, rascunho, carregamento, envio e feedback, mantendo a chave por lugar para isolamento do estado.
- Avaliação, configurações, novo relato e solicitação de melhoria passam a consumir os contextos específicos de sessão, catálogo e localização. Não há mais consumidor de `useAppData` nas telas/componentes/features; a API permanece no provider por compatibilidade.
- Cores principais, logotipo, ilustrações, carinhas e comportamento do mapa preservados. Nenhuma migração ou alteração de dados de produção neste bloco.

## Verificação realizada

`npm run verify` passou: TypeScript, ESLint, testes de banco simulado, resumos comunitários, fluxos de produção/demonstração, formulários, estabilidade e desempenho do mapa, regras de zoom/categorias, estado, importação e atualização atômica.

Os testes montados de formulários foram ampliados para verificar referência de foco, encaminhamento de eventos de foco/desfoque, mensagem acessível de erro, senha visível/oculta, ações desabilitadas/ocupadas e cabeçalho acessível. Os testes existentes de rascunhos, envio, seleção de lugares e estabilidade do mapa continuam passando.

`npx expo export --platform all` concluiu os bundles de Android, iOS e web. Isso não equivale a um APK/IPA assinado ou a um teste em dispositivo.

## Ainda pendente

Este é um bloco incremental, não a padronização de todas as telas. MapScreen, eventos e outros formulários grandes ainda podem ser decompostos em blocos específicos. O ReviewForm agora tem responsabilidade isolada, mas continua sendo um formulário extenso.

Busca, paginação, agrupamento de relatos e monitoramento de produção não foram alterados. Acessibilidade visual, fontes ampliadas, teclado, áreas seguras e toques precisam ser validados em Android e iPhone reais. Testes com hosts nativos simulados não calculam layout. O app continua sem validação para lançamento público em escala.
