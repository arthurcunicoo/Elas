import { useMemo } from "react";
import { normalizePlaceQuery, type MapRegion, type Place } from "../../constants/places";
import { categoryForPlace, type CategoryId } from "../../constants/placeCategories";
export function useMapResults(
  places: Place[],
  region: MapRegion,
  filter: CategoryId,
  query: string,
  importedRows: Place[],
  remote: boolean,
) {
  const areaPlaces = useMemo(
    () =>
      places.filter(
        (p) =>
          Math.abs(p.latitude - region.latitude) <=
            region.latitudeDelta * 0.55 &&
          Math.abs(p.longitude - region.longitude) <=
            region.longitudeDelta * 0.55,
      ),
    [places, region],
  );
  const available = useMemo(
    () =>
      areaPlaces.filter(
        (p) => filter === "all" || categoryForPlace(p).id === filter,
      ),
    [areaPlaces, filter],
  );
  const localResults = useMemo(
    () =>
      available.filter((p) =>
        normalizePlaceQuery(`${p.name} ${p.address}`).includes(
          normalizePlaceQuery(query),
        ),
      ),
    [available, query],
  );
  const results = remote ? importedRows : localResults;
  const counts = useMemo(() => {
    const value: Partial<Record<CategoryId, number>> = {
      all: areaPlaces.length,
    };
    areaPlaces.forEach((p) => {
      const id = categoryForPlace(p).id;
      value[id] = (value[id] ?? 0) + 1;
    });
    return value;
  }, [areaPlaces]);
  return { available, results, counts };
}
