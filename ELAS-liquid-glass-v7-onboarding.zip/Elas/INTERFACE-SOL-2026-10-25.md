# ELAS — interface e refinamento (Sol, nível Alto)

Base: versão 23, entregue em 25/10/2026 sobre a base de quinta-feira. O ZIP e o código foram comparados antes de editar. O pacote desta rodada é cumulativo: debounce/flush de rascunhos, revalidação das listas, conversão de fusos e isolamento dos tiles permanecem na base.

## As dez frentes

| Frente | Trabalho realizado | Como conferir / limite |
| --- | --- | --- |
| 1. Movimento | CityPulse e seu relógio foram preservados; feedback de pressionamento agora é imediato quando o sistema pede reduzir movimento. Tempos de pressionamento centralizados em `motionTiming`. | Testes de ciclo de vida existentes e teste de nenhuma animação nova no pressionamento reduzido. FPS físico não medido. |
| 2. Skeletons e estados | Três formatos de skeleton: cards, lugares e notificações. `CollectionState` distingue carga, vazio e falhas, com retry e limpeza quando úteis. Aplicado em eventos/enquetes, relatos recentes, favoritos, histórico de impactos, relatos da área, publicações administrativas, registros próprios, avaliações próprias, notificações e fila administrativa. | Testes de estado e ações. Atualizações com itens existentes preservam a lista; não exibem um skeleton por cima dela. Outros fluxos especializados, como mapa e formulários, mantêm seus próprios estados. |
| 3. Design system | Estados e filtros usam palette/radius/typography; botões comuns e `TouchFeedback` continuam como fonte de interação. Sem cores novas de marca. | Lint do design system e tipos; novos tokens de timing. Não foi substituído o tema. |
| 4. Responsividade | Filtros de status quebram em múltiplas linhas; skeletons usam larguras relativas e coluna flexível; botão de senha deixa de ocupar toda a altura de campo multilinha e fica centralizado em 48×48. Controles de sheet e ícone têm área de 48×48. | Geometria do campo testada com fontScale 1,6. Teclado, notch e tablets ainda exigem validação real. |
| 5. Feedback | Falhas de coleção têm mensagens próprias de conexão, sessão, permissão e serviço. Texto bruto do erro não é reproduzido pelo novo componente. Cabeçalhos deixam de repetir erros já mostrados no estado vazio; erro de moderação aparece junto da decisão. | Testes de cópia segura, retry e estado vazio sem retry irrelevante. Classificação é de apresentação, não diagnóstico de conectividade. |
| 6. Acessibilidade | Foco de teclado ganha contorno visível no web, inclusive variante clara nos botões sobre header de marca; campos sinalizam `aria-invalid`; erros são alertas; filtros ativos têm rótulos explícitos e seleção tem marca visual além da cor. | Testes de props/foco/estado. VoiceOver, TalkBack, ordem de foco e contraste da tela renderizada não foram certificados. |
| 7. Organização | Filtros extraídos de AdminScreen para AdminFilters; estados de coleção substituem blocos duplicados; removidas nove definições locais de estilo comprovadamente sem referências. | Lista em `qa/interface-removed-styles.json`; APIs públicas existentes mantidas. Nenhuma funcionalidade removida. |
| 8. Administração | Busca e status ativos aparecem explicitamente; limpeza independente e global; preservação do contexto de tipo; retorno a detalhes não reseta filtros da tela montada. Filtros ficam indisponíveis durante uma decisão. | Testes do componente e da tela real montada com services simulados. Consultas, autorização e SQL intactos. Persistência após encerrar a sessão/app não foi adicionada. |
| 9. Plataformas | Foco web sem forçar comportamento de mouse no mobile; controles de modal padronizados; removido um espaço de texto solto diretamente em View do card administrativo, inválido em renderização nativa. | Regressão procura strings diretamente em View. Consistência visual real entre plataformas ainda pendente. |
| 10. Testes | `tests/interface.mjs`, integrado como `npm run test:interface` e em `npm run verify`. Usa componentes reais e hosts nativos simulados, sem snapshots frágeis. | Logs e comandos em `qa/interface-validation.json` e evidências associadas. |

## Arquivos e preservação

O manifesto `qa/interface-changes.json` lista cada arquivo modificado ou acrescentado. A camada nova é somente de apresentação. Os tipos/rotas públicas, services de dados, migrations e regras de autorização não foram alterados. Os testes anteriores de produto passaram a usar um host para CollectionState porque continuam focados em routing/escopo; os testes novos exercitam o componente real e suas ações.

A checagem de preservação compara os arquivos de rascunho e sua fila, usePagedList, datas/conversão, CityPulse/useLoadingMotion e WebMapTiles com a versão 23. O package-lock e os assets/migrations também são mantidos. Nenhuma dependência foi instalada ou atualizada.

## Testes automatizados

- Carga com skeleton e progresso acessível; vazio com ação adequada; falhas de conexão/servidor/permissão/sessão; retry e limpeza independente.
- Mensagem contendo detalhe privado não é copiada para o novo estado de erro.
- Contraste matemático mínimo 4,5:1 para text/muted/brand sobre surface nos componentes compartilhados. Isso não certifica todas as combinações das telas.
- Foco e blur web mostram/removem o contorno; estado busy bloqueia acionamento; movimento reduzido não inicia timing/spring de pressionamento.
- Campo com erro sinaliza invalid/alert; fonte em 160% aumenta a altura; botão de senha mantém tamanho e posição definidos.
- Filtros respeitam o conjunto visual de moderador, mostram ativos e limpam busca/status sem mudar o outro filtro. Este teste de UI não substitui RLS.
- Tela administrativa real montada conserva busca ao abrir detalhes; limpar filtros resulta nos mesmos parâmetros esperados do service; containers View não recebem texto solto.
- Suíte existente conserva cobertura de rascunhos, isolamento, cursores, dados e mapa.

Hosts simulados não calculam pixels, não abrem teclado real nem executam leitores de tela. Não há baseline visual nova nem teste em aparelho nesta rodada. O roteiro para fechar isso está em `qa/interface-device-checklist.md`. Os 22 itens de `qa/release-evidence.json` continuam pending. Não considero todos os critérios de conclusão física atendidos apenas com os testes locais.

## Aplicação e reversão

Extraia em uma pasta separada, use `npm ci` e `npm run verify` e valide em staging/aparelhos. Não há migration ou deploy de backend nesta entrega. Para reverter, restaure o ZIP da versão 23 com seu lockfile; formatos de rascunhos e dados permanecem compatíveis.

Riscos a conferir: títulos e filtros longos podem ocupar mais altura em fontes grandes; mensagens de erro de apresentação não garantem a causa exata da falha; o formulário administrativo fecha a edição ao mudar status/filtros; filtros só sobrevivem enquanto a tela/sessão de navegação é mantida. As pendências de dependências e segurança descritas na modernização anterior continuam abertas e não fazem parte deste bloco de interface.
