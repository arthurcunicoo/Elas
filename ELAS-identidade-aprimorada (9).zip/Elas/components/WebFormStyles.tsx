import { palette, radius } from "../constants/theme";
import { createElement } from "react";
import { Platform } from "react-native";

// Browser autofill paints the inner input separately from its rounded container.
export function WebFormStyles() {
  if (Platform.OS !== "web") return null;
  return createElement(
    "style",
    null,
    `
    input, textarea { outline: none !important; }
    input:focus-visible, textarea:focus-visible { box-shadow: 0 0 7px ${palette.icon} !important; }
    input:-webkit-autofill,
    input:-webkit-autofill:hover,
    input:-webkit-autofill:focus,
    input:-webkit-autofill:active {
      -webkit-box-shadow: 0 0 0 1000px ${palette.surfaceTint} inset !important;
      -webkit-text-fill-color: ${palette.wine} !important;
      caret-color: ${palette.wine};
    }
    [role="button"]:focus, [role="link"]:focus { outline: none !important; }
    [role="button"]:focus-visible, [role="link"]:focus-visible {
      box-shadow: 0 0 0 3px ${palette.icon};
      border-radius: ${radius.medium}px;
    }
  `,
  );
}
