# Avaliações, consultas e mapa web — 22/10/2026

Esta entrega trata dos pontos 41 a 50. O Supabase conectado está no schema **10**, com **17 migrações**. As duas migrações desta etapa já foram aplicadas e verificadas. O aplicativo exige schema 10.

## Resultado por ponto

| Ponto | Resultado |
| --- | --- |
| 41 — tiles públicos | Provedor HTTPS XYZ configurável por ambiente, atribuição própria, limite de zoom e opção explícita de piloto. Nenhum provedor comercial foi contratado. |
| 42 — política comunitária | Parâmetros privados no backend; classificação e explicação retornam do mesmo cálculo. A explicação é enviada uma vez por lote. |
| 43 — incerteza | Rótulos continuam descrevendo percepções. O aviso de que não garantem segurança permanece visível. Comentários e autoria ficam privados. |
| 44 — eventos | Preservada a consulta única: `pagina_app('eventos')` já retorna `inscrito`. Teste usa o SDK real para conferir uma chamada. |
| 45 — impactos | Preservado `painel_impactos()`, uma chamada com escopos pessoais e públicos separados. `resumo_impactos()` continua apenas para compatibilidade. |
| 46 — agregações futuras | Mantidos agregação ao vivo, índice e lotes limitados a 600 IDs; não foi criada tabela materializada. |
| 47 — consultas antigas | AbortSignal atravessa hooks, cache, services, Supabase e fetch nos fluxos críticos de mapa, busca, detalhes e resumos. |
| 48 — imagens | Quatro imagens redimensionadas para no máximo 800 px no maior lado, com compressão JPEG progressiva. Fotos conhecidas usam as cópias otimizadas diretamente. |
| 49 — referências | As referências de cadastro e skyline foram movidas de `assets/` para `docs/design/`. |
| 50 — mapa web | Projeção, tiles, controles, pontos e gestos extraídos. Mantida a engine atual, com testes de geometria e ciclo de carregamento. Não houve migração para Leaflet/MapLibre. |

## Uma política publicada pelo backend

`private.politica_avaliacoes` contém uma única política, acessível aos operadores do banco. Usuários do app não podem ler nem alterar essa tabela: privilégios revogados, RLS habilitada e política explícita de bloqueio.

Valores atuais: versão 1, mínimo 5 contribuições aprovadas, janela de 180 dias, limite favorável de 70% e limite de atenção de 50%. O mínimo possui piso de privacidade de cinco contas. Continua valendo uma contribuição por conta e lugar. Alterações aprovadas pelos responsáveis podem ser feitas nos parâmetros, incrementando `versao`, sem duplicar fórmulas ou textos no app.

O RPC privado aplica a janela, moderação, limiares e precedência de atenção. A resposta contém a classificação (`unknown`, `safe`, `attention`, `moderate`) e a explicação em português, calculada a partir dos mesmos parâmetros. Esses códigos internos controlam a apresentação de **percepções**, não um laudo de segurança.

O cliente valida formato, limites, soma da distribuição e consistência do mínimo; apresenta a classificação e o método recebidos. Não exige mais exatamente 5/180, nem recalcula limiares. Testes isolados mudam a política para 8/90 e alteram percentuais para conferir classificação, distribuição e explicação juntas.

A chamada atual é `resumos_avaliacoes({ p_lugares, p_compacto: true })`, que retorna `{ politica, resumos }`. A política aparece uma vez por lote. A assinatura antiga com um argumento continua aceitando os clientes instalados. Ambas usam a mesma agregação autenticada e não expõem avaliações individuais.

Em uma consulta real com 500 lugares, o JSON caiu de **349.340 bytes** na projeção com metadados repetidos para **89.374 bytes** na projeção compacta. São tamanhos do JSON no banco, antes da compressão HTTP, observados com a base atual sem avaliações reais; não representam benchmark de grande volume.

Migrações canônicas:

- `20261022133600_review_policy_metadata.sql`
- `20261022134052_compact_review_policy_payload.sql`

`supabase/ATUALIZACAO.sql` foi regenerado com as 17 versões. Neste projeto elas já estão aplicadas; em outra instalação, usar o script atômico após backup e conferência do ambiente. O teste verifica rollback por falha tardia, segunda execução idempotente e preservação dos dados existentes.

## Cancelamento e cache

Mudança de região, busca, filtro, conta ou foco cancela os consumidores antigos. Desmontar o provider cancela suas requisições pendentes. A cadeia inclui busca de lugares, resolução de um local, consulta espacial de relatos, relato vinculado, resumo comunitário e atualização manual do card.

O cache mantém consumidores independentes: sair de uma tela não cancela uma consulta ainda usada por outra. Ao sair o último consumidor, o fetch pendente é cancelado e a entrada abandonada é removida, permitindo retentativa nova. Resultados antigos continuam protegidos por identidade e geração.

O teste de cancelamento usa o **SDK Supabase instalado**, os services reais e uma fronteira fetch controlada. Confere que o signal chega ao HTTP, inclusive quando uma busca já iniciou a consulta seguinte de resumos. AbortSignal interrompe o pedido no cliente; o encerramento de trabalho já iniciado no servidor depende da infraestrutura e não é garantido por este teste.

Não foram canceladas mutações como votos, relatos ou inscrições. A cobertura desta etapa está nos fluxos de leitura críticos do mapa; não é uma afirmação de cancelamento em toda consulta de todas as telas.

## Configurar tiles na web

O mapa nativo continua usando `react-native-maps`. Para web, configurar no ambiente de build:

```dotenv
EXPO_PUBLIC_MAP_TILE_URL=https://tiles.seu-provedor.example/{z}/{x}/{y}.png?key=CHAVE_PUBLICA_RESTRITA
EXPO_PUBLIC_MAP_TILE_ATTRIBUTION=Nome e créditos exigidos pelo provedor
EXPO_PUBLIC_MAP_TILE_ATTRIBUTION_URL=https://seu-provedor.example/licenca
EXPO_PUBLIC_MAP_TILE_MAX_ZOOM=19
```

O exemplo é ilustrativo: substituir pelo endpoint real contratado ou hospedado. Usar tiles raster XYZ de 256 px em HTTPS. A chave pública do navegador deve ter restrições de domínio e quota no provedor; nunca colocar credencial administrativa nesses campos. O máximo aceito pelo componente vai de 10 a 20.

Atribuição do provedor aparece junto às atribuições de dados OSM/Overture. Configuração inválida não troca silenciosamente para infraestrutura pública. Em release, sem provedor ou opção explícita de piloto, a camada de mapa informa indisponibilidade; a busca de lugares continua acessível.

Para desenvolvimento ou piloto pequeno, é possível optar por `EXPO_PUBLIC_MAP_TILE_MODE=pilot`. O `.env` desta entrega mantém essa opção explícita para preservar o piloto existente. Nesse modo o limite é 19, compatível com o servidor público utilizado. Remover essa opção e configurar um provedor adequado antes de ampliar o uso público. Nenhuma assinatura ou conta de tiles foi provisionada nesta etapa.

Não há prefetch de regiões ou download offline de tiles: somente o viewport visível é solicitado. O navegador usa as URLs e o cache HTTP normais. Ver política oficial: <https://operations.osmfoundation.org/policies/tiles/>.

Estrutura:

- `features/map/web/geometry.ts`: projeção e cobertura de tiles.
- `features/map/web/tileProvider.ts`: configuração, validação e URL XYZ.
- `features/map/web/useWebMapDrag.ts`: gestos com atualização por frame.
- `components/map/web/WebMapTiles.tsx`: imagens, estados e notificações de carregamento.
- `components/map/web/WebMapControls.tsx`: zoom e movimentos acessíveis.
- `components/map/web/PointLayer.tsx`: lugares e grupos.

O componente `CityMap.tsx` passou de 616 para 362 linhas nesta base. O volume total foi distribuído em módulos; isso não substitui uma biblioteca especializada. Como o uso principal é mobile, a engine web foi mantida. Se web passar a ser estratégica, avaliar uma biblioteca com zoom, gestos, navegação por teclado e tratamento global de coordenadas mais completos.

## Imagens e atribuição

| Arquivo | Antes | Depois | Dimensões atuais |
| --- | ---: | ---: | --- |
| `congresso.jpg` | 388.391 B | 99.601 B | 800 × 533 |
| `nacoes.jpg` | 107.832 B | 72.293 B | 800 × 435 |
| `nereu.jpg` | 808.891 B | 68.286 B | 800 × 600 |
| `city-modern.jpg` | 159.430 B | 78.673 B | 800 × 598 |

Total: **1.464.544 → 318.853 bytes**, redução de aproximadamente **78%**. As imagens foram inspecionadas após o redimensionamento. O card usa as cópias locais quando a URL coincide com uma das três fontes licenciadas conhecidas; assim não baixa o original de alta resolução antes do fallback.

Autoria, fonte, data e licença permanecem no card, agora com indicação de redimensionamento/compressão. As três fotos cadastradas têm esses metadados no banco. Fontes e licenças estão detalhadas também em `docs/design/ASSETS.md`.

## Verificação e limites

A verificação geral inclui TypeScript, ESLint e os testes de banco, política comunitária, cursores, geografia, filas de catálogo, demonstração, fluxos do app, arquitetura, mapa web, estabilidade, relevância, mobile, estado, OSM, Overture, script de atualização, cancelamento e desempenho.

O mapa web tem 1.100 testes de ida/volta da projeção, limites polares, cobertura visível, URLs XYZ, configuração inválida, limite de zoom, atribuição e ciclo de sucesso/erro/pan. A regressão montada do mapa verifica que a seleção estabiliza após uma consulta e que vinte ciclos de carregamento/layout não reabrem o indicador.

O banco remoto foi conferido com sessão autenticada simulada no SQL: contratos compactos e antigos, eventos com inscrição, painel de impactos, proibição de alterações da política e bloqueio do RPC para anon. Não foram criadas avaliações, contas, inscrições ou relatos fictícios no conteúdo real.

Os testes React usam hosts simulados. Exportação Expo para Android, iOS e web verifica empacotamento, não substitui instalação em celular real nem teste visual em navegador. Não foi gerado APK/IPA nem publicado um novo frontend nesta etapa.

A revisão dos advisors não introduziu um novo aviso de segurança. Permanecem itens anteriores: [proteção contra senhas vazadas desativada](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection), [quatro tabelas intencionalmente fechadas sem políticas](https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy), [uma chave estrangeira de histórico sem índice](https://supabase.com/docs/guides/database/database-linter?lint=0001_unindexed_foreign_keys) e [índices ainda sem uso registrado](https://supabase.com/docs/guides/database/database-linter?lint=0005_unused_index). Não houve mudança dessas configurações nem exclusão de índices.

A operação do job de catálogo e sua dependência externa permanecem descritas em `ESCALA-BUSCA-MAPA-2026-10-20.md`; uma importação externa bem-sucedida não foi revalidada neste bloco. As consultas do mapa continuam lendo do próprio banco.
