# Revisão de UI/UX mobile

## Corrigido nesta versão

- Feedback inconsistente: TouchFeedback e PrimaryButton agora compartilham compressão de toque e retorno por mola. O fundo acompanha a opacidade, além do texto. Toques rápidos têm 65 ms de feedback antes da ação; resultados de busca são imediatos para preservar a seleção.
- Links de autenticação, visibilidade de senha, tabs de Alertas e checkboxes de avaliação passaram a usar o mesmo feedback.
- Envios: avaliação e solicitação ficam indisponíveis durante o carregamento. Cadastro bloqueia nova ação durante a transição. Enquete informa o estado desabilitado após votar.
- Alvos pequenos: botões de envio em Alertas/Impactos, tabs de Alertas, olho da senha e linhas de checkbox agora têm pelo menos 44 unidades de altura.
- Avaliação tinha saída apenas após concluir (ou pelo voltar do sistema): adicionada seta de retorno no cabeçalho.
- Botão central variava de 86 para 100 entre abas: tamanho padronizado no componente compartilhado.
- Cards de melhorias tinham ação vazia: agora mostram detalhes locais num diálogo. Descrições pequenas passaram de 9 para 11.
- Falha na consulta de redução de movimento antes deixava movimento desativado indefinidamente: fallback corrigido. Quando o sistema solicita redução, a escala continua desativada e o feedback usa opacidade.

## Limitações restantes

- Esta foi uma revisão do código com verificação TypeScript e exportações. Não houve execução visual/gestual em celular nem medição de FPS.
- Foto ampliada da praça ainda usa o recorte existente de baixa resolução.
- Várias telas do MVP (informações pessoais/configurações, por exemplo) continuam demonstrativas; não foram transformadas em funcionalidades novas.
- O mapa depende dos provedores existentes. Avaliações, votos e solicitações permanecem locais e sem persistência.

## Conferência no Expo Go

1. Testar toque rápido e toque prolongado em Entrar, +, tabs e Enviar: compressão visível e retorno suave; arrastar para fora deve cancelar a ação.
2. Verificar teclado com busca e comentário; selecionar uma sugestão e avaliar o lugar correto.
3. Voltar da avaliação sem enviar, testar envio com campos faltando e repetir toque durante carregamento.
4. Testar redução de movimento ligada/desligada, texto ampliado e tela pequena: conteúdo deve continuar rolável.
5. Verificar que o + mantém tamanho entre Mapa, Eventos, Alertas e Perfil.
