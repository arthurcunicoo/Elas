# Backend, banco e administração — 27/10/2026

Base: `ELAS-liquid-glass-v7-onboarding.zip`, SHA-256 `b716452a435ccb80fa0929a0fcfc95da21a53f12dd361982a096c85f598ceef3`. Esta revisão usa o pacote enviado agora. Estilos, assets e onboarding foram preservados; as mudanças nas telas são de autorização.

## Administração corrigida

Usuários comuns já eram bloqueados pelo banco nos RPCs administrativos inspecionados. Na interface, a condição `role !== "usuario"` também aceitava moderadores e valores inesperados. As rotas administrativas estavam no grupo geral de usuários autenticados e dependiam das verificações individuais das telas.

Nesta entrega:

- Menu Administração exige backend configurado, sessão e papel exatamente `admin`.
- `admin`, `admin-publicar`, `admin-publicacoes` e `admin-lugar` ficam em um grupo `Stack.Protected` exclusivo de administrador.
- Links administrativos aguardam a primeira leitura de permissões, evitando redirecionar um administrador válido antes da resposta. As telas comuns não esperam essa leitura.
- O painel mantém sua própria verificação e não monta consultas para usuários, moderadores ou papéis desconhecidos.
- Respostas inválidas do RPC viram `usuario`; erros não concedem acesso.
- Permissões são reconsultadas ao voltar do background. Respostas de uma conta anterior não restauram seus privilégios na conta atual.

O papel vem de `private.papeis` via `meu_papel()`, não de dados editáveis pelo usuário. Há **um administrador cadastrado** no banco conectado. É esperado que essa conta veja o menu.

As permissões limitadas dos moderadores no backend foram preservadas para compatibilidade: relatos e melhorias continuam autorizados para esse papel nos RPCs existentes. Isso não equivale a administração completa. O painel atual, perfis, publicação e catálogo não são liberados para moderadores. Uma futura interface de moderação deverá ter rota e identificação próprias. Nenhuma conta foi promovida ou rebaixada.

## Banco conectado: evidências atuais

Consultas somente de leitura no projeto `pxcbzjxgxdmdayqwpqcj`, que coincide com a configuração do pacote:

| Verificação | Resultado |
| --- | --- |
| Tabelas públicas sem RLS | 0 |
| Grants diretos de tabelas privadas para anon/authenticated | 0 |
| Funções públicas SECURITY DEFINER executáveis por clientes | 0 |
| Origem dos papéis | Tabela privada, consulta por `auth.uid()` |
| Versão lógica retornada por `versao_app()` | 11 |
| Migrations aplicadas / incluídas no pacote | 20 / 22 |
| Staging | Nenhum outro projeto listado; nenhuma branch neste projeto |
| Edge Functions implantadas | lugares-osm, catalog-refresh, push-delivery |
| Push | Desativado; sem cron de entrega |
| Retenção de idempotência e push | Dois crons ativos |
| Atualização do catálogo | Cron ativo a cada 10 minutos |
| Catálogo salvo | 1.535 lugares |
| Importador | 81 tiles; nenhum com `updated_at` de sucesso; erro registrado `upstream_or_import_failed` |

O advisor de segurança apontou proteção contra senhas vazadas desativada e oito informações de RLS sem policy. As tabelas apontadas estão deliberadamente fechadas para acesso direto; não criar policies públicas para silenciar esses avisos. O advisor de desempenho apontou uma FK sem índice cobrindo `private.publicacoes_historico.responsavel_id` e 29 índices sem uso registrado. Índices sem uso em um piloto não foram removidos automaticamente.

Esses resultados verificam configuração e código, sem certificar todos os caminhos com sessões reais ou a capacidade de produção.

## O que falta, por prioridade

| Prioridade | Pendência | Critério de conclusão |
| --- | --- | --- |
| Alta | Aplicar as duas migrations de 25/10 que faltam no banco | Validar em staging, revisar rollback e aplicar de forma controlada. A checagem de versão 11 não detecta sozinha essa diferença. |
| Alta | Recuperar atualização do catálogo | Demonstrar importação real bem-sucedida, atualização dos tiles e preservação de correções manuais. Cron ativo não comprova sucesso. |
| Alta | Commit de importação atômico com a reserva do job | O worker faz upsert e só depois valida/finaliza a reserva. Uma reserva vencida pode ser rejeitada depois de dados já gravados. Validar a reserva dentro da mesma transação de escrita, com testes de concorrência e repetição. |
| Alta | Staging e testes com contas reais | Usuário A não lê/altera dados de B; usuários comuns/deslogados não administram; revogação funciona; decisões concorrentes não sobrescrevem revisões antigas. |
| Alta | Autenticação de produção | Testar entrega de e-mail, recuperação, deep link, nova senha e login final. Verificar SMTP e tratar o aviso de senhas vazadas conforme disponibilidade do plano. |
| Alta | Implantar exclusão de conta antes de ativá-la | A migration de exclusão está pendente e `account-erasure` não está implantada. A opção permanece desativada. Validar Auth, Storage, tokens existentes e recuperação de falhas em staging. |
| Média | Gestão de administradores | Falta fluxo auditado para conceder/revogar papéis e proteção automática do último administrador. Hoje há procedimento manual restrito ao banco. |
| Média | Observabilidade e recuperação | Logs Edge já existem; a configuração enviada não tem DSN do Sentry. Validar alertas e exercício real de backup/restauração remota. |
| Média | Carga real | Executar busca, mapa, resumos, relatos, eventos e Impactos em staging com volume/concorrência representativos. Fixtures locais não comprovam 500 usuários simultâneos. |
| Evolução | Push real | Configurar credenciais/projeto, habilitar entrega agendada e comprovar recebimento Android/iPhone e cancelamento após opt-out. Worker implantado sozinho não envia notificações. |
| Baixa | FK e atualização gerenciada do PostgreSQL | Medir consultas e revisar compatibilidade, backup e staging antes de alterar infraestrutura. |

Migrations pendentes: `20261025213938_account_erasure_controls.sql` e `20261025214404_catalog_job_jitter.sql`. A segunda acrescenta jitter ao backoff; não corrige o commit separado da reserva.

A causa específica da falha atual da fonte externa não foi demonstrada nesta rodada. O HTTP 406 mencionado nos relatórios antigos não foi reproduzido novamente. Esta entrega não troca a fonte nem incorpora propostas experimentais de outro pacote.

Já existem services, RLS, paginação por cursor, busca indexada, PostGIS, agregação de relatos, resumo comunitário, moderação com revisão/histórico e retenção. As pendências não exigem reconstruir o banco inteiro.

## Testes e limites

`npm run verify` passou, incluindo TypeScript, lint, banco e os novos testes administrativos. O lint terminou com zero erros e três avisos já presentes na base enviada: imports sem uso em `app/perfil.tsx` e `components/map/PlaceReviewPreview.tsx`, e dependência de hook em `features/map/MapScreen.tsx`. Os avisos não foram ocultados nem tratados como evidência de validação visual.

`tests/admin-access.mjs` executa os componentes reais de menu/layout, serviço de perfil e provider com transporte/hosts simulados. Cobre papéis válidos/inválidos, deslogado, demonstração, quatro rotas protegidas, espera de permissões, troca de conta, logout, falha, retorno do background e revogação. `tests/interface.mjs` verifica que o painel não monta consultas administrativas para papéis negados.

Os testes de banco existentes usam PostgreSQL isolado e Auth/Storage simulados: incluem RLS, bloqueio de autopromoção/resumo administrativo, limites dos moderadores, conflitos de revisão e histórico. O router foi verificado pelo contrato de configuração `Stack.Protected`; não foi executada navegação nativa, sessão real de QA no Supabase ou renderização em aparelho.

Resultados: `qa/backend-admin-evidence.json` e `qa/backend-admin-verify.txt`.

Produção recebeu apenas consultas de leitura. Não foram aplicadas migrations, alterados papéis, implantadas funções, enviados e-mails/push ou excluídos dados. A correção entregue passa a valer na próxima build/publicação que usar este código.

Referências: [RLS e grants](https://supabase.com/docs/guides/database/postgres/row-level-security), [segurança de senhas](https://supabase.com/docs/guides/auth/password-security), [mudanças do PostgreSQL gerenciado](https://supabase.com/changelog/postgres-15-19-17-11-breaking-changes). Os números do projeto vieram das consultas desta revisão.
