# ELAS — participação, navegação e responsabilidades

## Revisão 20–29 aplicada

| Ponto | Resultado |
| --- | --- |
| 20 — Participar | Restaurado o nome `Participar`, com círculo de 56 × 56 e raio pill. O sheet oferece `Avaliar um lugar` e `Relatar uma situação`, com coração e megafone e descrições de uma frase. A transição compartilhada agora anima abertura e fechamento, mantém o modal durante a saída, cancela saídas interrompidas por uma reabertura e respeita movimento reduzido. |
| 21 — Impactos e mapa | Impactos continua sendo uma área filha do mapa. O cabeçalho mostra `Mapa › Impactos` e oferece retorno direto ao mapa; a aba Mapa continua ativa com essa relação explicitada. Não foi acrescentada uma sexta aba à navegação. |
| 22 — API de label | `addLabel` controla o texto visível. `addAccessibilityLabel` fornece uma descrição acessível opcional e tem fallback para o mesmo label. A ação interna central se chama `Participar`, sem o identificador antigo `Adicionar`. |
| 23 — diálogo genérico | Confirmações sem label usam `Confirmar`. Logout informa `Sair` explicitamente. Diálogos informativos mantêm `Entendi`. |
| 24 — APIs sem consumidores | Removidos `useAppData`, os reexports antigos de tipos no provider, `ProfileDestination`, o adaptador antigo de `PrimaryButton` e a prop ignorada `immediate` de `TouchFeedback`. Os consumidores de tipos importam o domínio de localização diretamente. Adaptadores de campo que ainda têm consumidores e função de apresentação permanecem. |
| 25 — MapScreen | Separado em `MapSearch`, `MapResults`, `MapStatus`, `SelectedReport`, `MapActions`, `useMapResults` e estilos compartilhados. Seleção e carregamento regional continuam nos hooks já existentes. O arquivo principal passou de aproximadamente 840 para 391 linhas nesta revisão; o objetivo é separar responsabilidades, não apenas reduzir a contagem. |
| 26 — PlaceCard | Extraídos `PlaceHeader`, `PlaceMedia`, `PlaceActions`, `PlaceSources`, `usePlaceCardMotion` e estilos. O orquestrador ficou com 154 linhas; o resumo da comunidade continua em seu componente próprio. |
| 27 — distância | Calculada uma vez por mudança das coordenadas/localização com memoização, e reutilizada para formatar metros ou quilômetros. |
| 28 — acesso a dados | Consultas e ações antes executadas em telas/providers foram movidas para services de avaliações, perfil, conta, sessão e edição administrativa de lugares. Providers cuidam de ciclo de vida, estado e descarte de respostas; telas cuidam da interação. A consulta de votos saiu do hook de participação para o módulo de acesso a dados da feature. A regra de lint `elas/data-boundary` impede importar clientes Supabase diretamente nos arquivos TSX cobertos. |
| 29 — carregamento sob demanda | Os lugares já eram buscados pela região do mapa quando a tela recebia foco. Os fatores de avaliação deixaram de carregar no login: agora carregam na primeira abertura do formulário. Pedidos simultâneos compartilham a mesma Promise, resultados prontos são reutilizados, falhas permitem retry e respostas de uma conta anterior são descartadas. Atualizar fatores não busca mais uma região inicial do mapa. |

## Verificação

`npm run verify` passou integralmente, incluindo TypeScript, ESLint, banco simulado, fluxos de produção/demonstração, formulários, novos testes de arquitetura, estabilidade do mapa, regras de zoom/categoria, importações, estado, atualização atômica e desempenho.

Os testes montam os componentes extraídos do mapa no teste de estabilidade, mantendo a medição dos controles separada dos avisos transitórios. A seleção continua estabilizando após uma requisição, com 20 ciclos de layout/carregamento sem loop; pan e filtros continuam funcionando.

Os testes do PlaceCard cobrem distância, foto/créditos/licença, falha de mídia e recuperação ao trocar de lugar, navegação para melhoria/correção, avaliação e fechamento. O menu central é verificado quanto ao label visível/acessível e à ação resultante. Há testes do default genérico de confirmação e da transição com fechamento interrompido/reabertura e movimento reduzido.

Os testes de services verificam filtro de proprietário, paginação com lookahead, propagação de erro e payload de avaliação. Os testes de senha verificam que a checagem de senha atual usa cliente isolado, rejeita outra conta antes de atualizar a senha e encerra esse cliente em caso de erro. A recuperação continua isolada da sessão comum.

Uma consulta somente de leitura ao banco conectado confirmou seis fatores com IDs e nomes válidos. Não houve migração nem alteração de dados de produção. As regras de RLS e as autorizações do servidor foram preservadas.

`npx expo export --platform all` concluiu os bundles de Android, iOS e web. Não equivale a APK/IPA assinado ou publicação.

## Limites e próximos blocos

A revisão focou nos dois componentes apontados como principais concentradores de responsabilidades. CityMap, ReviewForm, ImprovementRequest, Novo Relato, Eventos, AdminScreen e PlacePicker ainda merecem decomposição incremental; não foram todos reescritos neste bloco.

Alguns módulos de acesso a dados existentes continuam organizados dentro da respectiva feature em arquivos `.ts`. As telas e providers TSX não importam mais os clientes de banco diretamente. O perfil básico e o papel do usuário continuam sendo carregados globalmente porque são usados na navegação e autorização da interface; não foi aplicado lazy loading indiscriminado a dados necessários.

Não houve inspeção visual em navegador nem teste em dispositivo real neste ambiente. Hosts nativos simulados não medem pixels, teclado, áreas seguras ou fluidez real. Continuam pendentes validação em Android/iPhone, monitoramento e avaliação de prontidão para escala pública.
