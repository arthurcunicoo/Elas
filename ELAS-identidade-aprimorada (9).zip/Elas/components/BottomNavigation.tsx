import { colors, palette, radius, typography } from "../constants/theme";
import { type ComponentProps, useEffect, useRef } from "react";
import { Animated, Platform, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "./icons/Ionicon";
import { TouchFeedback } from "./TouchFeedback";

import { useReducedMotion } from "../hooks/useReducedMotion";
function NavMotion({
  active,
  children,
}: {
  active: boolean;
  children: React.ReactNode;
}) {
  const reduced = useReducedMotion();
  const value = useRef(new Animated.Value(active ? 1 : 0)).current;
  useEffect(() => {
    const animation = Animated.spring(value, {
      toValue: active && !reduced ? 1 : 0,
      stiffness: 300,
      damping: 25,
      useNativeDriver: Platform.OS !== "web",
    });
    animation.start();
    return () => animation.stop();
  }, [active, reduced, value]);
  return (
    <Animated.View
      style={{
        width: "100%",
        alignItems: "center",
        transform: [
          {
            translateY: value.interpolate({
              inputRange: [0, 1],
              outputRange: [0, -1],
            }),
          },
        ],
      }}
    >
      {children}
    </Animated.View>
  );
}
type Icon = ComponentProps<typeof Ionicons>["name"];
const items: { label: string; icon: Icon; activeIcon: Icon }[] = [
  { label: "Mapa", icon: "location-outline", activeIcon: "location" },
  { label: "Eventos", icon: "calendar-outline", activeIcon: "calendar" },
  { label: "Participar", icon: "add", activeIcon: "add" },
  {
    label: "Relatos",
    icon: "document-text-outline",
    activeIcon: "document-text",
  },
  { label: "Perfil", icon: "person-outline", activeIcon: "person" },
];
export function BottomNavigation({
  onAction,
  active = "Perfil",
  addLabel = "Participar",
  addAccessibilityLabel,
}: {
  onAction: (label: string) => void;
  active?: "Mapa" | "Eventos" | "Relatos" | "Perfil";
  addLabel?: string;
  addAccessibilityLabel?: string;
}) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.bar, { paddingBottom: Math.max(8, insets.bottom) }]}>
      {items.map((item) =>
        item.label === "Participar" ? (
          <TouchFeedback
            key={item.label}
            testID="nav-participate"
            label={addAccessibilityLabel ?? addLabel}
            onPress={() => onAction(item.label)}
            pressedScale={0.94}
            style={styles.addItem}
          >
            <View style={styles.add}>
              <Ionicons name="add" color={colors.white} size={29} />
            </View>
            <Text style={styles.addLabel}>{addLabel}</Text>
          </TouchFeedback>
        ) : (
          <TouchFeedback
            key={item.label}
            testID={`nav-${item.label === "Mapa" ? "map" : item.label === "Eventos" ? "events" : item.label === "Relatos" ? "reports" : "profile"}`}
            role="tab"
            label={item.label}
            selected={item.label === active}
            onPress={() => onAction(item.label)}
            style={styles.item}
          >
            <NavMotion active={item.label === active}>
              <View
                style={[
                  styles.icon,
                  item.label === active && styles.selectedIcon,
                ]}
              >
                <Ionicons
                  name={item.label === active ? item.activeIcon : item.icon}
                  size={23}
                  color={item.label === active ? colors.pink : palette.muted}
                />
              </View>
              <Text
                style={[styles.label, item.label === active && styles.active]}
              >
                {item.label}
              </Text>
            </NavMotion>
          </TouchFeedback>
        ),
      )}
    </View>
  );
}
const styles = StyleSheet.create({
  bar: {
    flexDirection: "row",
    paddingTop: 8,
    paddingHorizontal: 8,
    minHeight: 80,
    alignItems: "center",
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: palette.border,
  },
  item: {
    flex: 1,
    minWidth: 0,
    minHeight: 58,
    alignItems: "center",
    justifyContent: "center",
  },
  icon: {
    width: 48,
    height: 31,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: radius.medium,
    marginBottom: 4,
  },
  selectedIcon: { backgroundColor: colors.cream },
  label: {
    fontSize: typography.caption,
    lineHeight: 18,
    color: palette.muted,
    textAlign: "center",
    maxWidth: "100%",
  },
  active: { color: colors.pink, fontWeight: "700" },
  addItem: {
    flex: 1,
    minWidth: 0,
    alignItems: "center",
    minHeight: 62,
    marginTop: -17,
  },
  add: {
    width: 56,
    height: 56,
    borderRadius: radius.pill,
    backgroundColor: colors.pink,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 4,
    borderColor: colors.white,
  },
  addLabel: {
    color: colors.pink,
    fontSize: typography.caption,
    lineHeight: 18,
    marginTop: 2,
    fontWeight: "600",
  },
});
