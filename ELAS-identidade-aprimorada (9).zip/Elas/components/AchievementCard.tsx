import { cardSurface, colors, typography, ui } from "../constants/theme";
import { StyleSheet, Text, View } from "react-native";
import MaterialCommunityIcons from "./icons/CommunityIcon";

import { Achievement, achievements } from "../constants/achievements";
import { AchievementProgressBar } from "./AchievementProgressBar";
import { TouchFeedback } from "./TouchFeedback";
export function AchievementCard({
  onMore,
  count,
  items = achievements,
}: {
  count?: number | null;
  items?: readonly Achievement[];
  onMore: () => void;
}) {
  return (
    <View style={styles.card}>
      <View style={styles.topRow}>
        <Text accessibilityRole="header" style={styles.heading}>
          Conquistas
        </Text>
        <View style={styles.summary}>
          <Text style={styles.number}>
            {count === undefined ? 7 : (count ?? "—")}
          </Text>
          <Text style={styles.reviews}>avaliações</Text>
        </View>
      </View>
      {items
        .filter((item) => !item.completed)
        .slice(0, 2)
        .map((item) => (
          <View key={item.title} style={styles.row}>
            <MaterialCommunityIcons
              name={item.icon}
              size={28}
              color={item.color}
              style={{ marginTop: 2, flexShrink: 0 }}
            />
            <View style={styles.detail}>
              <Text style={styles.title}>{item.title}</Text>
              <Text style={styles.description}>{item.description}</Text>
              <AchievementProgressBar
                compact
                value={item.value}
                total={item.total}
              />
            </View>
          </View>
        ))}
      <TouchFeedback
        label="Ver todas as conquistas"
        onPress={onMore}
        style={styles.more}
      >
        <Text style={styles.moreText}>Ver todas as conquistas</Text>
      </TouchFeedback>
    </View>
  );
}
const styles = StyleSheet.create({
  card: { ...cardSurface },
  topRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    flexWrap: "wrap",
    marginBottom: 14,
  },
  summary: { flexDirection: "row", alignItems: "center", gap: 5 },
  number: { color: colors.wine, fontSize: 20, fontWeight: "700" },
  reviews: { color: ui.muted, fontSize: typography.caption },
  heading: { color: ui.text, fontSize: typography.input, fontWeight: "600" },
  row: { flexDirection: "row", gap: 10, marginBottom: 14 },
  detail: { flex: 1, minWidth: 0 },
  title: {
    color: ui.text,
    fontSize: typography.body,
    lineHeight: 20,
    fontWeight: "600",
  },
  description: {
    color: ui.muted,
    fontSize: typography.caption,
    lineHeight: 18,
    marginTop: 1,
  },
  more: {
    alignSelf: "stretch",
    minHeight: 44,
    marginTop: 0,
    paddingHorizontal: 12,
  },
  moreText: {
    color: colors.pink,
    fontSize: typography.secondary,
    fontWeight: "600",
    textAlign: "center",
  },
});
