# Correções por prioridade — 19/10/2026

O ciclo principal agora está conectado: avaliação enviada → moderação → resumo agregado → mapa e detalhes. O app continua em React Native/Expo, com a marca, paleta rosa/vinho, prédios e quatro carinhas preservados. Esta entrega corrige os problemas confirmados de maior prioridade; não certifica o lançamento público.

## O que mudou

| Problema confirmado | Resultado nesta entrega |
| --- | --- |
| Avaliações aprovadas não chegavam aos outros usuários | Nova RPC autenticada `resumos_avaliacoes`, com agregação no servidor. As avaliações individuais continuam privadas. |
| Lugares reais sempre tinham status desconhecido | Catálogo, busca e resolução de um lugar recebem o resumo real. O status é derivado das percepções aprovadas, quando há amostra suficiente. |
| Detalhes só exibiam reviews fictícias | Detalhes mostram contagem, distribuição, período, método, estado vazio e tentativa de atualização dos dados reais. |
| Cache podia manter percepções antigas | Cada nova leitura da área e retorno ao mapa atualiza os resumos, mesmo reutilizando o catálogo em cache. O lugar selecionado também é atualizado. Falhas são identificadas como indisponibilidade. |
| Demonstração automática ocultava base vazia | Exemplos do banco exigem `EXPO_PUBLIC_SHOWCASE=1` **e** build de desenvolvimento. Há um aviso geral e identificação em cada exemplo. Builds de produção exibem estados vazios reais. |
| Ausência de configuração parecia demonstração | Sem configuração válida, o app informa o problema. A demonstração offline exige `npm run demo` ou `EXPO_PUBLIC_DEMO=1`. |
| Botão central ambíguo | “Participar” abre duas escolhas explícitas: avaliar um lugar ou relatar uma situação, mantendo o lugar selecionado como contexto. |
| Enquetes duplicadas e rótulos confusos | “Consultas” virou “Enquetes”, sem repetição acima da lista de eventos. Em Alertas, “Relatos da cidade” e “Minhas notificações” distinguem os conteúdos. |
| Logo e imagem de lugar eram recortes de screenshots | Logo vetorizada a partir da referência. Removidos `ReferenceCrop` e os dois screenshots. Lugares sem foto usam um placeholder; fotos reais e suas fontes permanecem. |
| Layout inicial dependia de uma proporção fixa da altura | Logo e ações usam fluxo normal, flex e rolagem. |
| Toques e listas tinham atrasos artificiais | Ação do toque imediata; animação em press-in/out. Entradas têm duração máxima de 350 ms e delay máximo de 180 ms, sem repetir ao retornar o foco. Skyline mantém entrada e repousa. |
| Textos auxiliares de 10–11 px | Tamanhos explícitos desses textos elevados para 12, incluindo porcentagens, status e selo de demonstração. Não substitui a avaliação visual de fonte ampliada em aparelho. |
| Seleção de relato mudava o zoom nativo | Preserva os deltas atuais. Mudanças reais de contagem/status atualizam o bitmap do marcador nativo. |
| Toda falha do SchemaGate parecia atualização pendente | Conexão, timeout, indisponibilidade, sessão e versão incompatível têm mensagens distintas e nova tentativa. Respostas de uma conta anterior são descartadas. |
| Impactos fazia quatro consultas | Nova RPC `resumo_impactos` devolve contagens e os 20 registros recentes em uma consulta, respeitando a mesma RLS. |
| Serviços recebiam um usuário que não era usado | Removido esse parâmetro de envio de relatos/melhorias. A identidade continua vindo de `auth.uid()` no servidor. |
| Atualizador SQL estava atrasado | `supabase/ATUALIZACAO.sql` inclui as cinco migrations posteriores à base original, numa única transação, com trava e histórico. Testado rollback após falha tardia e execução repetida sem duplicar estruturas. |
| Ausência de rotina única de validação | `npm run verify` reúne as verificações. Workflow GitHub Actions adicionado para testes e compilação Android/iOS/web, sem deploy ou credenciais. Ainda não foi executado num repositório GitHub. |

## Como interpretar as avaliações

- Considera uma contribuição por **conta e lugar**, aprovada e criada/revisada pelo autor nos últimos **180 dias**.
- A contagem aparece mesmo abaixo de cinco contribuições. Distribuição, data agregada e indicação coletiva exigem **pelo menos cinco** contribuições aprovadas no período.
- Com amostra suficiente: **70% ou mais “Segura”** → percepções favoráveis; **50% ou mais “Atenção” + “Cuidado”** → percepções de atenção; outros resultados → percepções variadas.
- Os pins mantêm cores/ícones das categorias. O pequeno selo numérico indica avaliações aprovadas; sua cor acompanha a indicação coletiva quando disponível. Números em grupos de pins contam lugares.
- Editar uma avaliação aprovada a retira do resumo até nova aprovação; rejeitar, excluir ou expirar também a retira. A moderação não renova a data da experiência.
- São regras iniciais de produto, documentadas na interface, e não uma garantia de segurança ou um índice oficial. Cinco contas não comprovam cinco pessoas distintas.
- A RPC não retorna autoria, comentários, fatores ou IDs de avaliações. Nenhuma política foi aberta para leitura pública das avaliações individuais.

## Banco remoto conferido

Projeto `pxcbzjxgxdmdayqwpqcj`: migration **20261019161613_community_review_summaries** aplicada; `versao_app()` = **5**, com **11 migrations** no histórico. Tipos TypeScript regenerados do schema remoto.

Estado preservado: **1.535 lugares, 3 relatos, 0 avaliações reais e 25 exemplos fictícios**. Não foram criadas avaliações falsas em contas reais. A base vazia de avaliações agora aparece corretamente; novas contribuições aprovadas alimentarão os resumos.

As novas RPCs negam acesso anônimo. Leituras remotas com papel autenticado e identidade de teste confirmaram resumos vazios reais e contagens de impactos zeradas. Essas verificações usaram contexto SQL dentro de transação com rollback, **não um novo login HTTP nem um E2E em dispositivo**.

O advisor de segurança manteve os avisos anteriores: proteção contra senhas vazadas desabilitada e quatro informações de RLS sem política em tabelas cujo acesso direto é intencionalmente fechado. Não houve nova abertura de avaliações brutas. A configuração Auth não foi alterada nesta etapa.

**Neste projeto ativo, não precisa executar SQL novamente.** Para outra instalação já baseada nas seis migrations originais, o atualizador completo está em `supabase/ATUALIZACAO.sql`. Para projeto novo, aplique todas as migrations na ordem; use seed apenas em desenvolvimento separado. Não faça reset/seed no banco ativo.

## Verificação executada

- TypeScript e ESLint passaram.
- `npm run verify` passou: testes de banco/RLS, ciclo das avaliações, isolamento por conta, demonstração, formulários, mapa, relevância/zoom, geometria, estado/cache, transporte OSM simulado, conciliação Overture e atualizador SQL.
- O banco isolado PGlite validou: pendente → aprovada → editada → reaprovada → rejeitada/excluída; janela expirada/revisada; limiar de cinco contas; privacidade; limites de até 600 lugares por chamada; impactos com RLS.
- Componentes React reais foram montados com hosts nativos simulados: dados frescos com catálogo em cache, estabilidade dos marcadores, falhas sem falso zero, mudança de conta, botões imediatos, entradas curtas, distribuição e escolha de participação.
- Regressão do mapa continuou estável após 20 ciclos de carregamento/layout, sem reabrir o indicador de atualização em loop.
- `npx expo export --platform all` gerou bundles Android, iOS e web. Isso verifica compilação JavaScript/Hermes, não um APK/IPA assinado.
- A logo vetorial foi renderizada para inspeção. Não houve verificação visual das telas em navegador ou aparelho nesta etapa.

## Próximos bloqueios de lançamento

| Item ainda pendente | Validação necessária |
| --- | --- |
| Dispositivos e acessibilidade | Android e iOS reais: telas pequenas, fontes 100/130/160%, teclado, safe areas, ícones, gestos, permissão negada e rede instável. Medir FPS/memória em aparelho intermediário. |
| E2E real | Cadastro/recuperação, login/logout, envio com moderação por outra conta, retorno ao mapa, edição/exclusão e repetição após falha de rede. As verificações montadas não equivalem a esse fluxo completo. |
| Tráfego e mapa em escala | Provedor de tiles apropriado ao volume; carga concorrente; agrupamento de relatos; limites/visibilidade de muitos relatos. Não foi substituído o provedor atual. |
| Consultas volumosas | Busca indexada por texto, paginação por cursor e consulta geoespacial no servidor precisam de medição antes de substituir os contratos existentes. OFFSET e a shortlist atual ainda existem. |
| Operação | Escolha/configuração de monitoramento remoto, alertas operacionais, retenção dos envios idempotentes, backup/restauração e proteção Auth. Não foi contratado nem ativado serviço externo. |
| Sistema visual e manutenção | Unificar gradualmente tokens, headers/formulários e separar módulos grandes, com comparação visual em dispositivos. Não houve refatoração em massa baseada apenas na contagem de linhas ou de cores. |

Para abrir: `npm ci` e `npm start`. Para testar: `npm run verify`. A dependência SVG foi incluída no lockfile; um build nativo próprio precisa ser recompilado após atualizar dependências. O modo de apresentação conectado usa `EXPO_PUBLIC_SHOWCASE=1` no ambiente de desenvolvimento e reinício do Expo; não altera os registros reais.
