// Explicit presentation switches. A release build never auto-fills an empty live database.
export const demoMode = process.env.EXPO_PUBLIC_DEMO === "1";
export const showcaseEnabled =
  typeof __DEV__ !== "undefined" &&
  __DEV__ &&
  process.env.EXPO_PUBLIC_SHOWCASE === "1";
