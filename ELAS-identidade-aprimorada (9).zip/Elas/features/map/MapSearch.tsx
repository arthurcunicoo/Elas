import { LoadingIndicator } from "../../components/loading/LoadingIndicator";
import { Platform, ScrollView, Text, TextInput, View } from "react-native";
import Ionicons from "../../components/icons/Ionicon";
import { TouchFeedback } from "../../components/TouchFeedback";
import { colors, palette } from "../../constants/theme";
import { styles } from "./mapStyles";
import { type ReactNode } from "react";
import { CategoryId, placeCategories } from "../../constants/placeCategories";
import { MotionReveal } from "../../components/MotionReveal";
type Props = {
  query: string;
  focused: boolean;
  locating: boolean;
  hasLocation: boolean;
  showScopes: boolean;
  scope: "area" | "catalog";
  filter: CategoryId;
  top: number;
  children: ReactNode;
  onHeight: (height: number) => void;
  onQueryChange: (query: string) => void;
  onFocus: () => void;
  onSubmit: () => void;
  onFilters: () => void;
  onLocate: () => void;
  onScopeChange: (scope: "area" | "catalog") => void;
  onFilterChange: (category: CategoryId) => void;
};
export function MapSearch({
  query,
  focused,
  locating,
  hasLocation,
  showScopes,
  scope,
  filter,
  top,
  children,
  onHeight,
  onQueryChange,
  onFocus,
  onSubmit,
  onFilters,
  onLocate,
  onScopeChange,
  onFilterChange,
}: Props) {
  return (
    <View pointerEvents="box-none" style={[styles.searchArea, { top: top }]}>
      <View onLayout={(e) => onHeight(Math.round(e.nativeEvent.layout.height))}>
        <MotionReveal duration={300} distance={-8}>
          <View style={styles.searchRow}>
            <View style={[styles.searchBox, focused && styles.focused]}>
              <Ionicons name="search" size={25} color={palette.overlay} />
              <TextInput
                testID="map-search"
                accessibilityLabel="Buscar um lugar"
                placeholder="Buscar um lugar"
                placeholderTextColor={palette.overlay}
                value={query}
                onChangeText={onQueryChange}
                onFocus={onFocus}
                autoCorrect={false}
                returnKeyType="search"
                onSubmitEditing={onSubmit}
                underlineColorAndroid="transparent"
                style={[styles.input, Platform.OS === "web" && styles.webInput]}
              />
            </View>
            <TouchFeedback
              label="Abrir filtros"
              onPress={onFilters}
              style={styles.filter}
            >
              <Ionicons name="options-outline" size={29} color={palette.text} />
            </TouchFeedback>
            <TouchFeedback
              testID="map-locate"
              label="Minha localização"
              busy={locating}
              disabled={locating}
              onPress={onLocate}
              style={styles.filter}
            >
              {locating ? (
                <LoadingIndicator />
              ) : (
                <Ionicons
                  name="locate-outline"
                  size={25}
                  color={hasLocation ? colors.pink : palette.text}
                />
              )}
            </TouchFeedback>
          </View>
        </MotionReveal>
        {showScopes ? (
          <View style={styles.scopeRow}>
            {(["area", "catalog"] as const).map((s) => (
              <TouchFeedback
                key={s}
                label={
                  s === "area"
                    ? "Buscar na área visível"
                    : "Buscar entre os lugares cadastrados"
                }
                selected={scope === s}
                onPress={() => onScopeChange(s)}
                style={[styles.scopeButton, scope === s && styles.activeScope]}
              >
                <Text
                  style={[
                    styles.scopeText,
                    scope === s && { color: colors.pink, fontWeight: "700" },
                  ]}
                >
                  {s === "area" ? "Nesta área" : "Lugares cadastrados"}
                </Text>
              </TouchFeedback>
            ))}
          </View>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoryStrip}
          >
            {placeCategories
              .filter((c) =>
                ["all", "parks", "restaurants", "cafes", filter].includes(c.id),
              )
              .map((c) => (
                <TouchFeedback
                  key={c.id}
                  label={`Filtrar ${c.label}`}
                  selected={filter === c.id}
                  onPress={() => onFilterChange(c.id)}
                  style={[
                    styles.categoryChip,
                    filter === c.id && styles.selectedChip,
                  ]}
                >
                  <Ionicons
                    name={c.icon}
                    size={16}
                    color={filter === c.id ? colors.white : colors.pink}
                  />
                  <Text
                    style={[
                      styles.chipText,
                      filter === c.id && { color: colors.white },
                    ]}
                  >
                    {c.label}
                  </Text>
                </TouchFeedback>
              ))}
          </ScrollView>
        )}
      </View>
      {children}
    </View>
  );
}
