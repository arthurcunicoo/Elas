# Pontos 61–63 — retenção, moderação e push

Base: **último ZIP entregue, versão 19**, conferido byte a byte antes das alterações. Entregas anteriores preservadas. Projeto conectado no **schema 11**, com **20 migrações**; atualização atômica/tipos atualizados.

| Ponto | Entrega | Limite |
| --- | --- | --- |
| 61 | Retenção inicial de 30 dias, holds com prazo/motivo, lotes/índice/cron horário e fingerprint no conteúdo preservado. | Limpeza real manual não executada; tabela estava vazia. Auditoria/backlog exigem operação. |
| 62 | Fila inicial de pendências, cursor/feedback/paginação explícita, revisão de conteúdo/status, recarga após conflito e histórico. | Lotes, reservas e editor/histórico de papéis seguem no backlog. |
| 63 | Opt-in, registro/rotação/revogação, outbox privada, worker Expo, tickets/recibos/retries. Função publicada. | Push desativado; credenciais/build, instalação do agendamento e recebimento real pendentes. Alertas geográficos são outra etapa. |

## Verificação

Suíte anterior mantida. Testes novos usam PostgreSQL local com Auth/Storage simulados: retenção/holds, replay após limpeza/edição, autorização, revisão/ABA, tokens, leases, recibos e cancelamento. Testes cliente exercitam consentimento, rotação, logout, troca de conta e toques com APIs nativas simuladas. Contratos HTTP Expo isolados; nenhuma notificação real enviada.

No Supabase: schema, cron de retenção ativo e grants conferidos por leitura. Clientes não leem tokens/fila nem executam worker. `push-delivery` v1 responde 401 sem segredo. Push desativado, sem projeto Expo/endpoint/dispositivos/fila. Nenhum usuário, relato ou avaliação de teste criado na base real.

Advisors mantêm o aviso anterior de proteção contra senhas vazadas desativada. Novas tabelas privadas têm RLS/acesso direto revogado intencionalmente; ausência de policies não significa acesso público. Índices novos ainda sem uso são esperados antes de dados/tráfego.

Exportações Expo Android/iOS/web e prebuild Android/iOS em cópia isolada passaram. No prebuild foram conferidos a declaração POST_NOTIFICATIONS da biblioteca, plugin/arquivo Google Services, pacote QA e entitlement APNs com valores fictícios. Isso não compila/assina o app nem valida FCM/APNs reais. O prebuild mantém o aviso anterior de ícone do aplicativo ausente, a resolver antes da loja. Atualização atômica e restauração local passaram com 20 migrações; restore em staging desativa configuração/fila de push da origem.

## Operação

- [Retenção e auditoria](docs/operations/RETENCAO-IDEMPOTENCIA.md)
- [Painel, conflitos e papéis](docs/operations/PAINEL-ADMIN.md)
- [Push: configuração e testes pendentes](docs/operations/PUSH.md)
- `qa/operations-queries.sql`: conferência somente por leitura.

## Ações bloqueadas pela revisão automática

Instalar segredo no Vault/agendamento push foi rejeitado por exigir autorização explícita para essa configuração operacional em produção. A limpeza manual foi rejeitada por poder excluir registro real; foi substituída por leitura de contagens/elegibilidade. Nenhuma ação foi repetida por outro caminho. Rotinas preparadas para execução autorizada quando recursos externos estiverem definidos.

Testes físicos, baselines, build assinado, Sentry real, SMTP, carga no staging e restauração remota anteriores continuam pendentes. Esta entrega não aprova lançamento público.
