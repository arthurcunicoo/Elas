import { buildQuery, parseOsmPlaces, type Bounds, type CatalogPlace } from "../lugares-osm/catalog.ts";
import { fetchOsmPayload } from "../lugares-osm/network.js";
export type CatalogLease = {
  lease: string;
  bounds: Bounds;
  area: { id: string; nome: string; estado: string };
};
export type WorkerStore = {
  reserve: (hash: string) => Promise<CatalogLease | null>;
  import: (places: CatalogPlace[]) => Promise<void>;
  finish: (
    lease: string,
    received: number,
    error: string | null,
  ) => Promise<void>;
};
export async function jobTokenHash(token: string) {
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(token),
  );
  return Array.from(new Uint8Array(digest))
    .map((n) => n.toString(16).padStart(2, "0"))
    .join("");
}
export function createRefreshHandler(
  store: WorkerStore,
  upstream: typeof fetch = fetch,
) {
  const reply = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      },
    });
  return async (req: Request) => {
    if (req.method !== "POST")
      return reply({ message: "Método inválido" }, 405);
    const token = req.headers.get("x-catalog-job-key");
    if (!token || !/^[a-f0-9]{64}$/.test(token))
      return reply({ message: "Acesso negado" }, 401);
    let lease: CatalogLease | null;
    try {
      lease = await store.reserve(await jobTokenHash(token));
    } catch {
      return reply({ message: "Acesso negado" }, 401);
    }
    if (!lease) return reply({ status: "idle" });
    let received = 0,
      error: string | null = null;
    try {
      const { payload } = await fetchOsmPayload(
        buildQuery(lease.bounds),
        upstream,
      );
      received = Math.min(400, payload.elements.length);
      const places = parseOsmPlaces(
        payload,
        lease.bounds,
        new Date().toISOString(),
        lease.area,
      );
      await store.import(places);
    } catch {
      error = "upstream_or_import_failed";
    }
    try {
      await store.finish(lease.lease, received, error);
    } catch {
      return reply({ status: "retry_after_lease" }, 503);
    }
    return reply(
      { status: error ? "retry_scheduled" : "updated", received },
      error ? 503 : 200,
    );
  };
}
