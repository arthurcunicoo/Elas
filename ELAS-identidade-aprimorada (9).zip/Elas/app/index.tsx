import { pageContent } from "../constants/theme";
import { ScrollView, StyleSheet, useWindowDimensions, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { MotionReveal } from "../components/MotionReveal";
import { Logo } from "../components/Logo";
import { PrimaryButton } from "../components/shared/Buttons";
import { AccountLink } from "../components/AccountLink";
export default function Welcome() {
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  return (
    <ScrollView
      contentContainerStyle={{
        flexGrow: 1,
        minHeight: height,
        paddingTop: insets.top + 24,
        paddingBottom: Math.max(insets.bottom, 20),
      }}
    >
      <View accessible accessibilityLabel="ELAS na cidade" style={styles.logo}>
        <MotionReveal distance={-18}>
          <Logo width={Math.min(width * 0.78, 340)} />
        </MotionReveal>
      </View>
      <View style={styles.space} />
      <View style={styles.actions}>
        <MotionReveal delay={80}>
          <PrimaryButton
            title="Começar"
            onPress={() => router.push("/login")}
          />
        </MotionReveal>
        <MotionReveal delay={120}>
          <AccountLink />
        </MotionReveal>
      </View>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  logo: { width: "100%", alignItems: "center" },
  space: { flex: 1, minHeight: 180 },
  actions: {
    ...pageContent,
    paddingTop: 24,
  },
});
