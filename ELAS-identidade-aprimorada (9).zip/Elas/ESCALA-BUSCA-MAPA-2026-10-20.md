# Busca, mapa e catálogo — 20/10/2026

Os pontos 31–40 foram implementados. O banco conectado está no schema **8**, com **15 migrações**; as duas funções de catálogo estão publicadas e o agendamento está ativo.

| Ponto | Alteração |
| --- | --- |
| 31 | `pg_trgm` e índices GIN para nome/endereço normalizados; busca aceita acentos e similaridade de nomes. |
| 32 | Relatos, melhorias, comentários de avaliações, lugares e perfis têm caminhos de busca indexados na API administrativa por cursor. |
| 33 | Lugares e relatos possuem `geography(Point,4326)` gerada pelas coordenadas e índices GiST. |
| 34 | O mapa deixa de cortar os relatos nos 100 mais recentes. Todos os registros visíveis da área consultada entram nas contagens. |
| 35 | Agregação no servidor devolve grupos com contagem, centro e limites. Ampliar refina a malha; no mesmo ponto, ou no zoom próximo, abre a lista inteira por cursor. |
| 36 | Web e mobile usam o mesmo `ReportMarker`, com símbolo de documento e contagem. O marcador não atribui gravidade a toda ocorrência. |
| 37 | Centro e tamanho da consulta são quantizados juntos, com margem que contém o viewport original. Pequenos deslocamentos reutilizam a consulta; aproximações usam outra chave. |
| 38 | O PostgreSQL seleciona no máximo 500 lugares por relevância e distribuição espacial, depois do recorte geográfico e da categoria. O cliente não recebe milhares para fazer essa seleção. |
| 39 | A navegação consulta o banco. Um worker separado atualiza o catálogo periodicamente, sem importação disparada pelo usuário. |
| 40 | `service_areas` define áreas ativas, prioridade, envelopes e centro inicial. O seletor de cidade e a localização usam esses dados. |

## Busca e seleção

A normalização conserva a busca sem acentos. Com um ou dois caracteres, a busca usa prefixo; com três ou mais, procura trechos e nomes semelhantes. Caracteres como `%` e `_` são tratados literalmente e não ampliam a consulta como curingas. A paginação continua com cursor e ordem estável por nome/ID; não foi inventado um índice de popularidade.

A relevância do mapa mantém a heurística existente de destaque e categoria. O valor é calculado no banco e compartilhado com o cliente. Destinos de destaque são preservados e as vagas restantes são distribuídas entre células geográficas. A redução visual por zoom continua no frontend, sobre uma resposta já limitada.

As APIs antigas permanecem disponíveis para instalações anteriores. Os caminhos ativos desta versão usam as novas consultas; as buscas legadas antigas não receberam uma migração geral para nova semântica.

## Relatos e privacidade

O mapa agrega apenas relatos verificados e pendentes da própria conta. Resolvidos, retirados e registros sem coordenadas ficam fora da camada ativa. A lista pessoal e os detalhes continuam disponíveis pelas rotas anteriores.

A consulta usa uma função interna com autorização explícita e saída controlada, exposta por uma função pública `SECURITY INVOKER`. Isso permite o filtro GiST antes da agregação, sem a barreira de RLS bloquear o operador geográfico. Não são retornados identificadores dos autores nem conteúdo de pendentes de outra pessoa. Não foi concedida leitura pública do campo geográfico dos relatos.

O limite defensivo é de 64 elementos agregados por resposta, com contagem completa; o pin selecionado pode aparecer como destaque adicional. Não há corte arbitrário dos registros que alimentam os grupos. A área consultada inclui uma pequena margem para o cache. Nos grupos coincidentes, a lista por cursor mantém acesso a todos os relatos permitidos, inclusive além dos antigos 100.

O cache de lugares e o de relatos são limitados por tamanho/tempo e separados por conta. Respostas antigas não substituem dados de uma sessão nova. Os marcadores nativos congelam a imagem após a atualização; a carga real de renderização ainda precisa ser medida em aparelhos.

## Atualização periódica

`catalog-refresh` está ativo e o job `elas-catalog-refresh` executa a cada **10 minutos**, em UTC. Cada execução reserva uma célula e processa até 400 elementos da fonte, respeitando o limite existente do Overpass. Regiões saturadas são subdivididas; falhas geram retentativa com espera progressiva. A reserva tem prazo para permitir recuperação após interrupção. Uma célula concluída volta à fila depois de um dia; isso não é uma promessa de cobertura diária completa para qualquer volume de cidades.

O segredo de máquina fica no Vault; as RPCs de reserva, conclusão e candidatos de importação são restritas a `service_role`. O endpoint verifica o segredo antes de consultar a fonte. A chave administrativa não vai para o frontend nem para o cron. O endpoint legado `lugares-osm`, versão 13, agora é uma ponte de leitura; não dispara importações. `catalog-refresh` foi publicado na versão 1.

A primeira execução online chegou ao worker e criou a fila de 81 células. Ela e a primeira execução do cron terminaram com `retry_scheduled`, sem importar dados. Os logs confirmaram resposta HTTP 406 do Overpass nas duas tentativas; as retentativas respeitam a espera da fila. Portanto, o fluxo de autenticação/reserva/retentativa foi confirmado online; uma importação externa bem-sucedida nesta etapa **não foi confirmada**. O catálogo existente continuou legível pelo banco. As regras de importação, sucesso, falha e quota também foram exercitadas com respostas simuladas.

Consulte `supabase/CATALOGO-OPERACAO.sql` para acompanhar fila, erros e execução, sem exibir segredos.

## Áreas e instalação

Somente Criciúma permanece habilitada neste projeto. Florianópolis foi exercitada em banco isolado para comprovar que outra cidade não exige alteração no código. Não foram adicionados dados fictícios de outra cidade na base conectada. Os envelopes são áreas retangulares de atendimento, não limites municipais oficiais.

Para outra instalação, aplique as migrações em ordem, publique os dois endpoints e execute como proprietário:

```sql
select private.programar_catalogo('https://seu-projeto.supabase.co/functions/v1/catalog-refresh');
```

O SQL não contém segredo ou ID de projeto embutido. A atualização atômica foi regenerada; requer as seis migrações de base, preserva dados e não reaplica versões já registradas. PostGIS deve estar no schema `gis`; se já existir em outro schema, revise os qualificadores antes de aplicar, sem remover uma extensão com dados existentes.

Migrações aplicadas: `20261020142143_spatial_search_service_areas.sql` e `20261020142203_catalog_background_job.sql`.

## Verificação e limites

- `npm run verify` passou; as alterações finais também passaram em tipagem, lint, testes de banco/comunidade e testes espaciais.
- PGlite com **PostGIS e pg_trgm reais**: 831 relatos visíveis, 431 coincidentes com acesso completo por cursor, separação entre contas, planos elegíveis para GIN/GiST, 1.403 lugares reduzidos a 500 no SQL, busca por erro/acento/literal, segunda cidade, reservas, subdivisão, espera e proteção de APIs de máquina.
- React em hosts simulados: mesmo símbolo e ações nas duas plataformas, cache/margem em 2.000 regiões, mudança de zoom, conta e retentativa. A regressão do mapa continua estabilizando após uma consulta e 20 ciclos de layout.
- Checagem Deno dos dois endpoints passou. Exportação Expo para Android, iOS e web concluída; não é APK/IPA assinado.
- Leitura autenticada no Supabase confirmou contratos, contagens, limites e bloqueio das RPCs de máquina para clientes. O cron foi confirmado ativo.
- Na aplicação das migrações foram preservados 1.535 lugares, três relatos, zero avaliações reais e zero solicitações reais. O job pode atualizar/adicionar lugares externos depois dessa verificação.

Continuam pendentes teste de carga, monitoramento com metas operacionais, importação externa bem-sucedida observada nesta etapa e validação visual/de desempenho em Android/iPhone reais. A preparação estrutural não equivale a liberação pública em escala.

O diagnóstico de segurança manteve os avisos anteriores: [RLS sem políticas em quatro tabelas internas](https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy) e [proteção contra senhas vazadas desativada](https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection). Desempenho manteve a [FK antiga sem índice](https://supabase.com/docs/guides/database/database-linter?lint=0001_unindexed_foreign_keys) e registra [índices ainda sem uso](https://supabase.com/docs/guides/database/database-linter?lint=0005_unused_index). Nenhum índice foi removido sem evidência de tráfego.

Referências: [PostGIS no Supabase](https://supabase.com/docs/guides/database/extensions/postgis), [agendamento de Edge Functions](https://supabase.com/docs/guides/functions/schedule-functions), [pg_trgm](https://www.postgresql.org/docs/current/pgtrgm.html) e [extensões do PGlite](https://pglite.dev/extensions/).
