import { useState } from "react";
import { useNavigation, usePreventRemove } from "@react-navigation/native";
import { ProfileDialog, ProfileNotice } from "./ProfileDialog";
export function DraftGuard({
  enabled,
  saved = true,
}: {
  enabled: boolean;
  saved?: boolean;
}) {
  const navigation = useNavigation(),
    [notice, setNotice] = useState<ProfileNotice | null>(null);
  usePreventRemove(enabled, ({ data }) =>
    setNotice({
      title: "Sair sem enviar?",
      message: saved
        ? "Seu rascunho ficará salvo neste aparelho por até 24 horas. Ele será apagado quando você sair da conta."
        : "Não foi possível salvar o rascunho neste aparelho. Sair agora pode perder os campos preenchidos.",
      confirmLabel: "Sair e guardar",
      confirm: () => navigation.dispatch(data.action),
    }),
  );
  return <ProfileDialog notice={notice} onClose={() => setNotice(null)} />;
}
