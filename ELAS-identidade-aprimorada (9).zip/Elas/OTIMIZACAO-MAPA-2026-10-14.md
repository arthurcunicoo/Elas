# ELAS — carregamento e desempenho do mapa

## Ajuste de 15/10/2026 — aviso sobre o mapa

A faixa com texto longo, enviada na captura do usuário, foi substituída por um botão branco compacto: “Sobre a área” para informações ou “Ver aviso” para falhas. O texto completo abre no diálogo já usado pelo app, com rolagem e fechamento. Informações oferecem “Buscar na lista”, que abre a busca paginada em todos os lugares cadastrados; falhas oferecem “Tentar novamente”. A abertura do diálogo mantém uma cópia da mensagem para que uma atualização do catálogo não a apague durante a leitura. O limite de lugares por resposta, os agrupamentos e as otimizações anteriores foram preservados. Apenas a tela do mapa foi modificada; nenhuma alteração remota ou de banco foi feita neste ajuste.

Validação: TypeScript, ESLint e exportação de produção web. A conferência visual em execução continua limitada pela indisponibilidade da prévia local neste ambiente.

Base: versão de 13/10/2026 com catálogo Overture, React Native 0.83 e Expo SDK 55. Plataforma priorizada: navegador, conforme informado pelo usuário. Identidade original, imagens, carinhas de avaliação e navegação preservadas.

## Mudanças

- Popup de abertura com a paleta rosa/vinho, imagem da cidade, estados reais do mapa e do catálogo, opção de continuar e nova tentativa em caso de falha. Respeita redução de movimento e áreas seguras. Após 8 segundos explica a demora; após 20 segundos sem resposta do mapa oferece recuperação. Não exibe porcentagem inventada.
- Atualizações de área usam um indicador discreto e não reabrem o popup. Erros e avisos continuam acessíveis.
- A função `lugares-osm` lê o catálogo cadastrado independentemente do Overpass. A importação externa é mantida viva por `EdgeRuntime.waitUntil`, com erros tratados, autenticação, limite de área e reserva compartilhada preservados. `updatedAt` continua sendo a data efetiva da importação, nunca a hora de uma tentativa.
- Áreas recém-visitadas ficam em memória por 60 segundos, com no máximo 8 respostas e compartilhamento de requisições simultâneas. Atualização manual ignora o prazo. Trocar ou sair da conta limpa o cache e descarta resultados da conta anterior. Não há armazenamento persistente de relatos ou credenciais.
- A identidade da consulta usa a mesma grade de 0,01° do servidor. Pequenos movimentos dentro da mesma área não reiniciam a consulta. A geometria de zoom permanece precisa.
- No navegador, eventos de arrasto são agrupados por `requestAnimationFrame`; a região é comunicada à tela após o gesto. Os pontos mantêm o agrupamento durante o arrasto e se movem como uma camada. Os tiles são reposicionados como camada, com imagens reutilizadas por URL.
- Agrupamentos e marcadores usam referências estáveis/memoização. Na versão nativa, os marcadores compartilham a preferência de redução de movimento recebida do mapa, e `tracksViewChanges` continua limitado à atualização visual.
- Ícones importam apenas suas famílias. O botão de impactos usa o prédio do Ionicons, evitando carregar uma segunda fonte só para ele.
- Rotas web de produção usam divisão de bundle pelo Expo Router. Android/iOS continuam com rotas síncronas. Nenhuma atualização de SDK ou biblioteca foi necessária.
- O timeout do catálogo passou de 55 para 20 segundos, pois a resposta não espera as duas consultas externas de até 20 segundos cada.
- Apenas uma consulta posterior é agendada após 30 segundos quando uma área está vazia e sendo importada; não há polling contínuo. Nas demais áreas, importações aparecem na próxima consulta ou atualização manual.

## Evidências e limites

| Verificação | Resultado |
| --- | --- |
| Consulta real do banco, área central e limite 501 | 3,127 ms de execução, `EXPLAIN ANALYZE` |
| Scripts iniciais no HTML da exportação anterior | 2.163.813 bytes |
| Scripts iniciais no HTML da nova exportação | 1.733.882 bytes |
| Redução desses scripts, sem compressão HTTP | 19,87% |
| Arquivos de imagens da versão anterior | Todos byte a byte preservados |
| TypeScript e ESLint | Passaram |
| Testes de desempenho, estado, OSM e layout móvel | Passaram |
| Testes existentes de categorias do mapa | 27 verificações passaram |
| Exportação de produção web, Android e iOS | Passou |
| Função no projeto Supabase conectado | `lugares-osm`, versão 11, ACTIVE, JWT obrigatório |

Os testes de desempenho confirmam resposta com lugares salvos enquanto a promessa externa continua pendente; importação posterior; falha externa sem rejeição não tratada; deduplicação/expiração/evicção do cache; isolamento entre contas; preservação de objetos de marcadores; e 1.000 eventos de gesto agrupados em um frame. As respostas externas desses testes são simuladas, não medições de FPS ou testes ao vivo do Overpass.

O navegador deste ambiente não acessou a prévia local (`ERR_CONNECTION_REFUSED`). A API pública do projeto também não respondeu às tentativas HTTP deste ambiente, embora os conectores confirmem projeto saudável, banco acessível e função ativa. Não foi possível afirmar FPS, tempo completo de abertura no navegador do usuário, aparência do popup em execução ou tempo de resposta real da versão 11. Antes da mudança, os logs reais da versão 10 mostravam respostas salvas entre 435 e 1.642 ms; não se deve comparar essas amostras com testes simulados para inventar uma melhora de latência.

A redução de bytes não significa automaticamente 20% menos tempo de abertura: rede, compressão do servidor, cache do navegador e tiles externos também influenciam. O mapa usa tiles públicos do OSM apenas na área visível; não há download em massa, remoção de atribuição ou desvio de quotas. Dados novos e fotos continuam limitados à cobertura documentada na versão anterior.

## Como executar

```bash
npm ci
npm run web
```

Para testar o bundle de produção localmente:

```bash
npm run web:production
```

Para gerar a versão de produção web dividida por rotas:

```bash
npm run build:web
```

Publique a pasta `dist` inteira, incluindo todos os chunks em `_expo`, com fallback de rotas para `index.html`. Após publicar uma versão, teste também uma navegação para perfil, avaliação e painel; carregar apenas `index.html` não basta. O primeiro acesso a uma página baixa seu chunk e os seguintes o reutilizam.

Verificações:

```bash
npm run typecheck
npm run lint
npm run test:performance
npm run test:osm
npm run test:map
npm run test:mobile
npm run test:state
```

Nenhuma migração de banco, alteração de conta, exclusão de dados ou configuração paga foi feita nesta atualização. Para outro projeto Supabase, publique os três arquivos da função `lugares-osm` presentes neste ZIP e mantenha JWT habilitado.

## Fontes oficiais consultadas em 14/10/2026

- React Native — desempenho e thread JavaScript: https://reactnative.dev/docs/performance
- React — memoização e referências de props: https://react.dev/reference/react/memo
- Expo — análise do bundle e teste em produção: https://docs.expo.dev/guides/analyzing-bundles/
- Expo Router — rotas assíncronas, inclusive configuração explícita em SDK 57 e anteriores: https://docs.expo.dev/router/web/async-routes/
- Supabase — tarefas após resposta com `EdgeRuntime.waitUntil` e tratamento de falhas: https://supabase.com/docs/guides/functions/background-tasks
- Supabase — changelog, incluindo aviso TLS de 12/10 sem necessidade de mudança para os clientes atuais: https://supabase.com/changelog
- MDN — `requestAnimationFrame`: https://developer.mozilla.org/en-US/docs/Web/API/Window/requestAnimationFrame
- react-native-maps — propriedades de marcadores: https://github.com/react-native-maps/react-native-maps/blob/master/docs/marker.md
- OSM Foundation — política dos tiles: https://operations.osmfoundation.org/policies/tiles/
